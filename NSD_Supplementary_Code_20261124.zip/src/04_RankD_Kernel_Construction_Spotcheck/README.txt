Independent numerical spot check (100 finite cases) of the rank-d holonomy construction. Requires Python 3 and NumPy. Run: python rank_d_kernel_spotcheck.py
Not a mathematical proof. Does not train any NSD model.
