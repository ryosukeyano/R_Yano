#!/usr/bin/env python3
"""Independent numerical spot check of the manuscript's Lemma B.

This verifies a finite set of constructed sheaves; it is NOT a proof and
is not a substitute for analytic verification. Uses numpy only.
"""
import csv
import numpy as np
from pathlib import Path

GRAPHS = {
 'C3': (3, [(0, 1), (1, 2), (2, 0)], 0),
 'C5': (5, [(i, (i + 1) % 5) for i in range(5)], 0),
 'K4': (4, [(i, j) for i in range(4) for j in range(i + 1, 4)], 0),
 'C6+chord': (6, [(i, (i + 1) % 6) for i in range(6)] + [(0, 2)], 0),
}

def householder_e1_to(v):
    d=len(v)
    e1=np.eye(d)[0]
    w=e1-v
    if np.linalg.norm(w)<1e-12: return np.eye(d)
    return np.eye(d)-2*np.outer(w,w)/np.dot(w,w)

def test(graph, d, seed):
    n, edges, e_star = GRAPHS[graph]
    rng=np.random.default_rng(seed)
    g=rng.uniform(0.2,3.0,size=len(edges))
    s=np.zeros(n)
    for k,(u,v) in enumerate(edges):s[u]+=g[k];s[v]+=g[k]
    z=rng.normal(size=(n,d))
    z=z/np.linalg.norm(z,axis=1)[:,None]*np.sqrt(s)[:,None]
    R=[householder_e1_to(z[v]/np.linalg.norm(z[v])) for v in range(n)]
    H=np.diag([1]+[-1]*(d-1))
    cob=np.zeros((len(edges)*d,n*d))
    for e,(u,v) in enumerate(edges):
        for vertex,sign in ((u,1),(v,-1)):
            U=H if (e==e_star and vertex==u) else np.eye(d)
            F=np.sqrt(g[e])/np.linalg.norm(z[vertex])*U@R[vertex].T
            cob[e*d:(e+1)*d,vertex*d:(vertex+1)*d]=sign*F
    DD=cob.T@cob
    degree_error=max(np.linalg.norm(DD[v*d:(v+1)*d,v*d:(v+1)*d]-np.eye(d),2) for v in range(n))
    residual=np.linalg.norm(cob@z.ravel())
    nulldim=n*d-np.linalg.matrix_rank(cob,tol=1e-9)
    return {'graph':graph,'rank':d,'seed':seed,'kernel_nullity':nulldim,'delta_z_norm':residual,'degree_identity_error':degree_error,'pass':(nulldim==1 and residual<1e-10 and degree_error<1e-10)}

if __name__ == '__main__':
    rows=[test(g,d,seed) for g in GRAPHS for d in [1,2,3,4,6] for seed in [0,1,2,3,4]]
    path=Path(__file__).with_name('rank_d_kernel_spotcheck.csv')
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    print(f'{len(rows)} checks; passes = {sum(row["pass"] for row in rows)}; output={path}')
    if not all(row['pass'] for row in rows): raise SystemExit('FAILED')
