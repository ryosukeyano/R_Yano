@echo off
py -3 replot_combine_nsd_5_7_8_9_times.py --roots results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU --figures 5,7,8,9 --width 6.5 --font-size 10 --tick-size 8.8 --legend-size 9.5 --panel-hgap 0.12 --panel-vgap 0.12 --font-name "Times New Roman"
pause
