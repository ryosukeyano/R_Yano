@echo off
py -3 replot_combine_nsd_fig6_10_11_times.py --roots results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU --figures 6,10,11 --width 6.5 --font-size 10.5 --tick-size 9.2 --legend-size 9.5 --panel-hgap 0.16 --panel-vgap 0.25 --font-name "Times New Roman"
pause
