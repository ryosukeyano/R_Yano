#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Directly regenerate compact, original-panel-order combined NSD Figures 5/7/8/9.

The script reads the saved *actual* per-run training_mse CSVs. It performs no
training, interpolation, smoothing, pseudo-data generation, image compositing,
or modification of the stored results. It draws all panels for each figure into
ONE matplotlib canvas (top: first 20 updates, bottom: full log history) and
saves print-scale true-vector EPS/PDF and PNG. Uses explicit gaps in INCHES.
2026-11-23: Fixed left-side vertical row labels clipped outside canvas;
responsive print-scale left-margin and glyph-overlap checks added.

Python>=3.9, numpy, matplotlib; no torch/GPU needed.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib import font_manager
from matplotlib.ticker import LogLocator, LogFormatterMathtext, NullLocator, MaxNLocator

def resolve_font(preferred):
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in preferred:
        if name in available:
            return name
    return 'DejaVu Serif'


plt.rcParams.update({
    'pdf.fonttype': 42,  # TrueType embedded for selectable PDF text
    'ps.fonttype': 42,
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times New Roman PS MT', 'Nimbus Roman', 'Liberation Serif', 'DejaVu Serif'],
    'axes.unicode_minus': False,
    'savefig.facecolor': 'white',
    'mathtext.fontset': 'stix',
})
RANKS = (2, 4, 6, 8)
COLORS = {2: '#2b6bb2', 4: '#d97731', 6: '#378a62', 8: '#c74b51'}
GCN_COLOR = '#7659a6'

@dataclass(frozen=True)
class Case:
    family: str
    n: int
    params: tuple
    task: str
    hidden: int
    def describe(self):
        return f'{self.family}, N={self.n}, ' + ', '.join(f'{k}={v}' for k, v in self.params) + f', {self.task}, h={self.hidden}'

def case(family, n, params, task, hidden):
    return Case(str(family), int(n), tuple(sorted((str(k), round(v, 9) if isinstance(v, float) else v)
                                                 for k, v in params.items())), str(task), int(hidden))

def layouts():
    """Exact original Figure 5, 7, 8, 9 row/column conditions (two histories)."""
    ns = (10, 50, 100, 300)
    return {
        5: (3, 4, [case(f, n, pars, 'feature_sum_noise', 20)
                    for f, pars in (('ER', {'p': .1}), ('BA', {'m': 2}), ('WS', {'k': 4, 'p': .1}))
                    for n in ns],
            ['ER  p=0.1', 'BA  m=2', 'WS  k=4, p=0.1'], ns),
        7: (2, 4, [case('BA', n, {'m': m}, 'feature_sum_noise', 16)
                    for m in (2, 4) for n in ns],
            ['BA  m=2', 'BA  m=4'], ns),
        8: (2, 4, [case('WS', n, {'k': k, 'p': p}, 'feature_sum_noise', 16)
                    for k, p in ((4, .1), (6, .2)) for n in ns],
            ['WS  k=4, p=0.1', 'WS  k=6, p=0.2'], ns),
        9: (3, 3, [case(f, n, pars, 'smoothed', 20)
                    for f, pars in (('ER', {'p': .1}), ('BA', {'m': 2}), ('WS', {'k': 4, 'p': .1}))
                    for n in (50, 100, 200)],
            ['ER  p=0.1', 'BA  m=2', 'WS  k=4, p=0.1'], (50, 100, 200)),
    }

def get_sources(roots, seed, layers):
    sources = defaultdict(list)
    for priority, rootstr in enumerate(roots):
        root = Path(rootstr)
        if not root.is_dir():
            print(f'NOTICE: Not present: {root}', file=sys.stderr)
            continue
        for jf in sorted(root.glob('*/case.json')):
            try:
                d = json.loads(jf.read_text(encoding='utf-8-sig'))
                if int(d['seed']) != seed or int(d['layers']) != layers:
                    continue
                key = case(d['family'], d['N'], d['parameters'], d['task'], d['hidden_channels'])
                folder = jf.parent
                finished = int((folder / 'completed.json').is_file())
                loss_count = len(list(folder.glob('*_loss.csv')))
                sources[key].append(((finished, loss_count, -priority), folder))
            except (OSError, TypeError, ValueError, KeyError) as ex:
                print(f'WARNING: Invalid case {jf}: {ex}', file=sys.stderr)
    return {k: max(candidates, key=lambda x: x[0])[1] for k, candidates in sources.items()}

def read_curve(path):
    xs, ys = [], []
    with path.open(newline='', encoding='utf-8-sig') as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames or not {'epoch', 'training_mse'} <= set(reader.fieldnames):
            raise ValueError(f'Missing epoch/training_mse columns: {path}')
        for row in reader:
            n, v = int(row['epoch']), float(row['training_mse'])
            if n < 1 or not math.isfinite(v) or v < 0:
                raise ValueError(f'Invalid record in {path}: {row}')
            xs.append(n-1)  # recorded epoch=1 is pre-first-update state
            ys.append(v)
    if not xs or any(b <= a for a, b in zip(xs, xs[1:])):
        raise ValueError(f'Empty or non-increasing epoch sequence: {path}')
    return np.asarray(xs, float), np.asarray(ys, float)

def load_data(requested, sources):
    curves, audit, issues = {}, [], []
    unique_cases = dict.fromkeys(c for fig in requested for c in layouts()[fig][2])
    for c in unique_cases:
        folder = sources.get(c)
        missing = []
        lines = {}
        if folder is None:
            missing.append('case.json')
        else:
            if not (folder/'completed.json').exists():
                missing.append('completed.json')
            for model in [f'NSD_rank{r}' for r in RANKS] + ['GCN_graph_using']:
                name = model + '_loss.csv'
                if not (folder/name).is_file():
                    missing.append(name)
                else:
                    try:
                        lines[model] = read_curve(folder/name)
                    except (ValueError, OSError) as ex:
                        missing.append(f'{name}: {ex}')
        if missing:
            issues.append(f'{c.describe()} [{"; ".join(missing)}]')
        curves[c] = lines
        audit.append({
            'case': c.describe(), 'folder': str(folder) if folder else '',
            'status': 'OK' if not missing else 'MISSING',
            'issues': '; '.join(missing)
        })
    return curves, audit, issues

def positive_limits(curves, lower=.85, upper=1.2):
    all_positive = [y[y > 0] for panel in curves for x, y in panel.values() if np.any(y > 0)]
    if not all_positive:
        raise ValueError('No positive MSE values: cannot use logarithmic y axis')
    lo = min(float(z.min()) for z in all_positive)
    hi = max(float(z.max()) for z in all_positive)
    if lo == hi:
        return (lo*.8, hi*1.25)
    return (lo*lower, hi*upper)

def panel_draw(ax, curves, view, args, ylims, show_y, show_x, col=0):
    for d in RANKS:
        key = f'NSD_rank{d}'
        if key not in curves:
            continue
        x, y = curves[key]
        mask = x <= 20 if view == 'early' else y > 0
        ax.plot(x[mask], y[mask], lw=args.line_width, color=COLORS[d],
                solid_joinstyle='round', clip_on=True)
    if 'GCN_graph_using' in curves:
        x, y = curves['GCN_graph_using']
        mask = x <= 20 if view == 'early' else y > 0
        ax.plot(x[mask], y[mask], color=GCN_COLOR, lw=args.line_width,
                linestyle='--', clip_on=True)
    if not curves:
        ax.text(.5, .5, 'DATA MISSING', transform=ax.transAxes,
                fontsize=args.tick_size, ha='center', va='center', color='crimson')
    if view == 'early':
        ax.set_xlim(0,20)
        ax.set_xticks((0,10,20))
        ax.set_ylim(*ylims)
        ax.yaxis.set_major_locator(MaxNLocator(4))
    else:
        ax.set_yscale('log', nonpositive='mask')
        ax.set_xlim(0, args.full_xmax)
        ax.set_xticks((0, 500, 1000) if args.full_xmax == 1000 else
                      (0, args.full_xmax/2, args.full_xmax))
        ax.set_ylim(*ylims)
        ax.yaxis.set_major_locator(LogLocator(base=10.0, numticks=5))
        ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10.0))
        ax.yaxis.set_minor_locator(NullLocator())
    ax.tick_params(axis='both', which='major', labelsize=args.tick_size,
                   length=2.0, width=.6, pad=1.4,
                   labelleft=show_y, labelbottom=show_x)
    if show_x and col > 0:
        # Adjacent frames are close together: omit only the duplicated leftmost '0'.
        labels = [tick.get_text() for tick in ax.get_xticklabels()]
        if labels:
            labels[0] = ''
            ax.set_xticklabels(labels)
    ax.tick_params(axis='both', which='minor', left=False, bottom=False)
    ax.grid(color='#dedede', linewidth=.45)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_linewidth(.6)
    return

def draw_combined(fig_no, layout, source_data, args, draft=False):
    nrows, ncols, cases, row_names, ns = layout
    fig_width = args.width
    # The previous version placed rotated ER/BA/WS labels at x=0.11in.
    # At 10pt their ink extents reached x=-0.03in and were cropped in EPS/PDF.
    # Keep the compact inter-panel gaps, but reserve a narrow safe left gutter.
    # Scale gutter with fonts so a user's larger label settings remain safe.
    row_label_x = max(args.row_label_x, 0.21 + 0.017 * max(0., args.font_size - 10.))
    lmargin = max(args.left_margin,
                  0.77 + 0.044 * max(0., args.font_size - 10.)
                       + 0.048 * max(0., args.tick_size - 8.8),
                  row_label_x + 0.55)
    rmargin = args.right_margin
    xgap = args.panel_hgap if args.log_scale != 'panel' else max(args.panel_hgap, .32)
    panel_w = (fig_width-lmargin-rmargin-xgap*(ncols-1))/ncols
    if panel_w < 1.08:
        raise ValueError(f'Panel width only {panel_w:.2f} in; increase --width or reduce gaps')
    panel_h = args.panel_height
    rowgap = args.panel_vgap
    sectionhead = args.section_header
    part_h = sectionhead+nrows*panel_h+(nrows-1)*rowgap
    fig_height = args.top_margin+2*part_h+args.section_gap+args.bottom_margin
    fig = plt.figure(figsize=(fig_width, fig_height), facecolor='white')

    all_early = [float(v) for c in cases for x, y in source_data[c].values()
                 for v in y[x <= 20]]
    upper = max(all_early)*1.07 if all_early else 1
    upper = max(upper, 1.e-8)
    early_limits = (0, upper)
    full_limits = {}
    for row in range(nrows):
        for col in range(ncols):
            idx = row*ncols+col
            if args.log_scale == 'panel':
                group = [source_data[cases[idx]]]
            elif args.log_scale == 'row':
                group = [source_data[c] for c in cases[row*ncols:(row+1)*ncols]]
            else:
                group = [source_data[c] for c in cases]
            if any(np.any(y > 0) for cvs in group for x,y in cvs.values()):
                full_limits[idx] = positive_limits(group)
            else:
                full_limits[idx] = (1.e-6,1)

    row_label_pairs = []  # (rotated label, leftmost-plot axis) for crop/overlap audit
    for section, view in enumerate(('early', 'full')):
        # y position of the top of this complete section, measured bottom-up in inches
        section_top = fig_height-args.top_margin-section*(part_h+args.section_gap)
        # Header: one title and one N-label per COLUMN, instead of titles over 24 axes.
        heading = '(a) First 20 optimizer updates - linear MSE' if view=='early' else \
                  '(b) Full training history - logarithmic MSE'
        fig.text(lmargin/fig_width, (section_top-.10)/fig_height, heading,
                 ha='left', va='top', fontsize=args.font_size, fontweight='bold')
        for col, n in enumerate(ns):
            xmid = lmargin + col*(panel_w+xgap)+panel_w/2
            fig.text(xmid/fig_width, (section_top-sectionhead+.10)/fig_height,
                     f'N={n}', fontsize=args.font_size-.25,
                     ha='center', va='bottom')
        for row in range(nrows):
            ytop = section_top-sectionhead-row*(panel_h+rowgap)
            ybottom = ytop-panel_h
            row_text = fig.text(row_label_x/fig_width, (ybottom+panel_h/2)/fig_height,
                                row_names[row].replace('  ', '\n', 1),
                                fontsize=args.font_size-.45,
                                rotation=90, ha='center', va='center')
            for col in range(ncols):
                idx = row*ncols+col
                left = lmargin+col*(panel_w+xgap)
                ax = fig.add_axes((left/fig_width, ybottom/fig_height,
                                   panel_w/fig_width, panel_h/fig_height))
                cvs = source_data[cases[idx]]
                lim = early_limits if view=='early' else full_limits[idx]
                if col == 0:
                    row_label_pairs.append((row_text, ax))
                panel_draw(ax, cvs, view, args, lim,
                           show_y=(col==0 if args.log_scale != 'panel' or view=='early' else True),
                           show_x=(row==nrows-1), col=col)
        # Shared y-axis / x-axis label instead of per-panel labels
        bottom = section_top-part_h
        fig.text((lmargin + (fig_width-lmargin-rmargin)/2)/fig_width,
                 (bottom-.21)/fig_height, 'Optimizer updates',
                 fontsize=args.font_size-.5, ha='center', va='top')

    handles = [Line2D([0],[0], lw=args.line_width*1.2, color=COLORS[r]) for r in RANKS]
    handles.append(Line2D([0],[0], lw=args.line_width*1.2, color=GCN_COLOR, ls='--'))
    legend_labels = [f'NSD  d={r}' for r in RANKS] + ['GCN']
    fig.legend(handles, legend_labels, loc='lower center', frameon=False,
               ncol=5, fontsize=args.legend_size, columnspacing=.9,
               handlelength=1.7, bbox_to_anchor=(.52, .024),
               borderaxespad=0., handletextpad=.4)
    if draft:
        fig.text(.5,.5,'INCOMPLETE DATA - DRAFT',fontsize=20,color='crimson',
                 alpha=.25, rotation=23,ha='center',va='center',fontweight='bold')
    axes_spec = {
        'figure': fig_no, 'n_rows_per_section': nrows, 'n_columns': ncols,
        'total_panels': 2*nrows*ncols, 'width_inches': round(fig_width,3),
        'height_inches': round(fig_height,3), 'panel_width_inches': round(panel_w,3),
        'panel_height_inches': round(panel_h,3), 'hgap_inches': round(xgap,3),
        'vgap_inches': round(rowgap,3), 'full_log_scale': args.log_scale,
        'font_size_pt': args.font_size, 'tick_size_pt': args.tick_size,
        'full_xmax': args.full_xmax,
        'actual_left_margin_inches': round(lmargin, 3),
        'row_label_center_inches': round(row_label_x, 3),
    }
    # Verify the printed canvas contains every ER/BA/WS glyph. Preserve the
    # exact figure size (do not rely on bbox_inches='tight' as a band-aid).
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    pad_px = fig.dpi * .035  # >=0.035in safety between glyph and crop border
    gap_px = fig.dpi * .04   # >=0.04in separation from left-column tick labels
    min_edge_px = float('inf')
    min_gap_px = float('inf')
    for row_text, ax in row_label_pairs:
        rb = row_text.get_window_extent(renderer)
        min_edge_px = min(min_edge_px, rb.x0)
        for tick in ax.get_yticklabels():
            if not tick.get_visible() or not tick.get_text():
                continue
            tb = tick.get_window_extent(renderer)
            if tb.y1 >= rb.y0 and tb.y0 <= rb.y1:
                min_gap_px = min(min_gap_px, tb.x0 - rb.x1)
    if min_edge_px < pad_px - 0.25:
        raise ValueError(f'Left row-label glyph touches figure crop: '
                         f'{min_edge_px / fig.dpi:.3f}in from edge, needs >=0.035in. '
                         'Increase --row-label-x.')
    if min_gap_px < gap_px - 0.25:
        raise ValueError(f'Left row labels are too close to y-tick labels: '
                         f'{min_gap_px / fig.dpi:.3f}in, needs >=0.04in. '
                         'Increase --left-margin.')
    axes_spec['min_left_glyph_inch'] = round(min_edge_px / fig.dpi, 3)
    axes_spec['min_row_label_to_tick_gap_inch'] = round(min_gap_px / fig.dpi, 3)
    axes_spec['all_row_labels_inside_canvas'] = True
    return fig, axes_spec

def parse_args():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('--roots',nargs='+',default=['results_BASE_GPU','results_SWEEPS_GPU','results_SMOOTHED_GPU','results_COMPARE_GPU'])
    p.add_argument('--output-dir',default='NSD_figures_5_7_8_9_COMBINED_TIGHT')
    p.add_argument('--figures',default='5,7,8,9')
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--layers',type=int,default=2)
    p.add_argument('--width',type=float,default=6.50,help='Printed composite width in inches; 6.50 matches this manuscript\'s letter paper with 1in margins')
    p.add_argument('--panel-height',type=float,default=.91,help='Height of each data frame in inches')
    p.add_argument('--panel-hgap',type=float,default=.12,help='Gap BETWEEN plot frames horizontally (inches)')
    p.add_argument('--panel-vgap',type=float,default=.12,help='Gap BETWEEN plot frames vertically (inches)')
    p.add_argument('--section-gap',type=float,default=.42,help='Gap between early and full sections (inches)')
    p.add_argument('--section-header',type=float,default=.52,help='Height for one section title and column headers')
    p.add_argument('--left-margin',type=float,default=.77,help='Reserve for log ticks and row labels; grows automatically for larger font sizes')
    p.add_argument('--row-label-x',type=float,default=.21,help='ER/BA/WS row-label center measured from the left edge in inches')
    p.add_argument('--right-margin',type=float,default=.16)
    p.add_argument('--top-margin',type=float,default=.12)
    p.add_argument('--bottom-margin',type=float,default=.86)
    p.add_argument('--font-size',type=float,default=10.0,help='Section headings, N column labels and row labels (pt)')
    p.add_argument('--tick-size',type=float,default=8.8,help='Axis tick font size (pt)')
    p.add_argument('--legend-size',type=float,default=9.0)
    p.add_argument('--font-name', type=str, default='Times New Roman', help='Preferred font family name for all non-math text')
    p.add_argument('--line-width',type=float,default=1.05)
    p.add_argument('--log-scale',choices=('row','figure','panel'),default='row',
                   help='Shared full-log y-axis per ROW (compact), across FIGURE, or per PANEL (larger gaps)')
    p.add_argument('--full-xmax',type=float,default=1000,help='Full-training x axis upper bound, 1000 includes all saved 999 updates')
    p.add_argument('--dpi',type=int,default=300)
    p.add_argument('--allow-incomplete',action='store_true',help='Only inspection: watermarked incomplete DRAFT outputs')
    return p.parse_args()

def run():
    args=parse_args()
    chosen_font = resolve_font([args.font_name, 'Times New Roman', 'Times New Roman PS MT', 'Nimbus Roman', 'Liberation Serif'])
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = [chosen_font, 'Times New Roman', 'Times New Roman PS MT', 'Nimbus Roman', 'Liberation Serif', 'DejaVu Serif']
    print(f'Using font: {chosen_font}')
    try:
        selected=sorted(set(int(s.strip()) for s in args.figures.split(',') if s.strip()))
    except ValueError:
        raise SystemExit('Use --figures 5,7,8,9')
    if not selected or not set(selected) <= set(layouts()):
        raise SystemExit('Only --figures 5,7,8,9 are supported')
    for name in ('width','panel_height','font_size','tick_size','legend_size','line_width','full_xmax'):
        if getattr(args,name) <= 0:
            raise SystemExit('--'+name.replace('_','-')+' must be positive')
    for name in ('panel_hgap','panel_vgap','section_gap','section_header','left_margin',
                 'right_margin','top_margin','bottom_margin','row_label_x'):
        if getattr(args,name) < 0:
            raise SystemExit('--'+name.replace('_','-')+' must be nonnegative')
    if args.section_header < .33 or args.bottom_margin < .34:
        raise SystemExit('Please reserve section-header>=.33 and bottom-margin>=.34 to avoid text collision')
    sources=get_sources(args.roots,args.seed,args.layers)
    curves,audit,issues=load_data(selected,sources)
    if issues and not args.allow_incomplete:
        print('ERROR: Input data incomplete. No paper figures produced. Missing entries:',file=sys.stderr)
        for error in issues:
            print(' -',error,file=sys.stderr)
        return 2
    out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)
    with (out/'SOURCE_AUDIT.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['case','folder','status','issues']);w.writeheader();w.writerows(audit)
    manifest=[]
    for figno in selected:
        fig, spec=draw_combined(figno,layouts()[figno],curves,args,draft=bool(issues))
        stem=f'{"DRAFT_" if issues else ""}FIG_{figno:02d}_FIRST20_AND_FULL_COMPACT'
        for ext in ('eps','pdf','png'):
            dest=out/(stem+'.'+ext)
            # No bbox_inches="tight" - it could change the promised printed dimensions.
            fig.savefig(dest,format=ext,dpi=args.dpi)
        plt.close(fig)
        spec['file_stem']=stem
        manifest.append(spec)
        print(f'SAVED {stem}.eps/.pdf/.png  ({spec["width_inches"]} x {spec["height_inches"]} in; '
              f'panel {spec["panel_width_inches"]} x {spec["panel_height_inches"]} in)')
    (out/'PLOT_MANIFEST.json').write_text(json.dumps({
        'plots':manifest, 'original_CSVs_unchanged':True,
        'x_coordinate':'optimizer updates = recorded epoch - 1',
        'early_y':'linear, shared across entire figure',
        'full_y':'strict positive logarithmic; no zero replacement or smoothing',
        'data_status':'DRAFT - incomplete' if issues else 'COMPLETE',
        'left_clipping_checked': True,
        'missing_input':issues,
    },indent=2,ensure_ascii=False),encoding='utf-8')
    return 1 if issues else 0

if __name__=='__main__':
    sys.exit(run())
