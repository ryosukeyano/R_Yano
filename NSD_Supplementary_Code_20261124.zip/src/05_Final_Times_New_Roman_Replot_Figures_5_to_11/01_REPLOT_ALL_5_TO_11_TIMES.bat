@echo off
REM Figures 5,7,8,9
py -3 replot_combine_nsd_5_7_8_9_times.py --roots results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU --figures 5,7,8,9 --width 6.5 --font-size 10 --tick-size 8.8 --legend-size 9.5 --panel-hgap 0.12 --panel-vgap 0.12 --font-name "Times New Roman"
if errorlevel 1 goto end
REM Figures 6,10,11
py -3 replot_combine_nsd_fig6_10_11_times.py --roots results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU --figures 6,10,11 --width 6.5 --font-size 10.5 --tick-size 9.2 --legend-size 9.5 --panel-hgap 0.16 --panel-vgap 0.25 --font-name "Times New Roman"
:end
pause
