#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Replot corrected NSD Figures 6, 10 and 11 from saved REAL loss CSVs.

Paper-width, compact TWO-SECTION combined figures, with larger plot frames,
font controls, one shared legend, cropped-label checks, and EPS/PDF/PNG outputs.
No training, curve smoothing, interpolation, data alteration, or pasted images.

Required case folder contents: case.json, completed.json,
 NSD_rank2_loss.csv, NSD_rank4_loss.csv, NSD_rank6_loss.csv,
 NSD_rank8_loss.csv, GCN_graph_using_loss.csv.
CSV columns: epoch, training_mse (epoch=1 is zero optimizer updates).

All conditions and 2-layer models are taken from the original
plot_combined_fig5to11_tight.py in the supplied Physica D source.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib import font_manager
from matplotlib.ticker import LogFormatterMathtext, LogLocator, MaxNLocator, NullLocator, FuncFormatter, FixedLocator

def resolve_font(preferred):
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in preferred:
        if name in available:
            return name
    return 'DejaVu Serif'


plt.rcParams.update({
    'pdf.fonttype': 42, 'ps.fonttype': 42,
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times New Roman PS MT', 'Nimbus Roman', 'Liberation Serif', 'DejaVu Serif'],
    'axes.unicode_minus': False,
    'savefig.facecolor': 'white',
    'mathtext.fontset': 'stix',
})
RANKS = (2, 4, 6, 8)
COLORS = {2: '#2b6bb2', 4: '#d97731', 6: '#378a62', 8: '#c74b51'}
GCN_COLOR = '#7659a6'
MODELS = [f'NSD_rank{r}' for r in RANKS] + ['GCN_graph_using']


@dataclass(frozen=True)
class Case:
    family: str
    n: int
    params: tuple
    task: str
    hidden: int

    def title(self):
        return f'{self.family} N={self.n}, ' + ', '.join(f'{k}={v:g}' if isinstance(v, float)
                              else f'{k}={v}' for k, v in self.params)

    def describe(self):
        return self.title() + f', task={self.task}, h={self.hidden}'

    def short_title(self):
        # N and graph family stay in figure captions; shorter titles make
        # 1.7-inch frames remain readable at the printed width.
        if self.family == 'ER':
            return ', '.join(f'{k}={v:g}' if isinstance(v,float) else f'{k}={v}' for k,v in self.params)
        if self.family == 'BA':
            return f'BA m={dict(self.params)["m"]}'
        return f'WS k={dict(self.params)["k"]}, p={dict(self.params)["p"]:g}'


def case(family, n, params, task, hidden):
    return Case(str(family), int(n),
                tuple(sorted((str(k), round(float(v), 9) if isinstance(v, float) else v)
                             for k,v in params.items())), str(task), int(hidden))


def layouts():
    # Exact ordered experimental conditions of the manuscript's source script.
    return {
        6: (2, 3, [case('ER', 100, {'p':x}, 'feature_sum_noise',16)
                    for x in (.1,.3,.5,.7,.9)]+[None],
            'ER connection probability - graph-independent target'),
        10: (1, 3, [case('ER',50,{'p':x},'smoothed',16)
                     for x in (.1,.5,.9)],
             'ER connection probability - graph-smoothed target'),
        11: (2, 2, [case('BA',50,{'m':2},'smoothed',16),
                     case('BA',50,{'m':4},'smoothed',16),
                     case('WS',50,{'k':4,'p':.1},'smoothed',16),
                     case('WS',50,{'k':6,'p':.2},'smoothed',16)],
             'BA and WS parameters - graph-smoothed target'),
    }


def discover(roots, seed, layers):
    candidates = defaultdict(list)
    for priority, path in enumerate(roots):
        root = Path(path).resolve()
        if not root.is_dir():
            print(f'NOTICE: folder not present: {root}', file=sys.stderr)
            continue
        for jf in sorted(root.glob('*/case.json')):
            try:
                d = json.loads(jf.read_text(encoding='utf-8-sig'))
                if int(d['seed']) != seed or int(d['layers']) != layers:
                    continue
                c = case(d['family'],d['N'],d['parameters'],d['task'],d['hidden_channels'])
                folder = jf.parent
                complete = int((folder/'completed.json').is_file())
                number_of_losses = len(list(folder.glob('*_loss.csv')))
                candidates[c].append(((complete,number_of_losses,-priority),folder))
            except (OSError,TypeError,ValueError,KeyError) as exc:
                print(f'WARNING: ignored invalid {jf}: {exc}',file=sys.stderr)
    return {c: max(opts,key=lambda k:k[0])[1] for c,opts in candidates.items()}


def read_loss(path, min_records):
    x,y=[],[]
    with path.open(newline='',encoding='utf-8-sig') as stream:
        reader=csv.DictReader(stream)
        if not reader.fieldnames or not {'epoch','training_mse'} <= set(reader.fieldnames):
            raise ValueError(f'missing epoch / training_mse header in {path}')
        for record in reader:
            ep=int(record['epoch'])
            v=float(record['training_mse'])
            if ep < 1 or not math.isfinite(v) or v < 0:
                raise ValueError(f'invalid loss in {path}: {record}')
            x.append(ep-1)  # CSV epoch=1 is PRE-first-update loss
            y.append(v)
    if len(x) < min_records:
        raise ValueError(f'truncated loss: only {len(x)} records, expected >= {min_records}: {path}')
    if any(b<=a for a,b in zip(x,x[1:])):
        raise ValueError(f'non-increasing epoch values in {path}')
    return np.asarray(x,dtype=float),np.asarray(y,dtype=float)


def acquire(figures,sources,min_records):
    unique = dict.fromkeys(c for num in figures for c in layouts()[num][2] if c is not None)
    curves, audit, issues = {}, [], []
    for c in unique:
        folder=sources.get(c)
        missing=[]
        lines={}
        if folder is None:
            missing.append('case.json (case missing)')
        else:
            if not (folder/'completed.json').is_file():
                missing.append('completed.json')
            for model in MODELS:
                path=folder/(model+'_loss.csv')
                if not path.is_file():
                    missing.append(path.name)
                else:
                    try:
                        lines[model]=read_loss(path,min_records)
                    except (ValueError,KeyError,OSError) as e:
                        missing.append(f'{path.name}: {e}')
        if missing:
            issues.append(f'{c.describe()} -> ' + '; '.join(missing))
        audit.append({'case':c.describe(), 'data_folder':str(folder) if folder else '',
                      'status':'OK' if not missing else 'MISSING', 'detail':'; '.join(missing)})
        curves[c]=lines
    return curves,audit,issues


def log_limits(groups, lower=.85, upper=1.20):
    vals=[v[v>0] for curves in groups for _,v in curves.values() if np.any(v>0)]
    if not vals:
        return (1e-6,1.0)
    low=min(float(a.min()) for a in vals)
    high=max(float(a.max()) for a in vals)
    if not high>low:
        return low*.8,high*1.25
    return low*lower,high*upper


def draw_series(ax, curves, first, lims, args, col, row, nrows):
    for r in RANKS:
        name=f'NSD_rank{r}'
        if name in curves:
            x,y=curves[name]
            valid=(x<=20) if first else (y>0)
            ax.plot(x[valid],y[valid],color=COLORS[r],lw=args.line_width,
                    solid_joinstyle='round',clip_on=True)
    if 'GCN_graph_using' in curves:
        x,y=curves['GCN_graph_using']
        valid=(x<=20) if first else (y>0)
        ax.plot(x[valid],y[valid],color=GCN_COLOR,lw=args.line_width,ls='--',clip_on=True)
    if not curves:
        ax.text(.5,.5,'DATA MISSING',ha='center',va='center',transform=ax.transAxes,
                fontsize=args.font_size,color='crimson',fontweight='bold')
    if first:
        ax.set_xlim(0,20)
        ax.set_xticks([0,10,20])
        ax.set_ylim(*lims)
        ax.yaxis.set_major_locator(MaxNLocator(4))
    else:
        ax.set_yscale('log',nonpositive='mask')
        ax.set_xlim(0,args.full_xmax)
        if args.full_xmax==1000:
            ax.set_xticks([0,500,1000])
        else:
            ax.set_xticks([0,args.full_xmax/2,args.full_xmax])
        ax.set_ylim(*lims)
        # Matplotlib LogLocator may put outer-decade labels beyond the physical
        # canvas (notably Fig.10 at the bottom). Restrict ticks to the data
        # axes span, while keeping standard 10^n annotations.
        lo, hi = lims
        powers = list(range(int(math.ceil(math.log10(lo))),
                            int(math.floor(math.log10(hi)))+1))
        if len(powers) > 6:
            stride = int(math.ceil(len(powers) / 6))
            powers = powers[::stride]
        tick_values = [10.**e for e in powers]
        if not tick_values:
            tick_values = [math.sqrt(lo*hi)]
        ax.yaxis.set_major_locator(FixedLocator(tick_values))
        ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10))
        ax.yaxis.set_minor_locator(NullLocator())
    if col>0:
        # Drop only the x=0 label in panels after the first column; otherwise
        # 1000/0 or 20/0 can overlap when frame gaps are compact.
        ax.xaxis.set_major_formatter(FuncFormatter(
            lambda v,pos: '' if abs(v)<1.e-8 else (f'{int(v):d}' if abs(v-round(v))<1.e-8 else f'{v:g}')))
    ax.tick_params(axis='both',which='major',labelsize=args.tick_size,
                   length=2.5,width=.6,pad=2.0,
                   labelleft=(col==0 or (not first and args.log_scale=='panel')),
                   labelbottom=(row==nrows-1))
    ax.tick_params(axis='both',which='minor',left=False,bottom=False)
    for sp in ax.spines.values(): sp.set_linewidth(.7)
    ax.grid(color='#dddddd',linewidth=.47)
    ax.set_axisbelow(True)


def compose(number, layout, all_curves, args, draft):
    nrows,ncols,conditions,subject=layout
    width=args.width
    left=max(args.left_margin,.69+.041*max(0,args.tick_size-9.2))
    right=max(args.right_margin,.24+.02*max(0,args.tick_size-9.2))
    xgap=args.panel_hgap if args.log_scale!='panel' else max(args.panel_hgap,.38)
    panel_w=(width-left-right-(ncols-1)*xgap)/ncols
    if panel_w<1.28: raise ValueError(f'frame width {panel_w:.2f}in: increase --width')
    panel_h = args.panel_height if args.panel_height else (1.55 if nrows==1 else 1.10)
    vgap=args.panel_vgap
    head=args.section_header
    part=head+nrows*panel_h+(nrows-1)*vgap
    height=args.top_margin+2*part+args.section_gap+args.bottom_margin
    fig=plt.figure(figsize=(width,height),facecolor='white')
    early=[float(yv) for c in conditions if c is not None for x,y in all_curves[c].values()
           for yv in y[x<=20] ]
    upper=max(early)*1.07 if early else 1.0
    early_lim=(0,max(upper,1e-8))
    loglims={}
    for row in range(nrows):
        for col in range(ncols):
            idx=row*ncols+col
            if conditions[idx] is None:continue
            scope=([all_curves[conditions[idx]]] if args.log_scale=='panel' else
                   [all_curves[c] for c in conditions[row*ncols:(row+1)*ncols] if c]
                   if args.log_scale=='row' else
                   [all_curves[c] for c in conditions if c])
            loglims[idx]=log_limits(scope,args.lower_factor,args.upper_factor)

    for sec,view in enumerate(('early','full')):
        first=(view=='early')
        sectiontop=height-args.top_margin-sec*(part+args.section_gap)
        heading='(a) First 20 optimizer updates (linear MSE)' if first else \
                '(b) Full 1000-epoch history (logarithmic MSE)'
        fig.text(left/width,(sectiontop-.06)/height,heading,va='top',ha='left',
                 fontsize=args.font_size+.2,fontweight='bold')
        # Only leftmost y axis labeled. Drop duplicate axes-labels in all panels.
        ycenter=sectiontop-head-nrows*panel_h/2-(nrows-1)*vgap/2
        fig.text(.135/width,ycenter/height,'Training MSE',rotation=90,
                 ha='center',va='center',fontsize=args.font_size-.3)
        for row in range(nrows):
            ytop=sectiontop-head-row*(panel_h+vgap)
            ybottom=ytop-panel_h
            for col in range(ncols):
                idx=row*ncols+col
                condition=conditions[idx]
                if condition is None:
                    continue  # blank sixth cell in original Figure 6 is retained
                xpos=left+col*(panel_w+xgap)
                ax=fig.add_axes([xpos/width,ybottom/height,panel_w/width,panel_h/height])
                curves=all_curves[condition]
                draw_series(ax,curves,first,early_lim if first else loglims[idx],args,col,row,nrows)
                fig.text((xpos+panel_w/2)/width,(ytop+.075)/height,
                         condition.short_title(),ha='center',va='bottom',
                         fontsize=args.font_size-.3)
        bottom=sectiontop-part
        fig.text((left+(width-left-right)/2)/width,(bottom-.20)/height,
                 'Optimizer updates',ha='center',va='top',fontsize=args.font_size)

    handles=[Line2D([0],[0],color=COLORS[r],lw=args.line_width*1.25) for r in RANKS]
    handles.append(Line2D([0],[0],color=GCN_COLOR,lw=args.line_width*1.25,ls='--'))
    labels=[f'NSD d={r}' for r in RANKS]+['GCN']
    fig.legend(handles,labels,loc='lower center',ncol=5,frameon=False,
               fontsize=args.legend_size,bbox_to_anchor=(.51,.035),
               handlelength=1.7,columnspacing=.85,handletextpad=.36,borderaxespad=0)
    if draft:
        fig.text(.5,.5,'INCOMPLETE DATA - DRAFT ONLY',fontsize=21,
                 rotation=25,ha='center',va='center',color='crimson',alpha=.23,
                 fontweight='bold')

    # Check *all rendered visible text* including top titles, log tick labels,
    # shared axis labels and legend against EPS/PDF physical canvas.
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    fw=fig.get_figwidth()*fig.dpi
    fh=fig.get_figheight()*fig.dpi
    min_clearance=.025*fig.dpi
    problems=[]
    for t in fig.findobj(match=matplotlib.text.Text):
        if not t.get_visible() or not t.get_text().strip(): continue
        if t.get_window_extent(renderer).width<.2: continue
        box=t.get_window_extent(renderer)
        if (box.x0<min_clearance or box.y0<min_clearance or
                box.x1>fw-min_clearance or box.y1>fh-min_clearance):
            problems.append((t.get_text()[:35],tuple(round(v/fig.dpi,3)
                          for v in [box.x0,box.y0,box.x1,box.y1])))
    if problems:
        plt.close(fig)
        raise ValueError('At least one label would be cropped outside the output canvas: '
                         +repr(problems[:10])+'. Try larger margins/width.')
    result={
        'figure':number,'subject':subject,'width_in':round(width,3),
        'height_in':round(height,3), 'frame_width_in':round(panel_w,3),
        'frame_height_in':round(panel_h,3),'frame_hgap_in':round(xgap,3),
        'frame_vgap_in':round(vgap,3),'font_pt':args.font_size,
        'tick_font_pt':args.tick_size,'legend_font_pt':args.legend_size,
        'full_log_scale':args.log_scale,'total_data_frames':2*(len(conditions)-(1 if None in conditions else 0)),
        'all_visible_text_inside_canvas':True,
    }
    return fig,result


def args_parser():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('--roots',nargs='+',default=['results_BASE_GPU','results_SWEEPS_GPU','results_SMOOTHED_GPU','results_COMPARE_GPU'])
    p.add_argument('--output-dir',default='NSD_figures_6_10_11_COMBINED_LARGETEXT')
    p.add_argument('--figures',default='6,10,11')
    p.add_argument('--layers',type=int,default=2)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--min-records',type=int,default=1000,help='Minimum records per loss CSV to reject partial runs')
    p.add_argument('--width',type=float,default=6.5,help='Exact paper width, in inches')
    p.add_argument('--panel-height',type=float,default=None,help='Default 1.24in for 2 rows; 1.55in for 1 row')
    p.add_argument('--panel-hgap',type=float,default=.16,help='Horizontal gap between adjacent plotting frames in inches')
    p.add_argument('--panel-vgap',type=float,default=.25,help='Vertical gap between plotting frames in inches, allowing 10pt condition labels')
    p.add_argument('--section-header',type=float,default=.44)
    p.add_argument('--section-gap',type=float,default=.46)
    p.add_argument('--left-margin',type=float,default=.69)
    p.add_argument('--right-margin',type=float,default=.28)
    p.add_argument('--top-margin',type=float,default=.12)
    p.add_argument('--bottom-margin',type=float,default=.82)
    p.add_argument('--font-size',type=float,default=10.5)
    p.add_argument('--tick-size',type=float,default=9.2)
    p.add_argument('--legend-size',type=float,default=9.5)
    p.add_argument('--font-name',default='Times New Roman', help='Preferred font family name for all non-math text')
    p.add_argument('--line-width',type=float,default=1.25)
    p.add_argument('--full-xmax',type=float,default=1000)
    p.add_argument('--log-scale',choices=('row','figure','panel'),default='row',help='Full log axes shared by row, whole figure, or per panel')
    p.add_argument('--lower-factor',type=float,default=.85)
    p.add_argument('--upper-factor',type=float,default=1.20)
    p.add_argument('--dpi',type=int,default=300)
    p.add_argument('--allow-incomplete',action='store_true',help='For debugging only: add a prominent DRAFT watermark')
    return p.parse_args()


def main():
    a=args_parser()
    chosen_font = resolve_font([a.font_name, 'Times New Roman', 'Times New Roman PS MT', 'Nimbus Roman', 'Liberation Serif'])
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = [chosen_font, 'Times New Roman', 'Times New Roman PS MT', 'Nimbus Roman', 'Liberation Serif', 'DejaVu Serif']
    print(f'Using font: {chosen_font}')
    try:
        figs=sorted(set(int(s.strip()) for s in a.figures.split(',') if s.strip()))
    except ValueError:
        raise SystemExit('Bad --figures. Use 6,10,11')
    if not figs or not set(figs) <= {6,10,11}:
        raise SystemExit('This program supports exactly figures 6, 10, 11')
    for attr in ('width','font_size','tick_size','legend_size','line_width','full_xmax','min_records'):
        if getattr(a,attr)<=0: raise SystemExit(f'--{attr.replace("_","-")} must be positive')
    if a.panel_height is not None and a.panel_height <=0: raise SystemExit('Bad --panel-height')
    for attr in ('panel_hgap','panel_vgap','section_header','section_gap','left_margin','right_margin','top_margin','bottom_margin'):
        if getattr(a,attr)<0: raise SystemExit(f'Bad --{attr.replace("_","-")}')
    if not (0<a.lower_factor<1 and a.upper_factor>1):
        raise SystemExit('Bad --lower-factor or --upper-factor')
    sources=discover(a.roots,a.seed,a.layers)
    curves,audit,missing=acquire(figs,sources,a.min_records)
    if missing and not a.allow_incomplete:
        print('ERROR: Missing or incomplete actual results. No paper plots generated.',file=sys.stderr)
        for line in missing: print(' - '+line,file=sys.stderr)
        return 2
    output=Path(a.output_dir)
    output.mkdir(parents=True,exist_ok=True)
    with (output/'SOURCE_AUDIT.csv').open('w',newline='',encoding='utf-8-sig') as fp:
        wr=csv.DictWriter(fp,fieldnames=['case','data_folder','status','detail'])
        wr.writeheader();wr.writerows(audit)
    manifest=[]
    for fig_no in figs:
        fig,info=compose(fig_no,layouts()[fig_no],curves,a,bool(missing))
        stem=('DRAFT_' if missing else '')+f'FIG_{fig_no:02d}_20_FULL_COMBINED'
        for ext in ('eps','pdf','png'):
            # Preserve exact print dimensions; never silently expand bbox.
            fig.savefig(output/(stem+'.'+ext),format=ext,dpi=a.dpi)
        plt.close(fig)
        info['file_stem']=stem
        manifest.append(info)
        print(f'Created {stem}.eps/.pdf/.png; frame {info["frame_width_in"]} x {info["frame_height_in"]}in')
    (output/'PLOT_MANIFEST.json').write_text(json.dumps({
        'figures':manifest,'figure_caption_is_in_latex':True,
        'input_roots':a.roots,'ranks':RANKS,'layers':a.layers,'seed':a.seed,
        'x_coordinate':'optimizer updates = CSV epoch - 1',
        'first_20_ordinate':'linear, shared range across panels',
        'full_ordinate':'strictly positive logarithmic MSE, no zero replacement',
        'original_losses_modified':False,'smoothing_or_interpolation':False,
        'data_status':'DRAFT INCOMPLETE' if missing else 'COMPLETE',
        'missing_inputs':missing,
    },ensure_ascii=False,indent=2),encoding='utf-8')
    return 1 if missing else 0


if __name__=='__main__':
    sys.exit(main())
