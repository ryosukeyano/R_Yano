
import torch
import torch.nn as nn
import torch.nn.functional as F
import networkx as nx
import wandb
import csv
import os
import numpy as np
import random
import sys

from models.disc_models import DiscreteBundleSheafDiffusion, DiscreteDiagSheafDiffusion
from exp.parser import get_parser

# 通常のGNN（比較用）
class SimpleLinearGNN(nn.Module):
    def __init__(self, input_dim, output_dim, d, layers):
        super().__init__()
        self.layers = nn.ModuleList()
        self.layers.append(nn.Linear(input_dim, d))
        for _ in range(layers - 1):
            self.layers.append(nn.Linear(d, d))
        self.out = nn.Linear(d, output_dim)

    def forward(self, x):
        for layer in self.layers:
            x = F.relu(layer(x))
        return self.out(x)

def generate_graph(graph_type, num_nodes):
    if graph_type == "ER":
        G = nx.erdos_renyi_graph(num_nodes, 0.3)
    elif graph_type == "WS":
        G = nx.watts_strogatz_graph(num_nodes, k=4, p=0.1)
    elif graph_type == "BA":
        G = nx.barabasi_albert_graph(num_nodes, m=3)
    else:
        raise ValueError(f"Unknown graph type: {graph_type}")
    return G

def run_experiment(graph_type, num_nodes, layers):
    torch.manual_seed(0)
    np.random.seed(0)
    random.seed(0)

    d_values = [ 4,8]
    input_dim = 10
    output_dim = 1
    epochs = 1000
    early_stop = 1000
    lr = 0.02
    weight_decay = 5e-3
    device = torch.device("cpu")

    # グラフ生成とedge_index
    G = generate_graph(graph_type, num_nodes)
    edge_index = torch.tensor(list(G.edges), dtype=torch.long).t().contiguous()
    swap_index = edge_index[[1, 0], :]
    edge_index = torch.cat([edge_index, swap_index], dim=1)

    x = torch.rand((num_nodes, input_dim))
    y = x.sum(dim=1, keepdim=True) + 0.1 * torch.randn(num_nodes, 1)

    if False:
        src, dst = edge_index
        y = torch.zeros_like(x)
        y.index_add_(0, dst, x[src]) 
        degrees = torch.tensor([G.degree[node] for node in range(num_nodes)], dtype=torch.float32).unsqueeze(1)
        y = y / degrees
    models = {}
    opts = {}
    losses = {}
    parser = get_parser()

    for d in d_values:
        model_args = parser.parse_args()
        model_args.graph_size = num_nodes
        model_args.input_dim = input_dim
        model_args.output_dim = output_dim
        model_args.d = d
        model_args.layers = layers
        model_args.device = device
        print(d)
        model_args = vars(model_args)
        if d == 1:
            model = DiscreteDiagSheafDiffusion(edge_index, model_args)
            model_name = "DiagSheaf"
        else:
            model = DiscreteBundleSheafDiffusion(edge_index, model_args)
            model_name = "BundleSheaf"

        models[(model_name, d)] = model.to(device)
        grouped_params = model.grouped_parameters()
        opts[(model_name, d)] = torch.optim.Adam([
            {'params': grouped_params[0], 'weight_decay': weight_decay},
            {'params': grouped_params[1], 'weight_decay': weight_decay},
        ], lr=lr)
        losses[(model_name, d)] = []

    # 通常のGNNモデルも追加
    model_name = "SimpleGNN"
    for d in [1]:
        model = SimpleLinearGNN(input_dim, output_dim, d, layers)
        models[(model_name, d)] = model.to(device)
        opts[(model_name, d)] = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
        losses[(model_name, d)] = []

    # wandb設定
    wandb.init(project="gnn_structure_comparison_hetero", name=f"{graph_type}_L{layers}_N{num_nodes}_In{input_dim}", config={
        "graph": graph_type,
        "layers": layers,
        "nodes": num_nodes
    })

    os.makedirs("logs/harmonic", exist_ok=True)
    log_file = f"logs/harmonic/loss_log_{graph_type}_L{layers}_N{num_nodes}_In{input_dim}_harmonic.csv"
    #with open(log_file, "w", newline="") as f:
    #    writer = csv.writer(f)
    #    writer.writerow(["model_type", "graph_type", "d", "layers", "num_nodes", "epoch", "loss"])

    for epoch in range(epochs):
        badcount = 0
        for (model_type, d), model in models.items():
            model.train()
            opt = opts[(model_type, d)]
            opt.zero_grad()
            output = model(x)
            loss = F.mse_loss(output, y)
            loss.backward()
            opt.step()

            losses[(model_type, d)].append(loss.item())
            wandb.log({f"loss_{model_type}_d={d}": loss.item(), "epoch": epoch})

            percent = (epoch + 1) / epochs * 100
            print(f"[{model_type} | d={d}] Epoch {epoch+1}/{epochs} [{percent:.1f}%] - Loss: {loss.item():.6f}")

            #with open(log_file, "a", newline="") as f:
            #    writer = csv.writer(f)
            #    writer.writerow([model_type, graph_type, d, layers, num_nodes, epoch, loss.item()])

            if epoch > 10 and losses[(model_type, d)][-1] > losses[(model_type, d)][-2]-0.00001:
                badcount += 1

        if badcount == len(models) and epoch > early_stop:
            print(f"Early stopping at epoch {epoch}")
            break

    wandb.finish()

def run_all_experiments():
    graph_types = ["ER", "WS", "BA"]
    node_sizes = [50] #[50,100,200]
    layer_options = [2]

    total = len(graph_types) * len(node_sizes) * len(layer_options)
    count = 0

    for gtype in graph_types:
        for n in node_sizes:
            for l in layer_options:
                count += 1
                print("=" * 50)
                print(f"Running experiment {count}/{total}: graph={gtype}, nodes={n}, layers={l}")
                print("=" * 50)
                run_experiment(graph_type=gtype, num_nodes=n, layers=l)

if __name__ == "__main__":
    # 実験例
    run_all_experiments()

    #ER 100 エポックで0.0063  300 エポックで0.0062と十分小さくなっている　900エポックで0.0061
    #WS 0.0225で収束　　BA　0.0199~0.0198で収束
