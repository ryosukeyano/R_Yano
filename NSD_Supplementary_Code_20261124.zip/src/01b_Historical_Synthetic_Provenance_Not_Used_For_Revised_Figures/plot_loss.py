import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import glob

def load_all_loss_logs(log_dir="logs"):
    # loss_log_*.csv をすべて読み込む
    all_csv = glob.glob(os.path.join(log_dir, "loss_log_*.csv"))
    df_list = [pd.read_csv(f) for f in all_csv]
    if not df_list:
        raise RuntimeError("No CSV files found in logs/")
    df = pd.concat(df_list, ignore_index=True)
    return df

def plot_loss_curves_grouped(df, save_dir="plots", max_epoch=20):
    os.makedirs(save_dir, exist_ok=True)

    df = df[~(df["model_type"] == "DiagSheaf") ]
    df = df[~((df["model_type"] == "SimpleGNN") & (df["d"] != 1))]

    if 'param_str' not in df.columns:
        df['param_str'] = 'default_param'

    print(df.head())

    graph_types = df["graph_type"].unique()
    params =df["param_str"].unique()
    node_sizes = df["num_nodes"].unique()
    d_values = df["d"].unique()

    for gtype in graph_types:
        for param in params:
            for n in node_sizes:
                subdf = df[(df["graph_type"] == gtype) & (df["num_nodes"] == n)& (df["param_str"] == param)]

                if subdf.empty:
                    print(f"[SKIP] No data for graph={gtype}, nodes={n}")
                    continue

                # エポック数制限
                subdf = subdf[subdf["epoch"] <= max_epoch]

                subdf["label"] = subdf["model_type"] + "_d=" + subdf["d"].astype(str)

                plt.figure(figsize=(7, 5))
                sns.set(style="whitegrid")

                for label, group in subdf.groupby("label"):
                    plt.plot(group["epoch"], group["loss"], label=label)

                plt.title(f"{gtype}({param}) Graph (Nodes={n})")
                plt.xlabel("Epoch")
                plt.ylabel("Loss (MSE)")
                plt.xlim(0, max_epoch)
                plt.ylim(0, 1)
                plt.legend()
                plt.tight_layout()

                # Save as EPS file
                if 1:
                    filename = f"loss_curve_{gtype}_{param}_{n}_input_10.eps"
                    save_path = os.path.join(save_dir, filename)
                    plt.savefig(save_path, format="eps")
                    plt.close()
                    print(f"Saved: {save_path}")
                elif 0:
                    filename = f"loss_curve_{gtype}_{param}_{n}_input_10.png"
                    save_path = os.path.join(save_dir, filename)
                    plt.savefig(save_path, format="png", dpi=300)
                    plt.close()
                    print(f"Saved: {save_path}")



if __name__ == "__main__":
    df = load_all_loss_logs("logs/harmonic")
    plot_loss_curves_grouped(df, "figures/harmonic/epsfiles", max_epoch=20)