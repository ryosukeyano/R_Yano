import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import os
import csv
import wandb
import csv
import os
import numpy as np
import random
from models.disc_models import DiscreteBundleSheafDiffusion, DiscreteDiagSheafDiffusion
from exp.parser import get_parser




# ==== 比較用の簡易GNN ====
class SimpleLinearGNN(nn.Module):
    def __init__(self, input_dim, output_dim, d, layers):
        super().__init__()
        self.layers = nn.ModuleList()
        self.layers.append(nn.Linear(input_dim, d))
        for _ in range(layers - 1):
            self.layers.append(nn.Linear(d, d))
        self.out = nn.Linear(d, output_dim)

    def forward(self, x):
        for layer in self.layers:
            x = F.relu(layer(x))
        return self.out(x)

# ==== グラフ生成 & 図保存 ====
def generate_graph(graph_type, num_nodes, graph_params=None):
    graph_params = graph_params or {}
    if graph_type == "ER":
        p = graph_params.get("p", 0.3)
        G = nx.erdos_renyi_graph(num_nodes, p)
    elif graph_type == "WS":
        k = graph_params.get("k", 4)
        p = graph_params.get("p", 0.1)
        G = nx.watts_strogatz_graph(num_nodes, k, p)
    elif graph_type == "BA":
        m = graph_params.get("m", 3)
        G = nx.barabasi_albert_graph(num_nodes, m)
    else:
        raise ValueError(f"Unknown graph type: {graph_type}")

    if 0:
        os.makedirs("figures", exist_ok=True)
        param_str = "_".join(f"{k}{v}" for k, v in graph_params.items())
        fig_name = f"figures/{graph_type}_{param_str}_N{num_nodes}.png"
        plt.figure(figsize=(4, 4))
        pos = nx.spring_layout(G, seed=42)
        nx.draw(G, pos, node_size=30, node_color='skyblue', edge_color='gray', with_labels=False)
        plt.title(f"{graph_type} (N={num_nodes})")
        plt.tight_layout()
        plt.savefig(fig_name, dpi=150)
        plt.close()
        print(f"[Graph Saved] {fig_name}")

    return G


def run_experiment(graph_type, num_nodes, layers, graph_params=None):
    torch.manual_seed(0)
    np.random.seed(0)
    random.seed(0)

    d_values = [4,8]
    input_dim = 10
    output_dim = 1
    epochs = 1000
    early_stop = 1000
    lr = 0.02
    weight_decay = 5e-3
    device = torch.device("cpu")

    # グラフ生成とedge_index
    G = generate_graph(graph_type, num_nodes, graph_params)
    param_str = "_".join(f"{k}{v}" for k, v in graph_params.items())
    edge_index = torch.tensor(list(G.edges), dtype=torch.long).t().contiguous()
    swap_index = edge_index[[1, 0], :]
    edge_index = torch.cat([edge_index, swap_index], dim=1)

    x = torch.rand((num_nodes, input_dim))

    y = x.sum(dim=1, keepdim=True) + 0.1 * torch.randn(num_nodes, 1)
    if True:
        src, dst = edge_index
        y = torch.zeros_like(x)
        y.index_add_(0, dst, x[src]) 
        degrees = torch.tensor([G.degree[node] for node in range(num_nodes)], dtype=torch.float32).unsqueeze(1)
        y = y / degrees

    models = {}
    opts = {}
    losses = {}
    parser = get_parser()

    for d in d_values:
        model_args = parser.parse_args()
        model_args.graph_size = num_nodes
        model_args.input_dim = input_dim
        model_args.output_dim = output_dim
        model_args.d = d
        model_args.layers = layers
        model_args.device = device
        hidden_channnels = 16
        model_args.hidden_channels = hidden_channnels
        print(d)
        model_args = vars(model_args)
        print(model_args)
        if d == 1:
            model = DiscreteDiagSheafDiffusion(edge_index, model_args)
            model_name = "DiagSheaf"
        else:
            model = DiscreteBundleSheafDiffusion(edge_index, model_args)
            model_name = "BundleSheaf"

        models[(model_name, d)] = model.to(device)
        grouped_params = model.grouped_parameters()
        opts[(model_name, d)] = torch.optim.Adam([
            {'params': grouped_params[0], 'weight_decay': weight_decay},
            {'params': grouped_params[1], 'weight_decay': weight_decay},
        ], lr=lr)
        losses[(model_name, d)] = []

    # 通常のGNNモデルも追加
    model_name = "SimpleGNN"
    for d in [1]:
        model = SimpleLinearGNN(input_dim, output_dim, d, layers)
        models[(model_name, d)] = model.to(device)
        opts[(model_name, d)] = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
        losses[(model_name, d)] = []

    # wandb設定
    wandb.init(project="gnn_structure_comparison_hetero", name=f"{graph_type}_L{layers}_param{param_str}_N{num_nodes}_In{input_dim}_hidden{hidden_channnels}", config={
        "graph": graph_type,
        "layers": layers,
        "nodes": num_nodes
    })

    os.makedirs("logs", exist_ok=True)
    #log_file = f"logs/harmonic/eachparm/loss_log_{graph_type}_{param_str}_L{layers}_N{num_nodes}_In{input_dim}_harmonic.csv"
    #with open(log_file, "w", newline="") as f:
    #    writer = csv.writer(f)
    #    writer.writerow(["model_type", "graph_type","param_str", "d", "layers", "num_nodes", "epoch", "loss"])

    for epoch in range(epochs):
        badcount = 0
        for (model_type, d), model in models.items():
            model.train()
            opt = opts[(model_type, d)]
            opt.zero_grad()
            output = model(x)
            loss = F.mse_loss(output, y)
            loss.backward()
            opt.step()

            losses[(model_type, d)].append(loss.item())
            wandb.log({f"loss_{model_type}_d={d}": loss.item(), "epoch": epoch})

            percent = (epoch + 1) / epochs * 100
            print(f"[{model_type} | d={d}] Epoch {epoch+1}/{epochs} [{percent:.1f}%] - Loss: {loss.item():.6f}")

            #with open(log_file, "a", newline="") as f:
            #    writer = csv.writer(f)
            #    writer.writerow([model_type, graph_type, param_str,d, layers, num_nodes, epoch, loss.item()])

            if epoch>4 and  losses[(model_type, d)][-1] > losses[(model_type, d)][-2]-0.00001:
                badcount += 1

        if badcount == len(models) and epoch > early_stop:
            print(f"Early stopping at epoch {epoch}")
            break

    wandb.finish()



def run_all_experiments():
    graph_configs = {
        "ER": [{"p": 0.1}, {"p": 0.5}, {"p": 0.9}],
        "WS": [{"k": 4, "p": 0.1}, {"k": 6, "p": 0.2}],
        "BA": [{"m": 2}, {"m": 4}]
    }

    node_sizes = [50]
    layer_options = [2]

    total = sum(len(graph_configs[g]) for g in graph_configs) * len(node_sizes) * len(layer_options)
    count = 0

    for gtype, param_list in graph_configs.items():
        for graph_params in param_list:
            for n in node_sizes:
                for l in layer_options:
                    count += 1
                    print("=" * 50)
                    print(f"[{count}/{total}] {gtype} params={graph_params}, nodes={n}, layers={l}")
                    print("=" * 50)
                    run_experiment(graph_type=gtype, num_nodes=n, layers=l, graph_params=graph_params)

if __name__ == "__main__":
    run_all_experiments()


