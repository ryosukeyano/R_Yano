import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch_geometric.nn import GCNConv
from PeMSDdataloader import PeMSDdata
from exp.parser import get_parser
import time
import math
import csv

def MAE(v, v_, std):
    return np.mean(np.abs(std * (v_ - v)))

def MAPE(v, v_, M, std):
    v = std * v + M
    v_ = std * v_ + M
    return np.mean(np.abs(v_ - v) / np.abs(v))

def RMSE(v, v_, std):
    return np.sqrt(np.mean((std * (v_ - v)) ** 2))

def valuation(model, val_data, M, std, input_sequence_length=12, forecast_horizon=3, device='cpu'):
    model.eval()
    with torch.no_grad():
        MAEloss_total, MAPEloss_total, RMSEloss_total, count = 0, 0, 0, 0
        for j in range(val_data.size(1) - input_sequence_length - forecast_horizon):
            input_val = val_data[:, j:j + input_sequence_length].to(device)
            target_val = val_data[:, j + input_sequence_length:j + input_sequence_length + forecast_horizon].to(device)
            output = model(input_val)
            output_np = output.cpu().numpy()
            target_np = target_val.cpu().numpy()
            MAEloss_total += MAE(output_np, target_np, std)
            MAPEloss_total += MAPE(target_np, output_np, M, std)
            RMSEloss_total += RMSE(output_np, target_np, std)
            count += 1
        if count == 0:
            return 0, 0, 0
        return MAEloss_total / count, MAPEloss_total / count, RMSEloss_total / count

class GCNTimeSeries(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim, num_layers, edge_index):
        super().__init__()
        self.edge_index = edge_index
        self.convs = nn.ModuleList()
        self.convs.append(GCNConv(input_dim, hidden_dim))
        for _ in range(num_layers - 2):
            self.convs.append(GCNConv(hidden_dim, hidden_dim))
        self.convs.append(GCNConv(hidden_dim, output_dim))

    def forward(self, x):
        for i, conv in enumerate(self.convs):
            x = conv(x, self.edge_index)
            if i < len(self.convs) - 1:
                x = F.relu(x)
        return x

if __name__ == '__main__':
    parser = get_parser()
    args = parser.parse_args()
    args.hidden_channels = 16
    args.device = torch.device('cpu')
    print(f"Using device: {args.device}")
    # データの読み込み
    pemsd = PeMSDdata(sample=False)
    train, val, test = [d.to(args.device) for d in pemsd.separate_data()]
    edge_index = pemsd.edge_index.to(args.device)
    M = pemsd.train_mean.cpu().numpy().reshape(pemsd.num_nodes, 1)
    STD = pemsd.train_std.cpu().numpy().reshape(pemsd.num_nodes, 1)

    input_seq_len = 12
    forecast_horizon = 6
    epochs = args.epochs if hasattr(args, 'epochs') else 200
    early_stop_patience = 50

    model = GCNTimeSeries(input_dim=input_seq_len,
                          output_dim=forecast_horizon,
                          hidden_dim=args.hidden_channels,
                          num_layers=4,
                          edge_index=edge_index).to(args.device)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-3)
    criterion = nn.MSELoss()

    best_val_mae = float('inf')
    bad_counter = 0
    print(f"Training model with {input_seq_len} input sequence length and {forecast_horizon} forecast horizon...")
    for epoch in range(epochs):
        model.train()
        losses = []
        for j in range(train.size(1) - input_seq_len - forecast_horizon):
            input_train = train[:, j:j + input_seq_len]
            target_train = train[:, j + input_seq_len:j + input_seq_len + forecast_horizon]
            output = model(input_train)
            loss = criterion(output, target_train)
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            losses.append(loss.item())
            
            if j % 100 == 0:
                avg_loss = sum(losses) / len(losses)
                print(f"Epoch {epoch + 1}/{epochs}, Step {j}, Loss: {avg_loss:.4f}")
                if avg_loss < best_val_mae:
                    best_val_mae = avg_loss
                    bad_counter = 0
                else:
                    bad_counter += 1
                
        
        print(f"Epoch {epoch + 1}/{epochs} - Train Loss: {avg_loss:.4f} ")


        if bad_counter >= early_stop_patience:
            print(f"Early stopping at epoch {epoch + 1}")
            break

    test_mae, test_mape, test_rmse = valuation(model, test, M, STD, input_seq_len, forecast_horizon, args.device)
    print(f"\nTest MAE: {test_mae:.4f}, MAPE: {test_mape:.4f}, RMSE: {test_rmse:.4f}")
    # forcast_horizon = 3 Test MAE: 7.3802, MAPE: 0.1931, RMSE: 9.6490
    # forcast_horizon = 6 est MAE: 7.6523, MAPE: 0.1990, RMSE: 9.9870