import os
import sys
import torch
import torch.nn.functional as F
import torch.nn as nn
import torch_sparse
import numpy as np
from torchinfo import summary
# import matplotlib.pyplot as plt # グラフ描画が直接必要ない場合はコメントアウト可
import math
from torch import nn # 重複インポートなので片方削除可
from models.disc_models import DiscreteBundleSheafDiffusion,DiscreteDiagSheafDiffusion
from models.sheaf_base import SheafDiffusion # 未使用の可能性
from models.cont_models import DiagSheafDiffusion,BundleSheafDiffusion # 未使用の可能性
from exp.parser import get_parser
from PeMSDdataloader import PeMSDdata
import csv # CSVモジュールのインポート
import time # timeモジュールのインポート

#export PYTHONPATH="${PYTHONPATH}:/home/tomohiro/cording/python/neural-sheaf-diffusion"


class linearmodel(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(linearmodel, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.linear = nn.Linear(input_dim, output_dim)
    def forward(self, x):
        x =  self.linear(x)
        return x

def MAPE(v, v_,M,std):
    '''
    Mean absolute percentage error.
    :param v: np.ndarray or int, ground truth.
    :param v_: np.ndarray or int, prediction.
    :return: int, MAPE averages on all elements of input.
    '''
    v = std*v + M
    v_ = std*v_ + M
    #print(np.abs(v))
    return np.mean(np.abs(v_ - v) / (np.abs(v)))


def RMSE(v, v_,std):
    '''
    Mean squared error.
    :param v: np.ndarray or int, ground truth.
    :param v_: np.ndarray or int, prediction.
    :return: int, RMSE averages on all elements of input.
    '''
    return np.sqrt(np.mean((std*(v_ - v) )** 2))


def MAE(v, v_,std):
    '''
    Mean absolute error.
    :param v: np.ndarray or int, ground truth.
    :param v_: np.ndarray or int, prediction.
    :return: int, MAE averages on all elements of input.
    '''
    return np.mean(np.abs(std*(v_ - v)))



def valuation(model, val_data, M,std,input_sequence_length = 12, forecast_horizon=3, device='cpu'):
    model.eval()
    with torch.no_grad():
        MAEloss_total = 0
        MAPEloss_total = 0
        RMSEloss_total = 0
        count = 0

        for j in range(val_data.size(1) - input_sequence_length - forecast_horizon):
            input_val = val_data[:,j:j+input_sequence_length].to(device)
            target_val = val_data[:,j+input_sequence_length:j+input_sequence_length+forecast_horizon].to(device)
            output = model(input_val)
            output_np = output.cpu().numpy()
            target_np = target_val.cpu().numpy()

            MAEloss_total += MAE(output_np, target_np,std)
            MAPEloss_total += MAPE(target_np,output_np,M,std) # MAPEの引数順を修正 (target, prediction)
            RMSEloss_total += RMSE(output_np, target_np,std)
            count +=1
        
        if count == 0: # データが少なすぎてループが一度も回らない場合
            return 0,0,0

        return MAEloss_total/count, MAPEloss_total/count, RMSEloss_total/count


if __name__ == '__main__':
    # --- 初期設定 ---
    parser = get_parser()
    args = parser.parse_args()
    args.hidden_channels = 10

    # Weights & Biases ログイン (スクリプトの最初で一度だけ)
    try:
        import wandb
        wandb.login()
    except ImportError:
        print("wandb not installed, skipping wandb logging.")
        wandb = None # wandbがなくても実行できるようにダミーオブジェクトを設定

    # PeMSDデータロード
    pemsd = PeMSDdata(sample=False) # sample=Trueのままで良いか確認
    edge_index_orig = pemsd.edge_index # 元のedge_indexを保持 (ループ内でargs.deviceに送るため)
    
    # 訓練、検証、テストデータと正規化パラメータの取得
    train_orig, val_orig, test_orig = pemsd.separate_data()
    M_orig = pemsd.train_mean.cpu().numpy().reshape(pemsd.num_nodes, 1)
    STD_orig = pemsd.train_std.cpu().numpy().reshape(pemsd.num_nodes, 1)

    # --- 実験パラメータ ---
    d_options = [2,4]
    layers_options = [2, 4]
    
    epochs = args.epochs # argparseから取得 (なければデフォルト値)
    input_sequence_length = 12 # 固定値、またはargsから取得
    forecast_horizon = 12
     # 固定値、またはargsから取得
    early_stop_patience =100 # get_parserに定義があれば

    all_experiments_summary = []
    summary_csv_path = "summary_results.csv"

    # --- メインループ (dとlayersの組み合わせ) ---
    for current_d in d_options:
        for current_layers in layers_options:
            print(f"\n--- Running Experiment: d={current_d}, layers={current_layers} ---")
            start_time_exp = time.time()

            # --- ループごとのパラメータ設定 ---
            args.d = current_d
            args.layers = current_layers
            args.device = torch.device('cpu') # CPUで実行
            
            # データとedge_indexを現在のデバイスに送信
            # (データセット全体が大きい場合、ミニバッチごとに送る方が効率的だが、ここでは全体を送る)
            data = pemsd.data.to(args.device) 
            train = train_orig.clone().to(args.device)
            val = val_orig.clone().to(args.device)
            test = test_orig.clone().to(args.device)
            edge_index = edge_index_orig.clone().to(args.device)
            
            # MとSTDはnumpyなのでデバイス指定不要だが、一応コピーして使う
            M = np.copy(M_orig)
            STD = np.copy(STD_orig)
            #print(M,STD,train_orig.cpu().numpy().mean(),train_orig.cpu().numpy().std())

            args.graph_size = pemsd.num_nodes
            args.input_dim = input_sequence_length
            args.output_dim = forecast_horizon
            # args.hidden_channels = 1 # 必要に応じてargsから設定できるようにする

            if args.d == 1: # d=1は今回対象外だが、元のロジックを残す
                model_cls = DiscreteDiagSheafDiffusion
            else:
                model_cls = DiscreteBundleSheafDiffusion

            # --- CSVファイルの準備 ---
                if 0:
                    metrics_csv_filename = f"metrics_d{current_d}_layers{current_layers}.csv"
                    with open(metrics_csv_filename, 'w', newline='') as csvfile:
                        csv_writer = csv.writer(csvfile)
                        csv_header = ['step', 'avg_loss', 'MAE', 'MAPE', 'RMSE']
                        csv_writer.writerow(csv_header)
                csv_step_counter = 0

                # --- wandbの初期化 ---
                if wandb:
                    run_name = f"d{current_d}_l{current_layers}_edges{edge_index.size(1)}"
                    # wandb.configを更新するためにvars(args)を渡す
                    current_config = vars(args).copy() # 辞書としてコピー
                    wandb.init(project='nsd-pemsd_exp_5-24',
                               name=run_name,
                               config=current_config,
                               reinit=True) # ループ内で複数回呼び出すためreinit=True

                # --- モデルの構築 ---
                print("Constructing model...")
                print(vars(args)) # 現在のargsを確認
                model = model_cls(edge_index, vars(args)).to(args.device)
                # print(summary(model, input_size=(train.size(0), input_sequence_length))) # 必要ならコメント解除

                sheaf_learner_params, other_params = model.grouped_parameters()
                args.optimizer = 'grouped'
                if args.optimizer == 'grouped':
                    optimizer = torch.optim.Adam([        {'params': sheaf_learner_params, 'weight_decay': 5e-3},    {'params': other_params, 'weight_decay':5e-3}], lr=0.02) # parserで定義推奨
                else: # 'not_grouped' or other
                    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr if hasattr(args,'lr') else 0.001)


                criterion = nn.MSELoss()
                
                loss_history_for_avg = [] # 100バッチごとの平均損失計算用
                
                best_val_loss = float('inf') # MAE, MAPE, RMSEのどれを基準にするか、あるいは複合的な指標か
                best_val_MAE = float('inf')
                best_val_MAPE = float('inf')
                best_val_RMSE = float('inf')

                bad_counter = 0 # 早期終了用カウンタ
                # --- 訓練ループ ---
                print("Starting training...")
                for epoch in range(epochs):
                    model.train()
                    epoch_loss_sum = 0
                    epoch_batch_count = 0
                    bad_counter = 0 
                    for j in range(train.size(1) - input_sequence_length - forecast_horizon):
                        optimizer.zero_grad()
                        input_train = train[:,j:j+input_sequence_length]
                        target_train = train[:,j+input_sequence_length:j+input_sequence_length+forecast_horizon]
                        
                        output_train = model(input_train)
                        loss = criterion(output_train, target_train)
                        loss.backward()
                        optimizer.step()
                        
                        loss_history_for_avg.append(loss.item())
                        epoch_loss_sum += loss.item()
                        epoch_batch_count +=1

                        # 100バッチごとに評価とログ記録
                        if len(loss_history_for_avg) >= 50:
                            avg_loss_current_batch_set = sum(loss_history_for_avg) / len(loss_history_for_avg)
                            print(f"Epoch {epoch+1}, Step {csv_step_counter}, Avg Loss (last 100 batches): {avg_loss_current_batch_set:.4f}")
                            if wandb:
                                wandb.log({"Train Batch Loss Avg": avg_loss_current_batch_set, 
                                           "Train Batch LogLoss Avg": math.log(avg_loss_current_batch_set) if avg_loss_current_batch_set > 0 else -float('inf'),
                                           "step": csv_step_counter})

                            #val_MAE, val_MAPE, val_RMSE = valuation(model, val, M, STD, input_sequence_length, forecast_horizon, args.device)
                            #print(f"Validation: MAE={val_MAE:.4f}, MAPE={val_MAPE:.4f}, RMSE={val_RMSE:.4f}")
                            
                            #if wandb:
                                #wandb.log({"Val MAE": val_MAE, "Val MAPE": val_MAPE, "Val RMSE": val_RMSE, "step": csv_step_counter})
                            
                            # CSVに記録
                            #csv_writer.writerow([csv_step_counter, avg_loss_current_batch_set, val_MAE, val_MAPE, val_RMSE])
                            
                            loss_history_for_avg = [] # リストをクリア
                            csv_step_counter += 1

                            # 早期終了チェック (例: Val MAEを基準)
                            if avg_loss_current_batch_set  < best_val_MAE:
                                best_val_MAE = avg_loss_current_batch_set 
                                best_val_MAPE = 0 #val_MAPE 同時のMAPEとRMSEも保存
                                best_val_RMSE = 0 #val_RMSE
                                bad_counter = 0
                                # torch.save(model.state_dict(), f"best_model_d{current_d}_l{current_layers}.pth") # 必要ならベストモデル保存
                                if wandb:
                                    wandb.log({"Best Val MAE": best_val_MAE, 
                                               "Best Val MAPE at Best MAE": best_val_MAPE, 
                                               "Best Val RMSE at Best MAE": best_val_RMSE,
                                               "step": csv_step_counter})
                            else:
                                bad_counter += 1
                                print(f"Bad counter: {bad_counter}/{early_stop_patience}")
                        if bad_counter >= early_stop_patience:
                            print(f"Early stopping at epoch {epoch+1} due to no improvement for {early_stop_patience} validation steps.")
                            break
                    avg_epoch_loss = epoch_loss_sum / epoch_batch_count if epoch_batch_count > 0 else 0
                    print(f"Epoch {epoch+1}/{epochs} completed. Avg Epoch Training Loss: {avg_epoch_loss:.4f}")
                    if wandb:
                         wandb.log({"Epoch Avg Train Loss": avg_epoch_loss, "epoch": epoch + 1})
                    if bad_counter >= early_stop_patience or epoch > 3:
                        print(f"Early stopping at epoch {epoch+1} due to no improvement for {early_stop_patience} validation steps.")
                        break 
                
                # --- 訓練終了後の処理 ---
                print("Training finished for this configuration.")
                # 最終評価 (オプション: 最後の状態での評価値を記録する場合)
                #final_val_MAE, final_val_MAPE, final_val_RMSE = valuation(model, val, M, STD, input_sequence_length, forecast_horizon, args.device)
                test_MAE, test_MAPE, test_RMSE = valuation(model, test, M, STD, input_sequence_length, forecast_horizon, args.device)
                print(f"Test: MAE={test_MAE:.4f}, MAPE={test_MAPE:.4f}, RMSE={test_RMSE:.4f}")
                if wandb:
                    #wandb.log({"Final Val MAE": final_val_MAE, "Final Val MAPE": final_val_MAPE, "Final Val RMSE": final_val_RMSE})
                    wandb.log({"Test MAE": test_MAE, "Test MAPE": test_MAPE, "Test RMSE": test_RMSE})
                    # wandbに最終的なベストスコアを記録 (既にステップごとに記録されているが、サマリーとして最終値も記録)
                    wandb.summary['Best Val MAE'] = best_val_MAE
                    wandb.summary['Best Val MAPE'] = best_val_MAPE # これはMAEがベストだった時のMAPE
                    wandb.summary['Best Val RMSE'] = best_val_RMSE # これはMAEがベストだった時のRMSE
                
                # 結果サマリーに追加 (早期終了にかかわらず、その時点でのベストを記録)
                all_experiments_summary.append({
                    'd': current_d,
                    'layers': current_layers,
                    'Best_MAE': best_val_MAE,
                    'Best_MAPE': best_val_MAPE, # MAEがベストだった時のMAPE
                    'Best_RMSE': best_val_RMSE, # MAEがベストだった時のRMSE
                    'Final_Test_MAE': test_MAE,
                    'Final_Test_MAPE': test_MAPE,
                    'Final_Test_RMSE': test_RMSE,  
                    'training_duration_sec': time.time() - start_time_exp
                })

                if wandb:
                    wandb.finish() # 各実験のwandb runを終了
            # CSVファイルは 'with open' を抜けるときに自動的にクローズされる
            print(f"Experiment d={current_d}, layers={current_layers} took {time.time() - start_time_exp:.2f} seconds.")

    # --- テストデータでの評価 ---



    # --- 全実験終了後のサマリー出力 ---
    print("\n--- All Experiments Completed ---")
    print("Summary of results:")
    if not all_experiments_summary:
        print("No experiments were run or no results were collected.")
    else:
        # コンソール出力
        header = all_experiments_summary[0].keys()
        print(f"{' | '.join(str(x) for x in header)}")
        for row_dict in all_experiments_summary:
            print(f"{' | '.join(str(round(row_dict[key], 4) if isinstance(row_dict[key], float) else row_dict[key]) for key in header)}")

        # サマリーCSVファイルへの保存
        with open(summary_csv_path, 'w', newline='') as csvfile_summary:
            if all_experiments_summary: # リストが空でないことを確認
                writer = csv.DictWriter(csvfile_summary, fieldnames=header)
                writer.writeheader()
                writer.writerows(all_experiments_summary)
        print(f"Summary of results saved to {summary_csv_path}")