import csv
import numpy as np
import networkx as nx
import torch
import torchvision.models as models
from models.disc_models import DiscreteBundleSheafDiffusion
from torchinfo import summary
from exp.parser import get_parser
from utils.heterophilic import get_dataset
import sys
#export PYTHONPATH="${PYTHONPATH}:/home/tomohiro/cording/python/neural-sheaf-diffusion"
sample_routes = [
    0,
    1,
    4,
    7,
    8,
    11,
    15,
    108,
    109,
    114,
    115,
    118,
    120,
    123,
    124,
    126,
    127,
    129,
    130,
    132,
    133,
    136,
    139,
    144,
    147,
    216,
]

sample_routes = [3, 5, 6, 9, 10, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 43, 44, 45, 46, 47, 48, 50, 54, 57, 63, 66, 67, 69, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 90, 91, 93, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 131, 140, 141, 142, 143, 145, 146, 148]


def read_csv_as_matrix(file_path):
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        data = list(reader)
        matrix = np.array(data, dtype=np.float32)
    return matrix

def compute_adjacency_matrix(
    route_distances: np.ndarray, sigma2: float, epsilon: float
):
    num_routes = route_distances.shape[0]
    route_distances = route_distances / 10000.0
    w2, w_mask = (
        route_distances * route_distances,
        np.ones([num_routes, num_routes]) - np.identity(num_routes),
    )
    return (np.exp(-w2 / sigma2) >= epsilon) * w_mask

class PeMSDdata():
    def __init__(
            self,weightpath =  '/home/tomohiro/cording/python/neural-sheaf-diffusion/datasets/PeMSD7/PeMSD7_W_228.csv',
            datapath = '/home/tomohiro/cording/python/neural-sheaf-diffusion/datasets/PeMSD7/PeMSD7_V_228.csv',
            sample = True):
        self.weightpath = weightpath
        self.datapath = datapath
        matrix = read_csv_as_matrix(weightpath)
        D = read_csv_as_matrix(datapath)
        sigma2 = 0.1
        epsilon = 0.5
        if sample == True:
            matrix = matrix[np.ix_(sample_routes, sample_routes)]
            D =D[:,sample_routes]
        self.adjacency_matrix = compute_adjacency_matrix(matrix, sigma2, epsilon)
        self.G = nx.from_numpy_array(self.adjacency_matrix)
        edge_index = torch.tensor(list(self.G.edges)).t().contiguous()
        swap_edge_index = edge_index[[1, 0], :]
        self.edge_index = torch.cat([edge_index, swap_edge_index], dim=1)
        self.data = torch.tensor(D).t()
        self.num_nodes = len(self.G.nodes)
    def separate_data(self):
        N = self.data.size(1)
        train = self.data[:,:int(0.7 *N)]
        val = self.data[:,int(0.7 * N):int(0.85 * N)]
        test = self.data[:,int(0.85 * N):]
        train_mean = torch.zeros_like(torch.mean(train, dim=1)) #torch.mean(train, dim=1)
        train_std = torch.ones_like(torch.std(train, dim=1)) #torch.std(train, dim=1)
        self.train_mean = train_mean
        self.train_std = train_std
        #print(train.shape, val.shape, test.shape)
        #print(train_mean.shape,train_std.shape)
        train = (train - train_mean[:, None]) / train_std[:, None]
        val = (val - train_mean[:, None]) / train_std[:, None]
        test = (test - train_mean[:, None]) / train_std[:, None]
        self.train = train
        self.val = val
        self.test = test
        return train, val, test
    def get_density(self):
        self.max_value, _ = torch.max(self.data, dim=1)
        self.min_value, _ = torch.min(self.data, dim=1)
        self.max_value = self.max_value.reshape(-1, 1)
        self.min_value = self.min_value.reshape(-1, 1)
        density = (-self.data + self.max_value) / (self.max_value - self.min_value)
        self.density  = density
        return density
    def separate_density(self):
        self.get_density()
        N = self.data.size(1)
        train = self.density[:,:int(0.7 *N)]
        val = self.density[:,int(0.7 * N):int(0.85 * N)]
        test = self.density[:,int(0.85 * N):]
        train_mean = torch.mean(train, dim=1)
        train_std = torch.std(train, dim=1)
        self.density_train_mean = train_mean
        self.density_train_std = train_std
        train = (train - train_mean[:, None]) / train_std[:, None]
        val = (val - train_mean[:, None]) / train_std[:, None]
        test = (test - train_mean[:, None]) / train_std[:, None]
        return train, val, test




if __name__ == '__main__':
    #torch.set_printoptions(edgeitems=3, threshold=10000)
    sys.path.append('/home/tomohiro/cording/python/neural-sheaf-diffusion')
    # Load data
    print("Loading data...")


    #weight_path = '/home/tomohiro/cording/python/neural-sheaf-diffusion/datasets/PeMSD7/PeMSD7_W_1026.csv'
    #data_path = '/home/tomohiro/cording/python/neural-sheaf-diffusion/datasets/PeMSD7/PeMSD7_V_1026.csv'

    pemsd = PeMSDdata()
    # Load model
    model_cls =  DiscreteBundleSheafDiffusion
    parser = get_parser()
    args = parser.parse_args()
    args.graph_size = pemsd.num_nodes
    args.input_dim = pemsd.data.size(1)
    args.output_dim = 20
    args.device = torch.device(f'cuda:{args.cuda}' if torch.cuda.is_available() else 'cpu')
    args.layers = 1
    print(args)

    data = pemsd.data.to(args.device)
    train, val, test = pemsd.separate_data()
    #print(pemsd.adjacency_matrix.shape)
    #print(data.shape)
    print("train size",train.shape)


    #print(data.edge_index)
    #print(pemsd.edge_index.size())
    #print(pemsd.edge_index[[1, 0], :].to(args.device))
    #pedge_index = pemsd.edge_index
    #swap_index = pemsd.edge_index[[1, 0], :].to(args.device)
    #e_index = torch.cat([pedge_index,swap_index],dim=1)
    #print(e_index,e_index.size())
    #print(type(pemsd.edge_index),pemsd.edge_index.shape)
    #print(pemsd.edge_index.size(1),pemsd.edge_index[0,10])
    #print(type(data.edge_index),data.edge_index.shape)
    #print(type(data.x),data.x.shape) # torch.Size([183, 1703])

    model = model_cls(pemsd.edge_index,vars(args)).to(args.device)
    print(summary(model, input_size=(pemsd.data.size(0),pemsd.data.size(1))))
    print(pemsd.data.size())
    print(model(pemsd.data)[0].shape)
    #model.print_edge_index()

