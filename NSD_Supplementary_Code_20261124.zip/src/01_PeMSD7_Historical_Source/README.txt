NSD (Neural Sheaf Diffusion) 数値実験コード一式 — PHYSD-D-26-01887 改訂用
作成: 軽部 (2026-11-21)
保存されていたファイルをそのまままとめたものです。再計算はしていません。

========================================================================
1. PeMSD7 (Table 2)
========================================================================
データ: PeMSD7_V_228.csv / PeMSD7_W_228.csv
  （同梱していません。https://github.com/VeritasYin/STGCN_IJCAI-18 から入手）
  コード内のパスは /home/tomohiro/... の絶対パスになっているので、実行する場合は書き換えが必要です。

[Table 2 の値と結果ファイルの対応]
  15分 NSD (d=2, l=2/4)  … visualizations/summary_results_d2.csv     （Final_Test_* 列）
  15分 NSD (d=4, l=2/4)  … visualizations/summary_results_d4.csv
  45分 NSD (全4行)       … visualizations/summary_results_forcast_45.csv
  （参考）60分 NSD       … visualizations/summary_results_forcast60.csv（論文では未使用）
  GCN 15分 / 45分        … runpemsdGCN.py の末尾コメントに記録された値
  STGCN                  … 元論文 [8] の値を転記（再計算なし）
  MAPE は CSV では比率（0.0509 = 5.09%）。Best_MAE 列は訓練損失の最小値で、評価指標ではありません。

[実行時のコード]
  すべて 2025-05-24 に実行。VS Code の編集履歴から、実行時の版を取り出しました。
  visualizations/history_versions/
    runpemsdexp_20250524_1351_15min_d2.py     → summary_results_d2.csv
    runpemsdexp_20250524_1544_15min_d4.py     → summary_results_d4.csv
    runpemsdexp_20250524_1723_45min_9steps.py → summary_results_forcast_45.csv
    runpemsdexp_20250524_1759_60min_12steps.py→ summary_results_forcast60.csv
    runpemsdGCN_20250524_1937_15min_3steps.py → GCN 15分
    disc_models_20250524_1654.py              → 上記すべての実行時のモデル定義
                                                （models/disc_models.py と同一。差分は import sys のみ）
  visualizations/runpemsdexp.py / runpemsdGCN.py は最終保存版です（d=[1] / 6 steps の設定のまま）。

[実験条件]
                       15分 (d2, d4)            45分 / 60分
  予測ステップ数       3 (=15分)                9 (=45分) / 12 (=60分)
  入力                 過去12ステップ（1時間）   同左
  hidden_channels      20 (parser の既定値)      10
  エポック             上限1500、早期終了あり    最大5エポック (epoch > 3 で打ち切り)
  最適化               Adam, lr=0.02, weight_decay=5e-3（sheaf learner とその他の両方）
  損失                 MSE
  活性化               ELU（層内と出力層 lin2 の後の両方）
  早期終了             訓練損失の50ステップ平均で判定（patience 100）。検証データでは判定していない
  データ分割           時系列順に train 70% / val 15% / test 15%
  正規化               なし（train_mean=0, train_std=1 に固定）
  グラフ               PeMSD7_W_228 から exp(-(w/10000)^2/0.1) >= 0.5 で隣接行列を作成（重みは学習で無視）
  乱数シード           固定していない
  評価                 テストデータ上で、予測窓全体（1〜Tステップ先）の平均 RMSE / MAE / MAPE
                       ※STGCN の論文はホライズン時点の1点だけを評価しているので、定義が異なる

  GCN baseline: GCNConv 4層, hidden 16, ReLU, Adam lr=0.01, weight_decay=5e-3。
                15分 = 3 steps、Table 2 の「45分」の列 = 6 steps（実際は30分）。

[モデル構造 (models/disc_models.py: DiscreteBundleSheafDiffusion)]
  N: ノード数, d: stalk 次元, h: hidden_channels, T: 予測ステップ数
  1) X (N x 12) → lin1 (12 → h*d) → ELU → (N*d) x h に並べ替え
  2) 各層: Z = ELU( Δ_F · (I_N ⊗ W_L) · X · W_R ),  X ← (1 + tanh ε) ⊙ X − Z
       W_R: h x h（バイアスなし、直交初期化）、W_L: d x d（単位行列で初期化）、ε: d x 1（学習可能）
       制限写像は各層で学習（LocalConcatSheafLearner, tanh, Householder 直交化）、エッジ重みも学習
  3) N x (d*h) に並べ替え → lin2 (d*h → T) → ELU

========================================================================
2. 合成実験 (ER / BA / WS)
========================================================================
  visualizations/gnn_experiment_runner.py   グラフ種別ごとの実験
  visualizations/gnn_exp_each_param.py      パラメータ (p, m, k) を変えた実験
  visualizations/plot_loss.py               損失曲線の作図
  visualizations/logs/                      学習履歴（harmonic/ は graph-smoothed target）
  visualizations/figures/                   出力図（each_param/, harmonic/ を含む）
  シード: torch / numpy / random とも 0、input_dim=10, output_dim=1, epochs=1000, lr=0.02
  ※この2つのスクリプトは最後の編集がコミットされていない状態のものです。
    論文の図を作った時点の版と完全に同じかは確認できていません。

========================================================================
3. その他
========================================================================
  visualizations/metrics/    2025-05-14 時点の 15分の実験（d=2,4,6）の学習履歴（Table 2 の前の試行）
  visualizations/csvfiles/   PeMSD7 の予測出力（2024年の試行。Figure 12 の元データの可能性あり、未確認）
  figures_pemsd/             2024年の PeMSD7 関連の図
  models/ lib/ utils/ exp/   Bodnar et al. の NSD 実装をベースにしたモデル本体

  入れていないもの:
    - PeMSD7 データ（公開データ）
    - wandb ログ
    - 学習済みの重み（Table 2 の実験の重みは保存していません）
    - Table 1 の計算コード（手元で見つかりませんでした）
