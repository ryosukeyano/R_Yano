@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
"%NSD_PYTHON%" plot_combined_fig5to11_tight.py --strict --output-dir composite_figures_new_titles
if errorlevel 1 (
  echo ERROR: Required saved loss CSV or conditions are missing. No training was started.
  exit /b 1
)
echo Completed: composite_figures_new_titles
endlocal
