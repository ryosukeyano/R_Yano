# 2026-11-21 GPU環境保護・軽部君確認結果反映

- CPU版PyTorchの自動インストールBATを廃止。新パッケージにpip/conda実行処理なし。
- 既存GPU環境をチェックする `check_gpu_environment.py` とGPU実行BATを導入。CUDA不可なら停止。
- 実際の歴史的なグラフ非依存目標を `feature_sum_noise` として復元（入力Xには依存）。
- グラフ平滑化目標は論文通りN×1、損失でのbroadcast禁止。
- 旧`GNN`=MLPという本人確認を反映。比較用の本当のGCNを別に実装（以前の版と同じ）。
- 元のNSDモデル・Laplacian・Householder構成は未改変。portable演算は元モデルの依存ライブラリ置換にすぎず、厳密な軌道一致は保証しない。
- 元のCPU版ZIPは新パッケージに含めず、GPUチェックに失敗してもインストールは開始しない。
