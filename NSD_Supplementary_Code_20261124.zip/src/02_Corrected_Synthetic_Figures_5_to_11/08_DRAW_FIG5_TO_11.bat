@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Rendering paper-matching Figure 5-11 grids from saved corrected loss CSVs.
echo No PyTorch or CUDA packages are modified.
"%NSD_PYTHON%" plot_paper_figures_5_11.py --roots results_ALL_GPU results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU results_COMPARE_GPU --output-dir figures_5_to_11_corrected --layers 2 --seed 0 --ranks 2,4,6,8 --full-epochs
if errorlevel 1 goto :failed
echo.
echo Check figures_5_to_11_corrected\FIGURE_COVERAGE.csv for missing panels.
echo DRAFT_* files must NOT be included in a manuscript.
pause
exit /b 0
:failed
echo.
echo Figure rendering failed. Input data were not modified.
pause
exit /b 1
