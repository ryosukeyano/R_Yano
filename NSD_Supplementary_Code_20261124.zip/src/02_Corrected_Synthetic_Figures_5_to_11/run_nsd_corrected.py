#!/usr/bin/env python3
"""ER / BA / WS NSD recalculation using Karube's original NSD classes.

Corrections are deliberately confined to the *experiment runner*:
  * historical graph-independent local-feature-sum target X.sum(axis=1)+0.1*noise,
  * optional fully independent random target for separate ablation,
  * graph-smoothed target N x 1 = degree-normalized sum of all 10
    neighbor feature channels (not N x 10 broadcast MSE),
  * legacy SimpleGNN is not called a GCN; optional real GCN baseline,
  * all ranks share the same graph, input and target within a case,
  * seed/parameters/logs/checkpoints are recorded.
No changes to Karube's DiscreteBundleSheafDiffusion, learners or builders.
"""
from __future__ import annotations
import argparse
import csv
import dataclasses
import hashlib
import json
import math
import os
import random
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'karube_original'


def parse_ints(s):
    return [int(v.strip()) for v in s.split(',') if v.strip()]


def parse_strs(s):
    return [v.strip() for v in s.split(',') if v.strip()]


def cli():
    p=argparse.ArgumentParser(description='Corrected NSD synthetic experiments (Karube source unchanged)')
    p.add_argument('--preset', choices=['smoke','base','sweeps','smoothed','paper_all','custom'],default='base')
    p.add_argument('--graph',choices=['ER','BA','WS'],default='ER',help='For custom preset')
    p.add_argument('--nodes',type=str,default='50',help='For custom preset: e.g. 10,50,100,300')
    p.add_argument('--er-p',type=float,default=0.1)
    p.add_argument('--ba-m',type=int,default=2)
    p.add_argument('--ws-k',type=int,default=4)
    p.add_argument('--ws-p',type=float,default=0.1)
    p.add_argument('--tasks',type=str,default='feature_sum_noise,smoothed',help='feature_sum_noise,smoothed; independent is optional new ablation')
    p.add_argument('--ranks',type=str,default='2,4,6,8')
    p.add_argument('--layers',type=int,default=2,help='Legacy logs used 2; manuscript description said 1')
    p.add_argument('--hidden',type=int,default=0,help='0 = original runner default: 20(base), 16(sweeps)')
    p.add_argument('--epochs',type=int,default=1000)
    p.add_argument('--seeds',type=str,default='0')
    p.add_argument('--lr',type=float,default=0.02)
    p.add_argument('--weight-decay',type=float,default=0.005)
    p.add_argument('--patience',type=int,default=0,help='0 disables early stopping (legacy 1000 epochs)')
    p.add_argument('--min-improvement',type=float,default=1e-5)
    p.add_argument('--backend',choices=['portable','native'],default='portable')
    p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    p.add_argument('--baselines',choices=['none','gcn','mlp','both'],default='none')
    p.add_argument('--baseline-hidden',type=int,default=16)
    p.add_argument('--isolate-policy',choices=['zero','reject'],default='zero',help='zero: target Y_i=0 for isolated nodes (explicit extension)')
    p.add_argument('--output-dir',type=str,default='results_nsd_corrected')
    p.add_argument('--checkpoint-every',type=int,default=50)
    p.add_argument('--print-every',type=int,default=25)
    p.add_argument('--resume',action='store_true')
    p.add_argument('--exclude-base-smoothed',action='store_true',
                   help='Only for --preset smoothed: omit 6 smoothed graph specs (24 rank runs) already in BASE_GPU at N=50/100, hidden=20')
    p.add_argument('--plan-only',action='store_true')
    p.add_argument('--fail-fast',action='store_true')
    p.add_argument('--no-plots',action='store_true')
    p.add_argument('--threads',type=int,default=4)
    return p.parse_args()


def preset_specs(args):
    """Return (family,N,params,task,hidden) sorted unique specs; rank/seed/layers separate."""
    tasks=parse_strs(args.tasks)
    if any(t not in ('feature_sum_noise','independent','smoothed') for t in tasks):
        raise ValueError('--tasks must use feature_sum_noise,independent,smoothed')
    out=[]
    def add(fam, Ns, params, sub_tasks, hidden):
        for n in Ns:
            for param in params:
                for task in sub_tasks:
                    out.append((fam,int(n),dict(param),task, int(args.hidden or hidden)))
    if args.preset=='smoke':
        add('BA',[10],[dict(m=2)],['smoothed'],8)
    if args.preset in ('base','paper_all'):
        add('ER',[10,50,100,300],[dict(p=0.1)],tasks,20)
        add('BA',[10,50,100,300],[dict(m=2)],tasks,20)
        add('WS',[10,50,100,300],[dict(k=4,p=0.1)],tasks,20)
    if args.preset in ('sweeps','paper_all'):
        add('ER',[10,50,100,300],[dict(p=x) for x in [0.1,0.3,0.5,0.7,0.9]],['feature_sum_noise'],16)
        add('BA',[10,50,100,300],[dict(m=x) for x in [2,4]],['feature_sum_noise'],16)
        add('WS',[10,50,100,300],[dict(k=4,p=0.1),dict(k=6,p=0.2)],['feature_sum_noise'],16)
    if args.preset in ('smoothed','paper_all'):
        add('ER',[50,100,200],[dict(p=0.1)],['smoothed'],20)
        add('BA',[50,100,200],[dict(m=2)],['smoothed'],20)
        add('WS',[50,100,200],[dict(k=4,p=0.1)],['smoothed'],20)
        add('ER',[50],[dict(p=x) for x in [0.1,0.5,0.9]],['smoothed'],16)
        add('BA',[50],[dict(m=2),dict(m=4)],['smoothed'],16)
        add('WS',[50],[dict(k=4,p=0.1),dict(k=6,p=0.2)],['smoothed'],16)
    if args.preset=='custom':
        cfg={'ER':dict(p=args.er_p),'BA':dict(m=args.ba_m),'WS':dict(k=args.ws_k,p=args.ws_p)}
        add(args.graph,parse_ints(args.nodes),[cfg[args.graph]],tasks,20)
    unique={}
    for s in out:
        key=json.dumps(s,sort_keys=True,ensure_ascii=False)
        unique[key]=s
    specs = list(unique.values())
    if args.exclude_base_smoothed:
        if args.preset != 'smoothed':
            raise ValueError('--exclude-base-smoothed is only supported with --preset smoothed')
        # 02_RUN_BASE_GPU.bat already computes these six h=20, N=50/100,
        # smoothed specs for 4 ranks: 6 graph configs x 4 ranks = 24 runs.
        # Do NOT remove h=16 N=50 sweep variants: although graph params
        # can match, the hidden width is different and must be trained.
        base_keys = {
            ('ER', 0.1), ('BA', 2), ('WS', (4, 0.1))
        }
        def covered_by_base(spec):
            family, n, pars, task, hidden = spec
            if task != 'smoothed' or hidden != 20 or n not in (50, 100):
                return False
            key = (family, pars['p'] if family == 'ER' else
                   pars['m'] if family == 'BA' else (pars['k'], pars['p']))
            return key in base_keys
        retained = [s for s in specs if not covered_by_base(s)]
        omitted = len(specs) - len(retained)
        if len(specs) != 16 or omitted != 6 or len(retained) != 10:
            raise RuntimeError(
                f'Unexpected smoothed grid: total={len(specs)}, omitted={omitted}, retained={len(retained)}. '
                'Refusing to run; review the presets before changing overlap exclusions.'
            )
        print('SMOOTHED-ONLY PLAN: 6 specs (24 NSD rank runs) covered by BASE_GPU excluded; '
              '10 specs (40 rank runs) remain for ranks 2,4,6,8.', flush=True)
        specs = retained
    return specs


def tag(family,n,params,task,hidden,seed,layers):
    ps='_'.join(k+str(v).replace('.','p') for k,v in sorted(params.items()))
    return f'{family}_{ps}_N{n}_{task}_h{hidden}_L{layers}_seed{seed}'


def seed_everything(seed,torch):
    random.seed(seed)
    import numpy as np
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def model_options(torch,n,d,layers,hidden,device):
    # Exact defaults of original exp/parser.py, restricted to DiscreteBundleSheafDiffusion.
    return dict(
        graph_size=n,input_dim=10,output_dim=1,d=d,layers=layers,device=device,
        hidden_channels=hidden,normalised=True,deg_normalised=False,linear=False,
        input_dropout=0.0,dropout=0.0,left_weights=True,right_weights=True,
        add_lp=False,add_hp=False,use_act=True,second_linear=False,
        orth='householder',sheaf_act='tanh',edge_weights=True,sparse_learner=False,
        max_t=1.0
    )


def generate_data(family,n,params,seed,task,isolate_policy,torch,nx,device):
    if family=='ER':
        g=nx.erdos_renyi_graph(n,params['p'],seed=seed)
    elif family=='BA':
        g=nx.barabasi_albert_graph(n,params['m'],seed=seed)
    elif family=='WS':
        g=nx.watts_strogatz_graph(n,params['k'],params['p'],seed=seed)
    else:
        raise ValueError(family)
    if g.number_of_edges()==0:
        raise ValueError('Graph has zero edges; do not silently substitute a different graph.')
    undirected=sorted((int(min(u,v)),int(max(u,v))) for u,v in g.edges())
    edge_one=torch.tensor(undirected,dtype=torch.long,device=device).T.contiguous()
    edge_index=torch.cat([edge_one,edge_one.flip(0)],dim=1)
    seed_everything(seed,torch)
    x=torch.rand(n,10,device=device)
    deg=torch.tensor([g.degree(i) for i in range(n)],dtype=x.dtype,device=device)
    isolate_count=int((deg==0).sum().item())
    if task=='feature_sum_noise':
        # Confirmed by Karube on 2026-11-21 to be the historical target used for Figs 5-8.
        # Graph-independent conditional on X, but NOT independent of the input.
        y=x.sum(dim=1,keepdim=True)+0.1*torch.randn(n,1,device=device)
    elif task=='independent':
        # New optional ablation; NOT the historical synthetic task.
        y=torch.rand(n,1,device=device)
    elif task=='smoothed':
        if isolate_count and isolate_policy=='reject':
            raise ValueError(f'{isolate_count} isolated vertices; Yi in paper undefined. Use --isolate-policy zero explicitly.')
        neighbors=torch.zeros(n,10,dtype=x.dtype,device=device)
        src,dst=edge_index
        neighbors.index_add_(0,dst,x[src])
        y=(neighbors.sum(dim=1,keepdim=True)/deg.clamp(min=1).unsqueeze(1))
        if isolate_count:
            y[deg==0,:]=0.0
    else: raise ValueError(task)
    if tuple(y.shape)!=(n,1): raise AssertionError(f'TARGET SHAPE ERROR: {tuple(y.shape)} vs {(n,1)}')
    if not torch.isfinite(y).all(): raise AssertionError('non-finite targets')
    return g,edge_index,x,y,isolate_count,undirected


def create_baseline_models(torch,edge_index,n,input_dim,hidden,layers,device,which,seed):
    nn=torch.nn
    adj=torch.zeros(n,n,dtype=torch.float32,device=device)
    src,dst=edge_index
    adj[src,dst]=1.
    adj=adj+torch.eye(n,device=device)
    degree=adj.sum(dim=1)
    adj=degree.rsqrt()[:,None]*adj*degree.rsqrt()[None,:]
    class Base(nn.Module):
        def __init__(self,use_graph):
            super().__init__(); self.use_graph=use_graph
            widths=[input_dim]+[hidden]*layers+[1]
            self.layers=nn.ModuleList([nn.Linear(a,b) for a,b in zip(widths[:-1],widths[1:])])
            if use_graph: self.register_buffer('graph_operator',adj)
        def forward(self,x):
            for l in self.layers[:-1]:
                if self.use_graph: x=self.graph_operator@x
                x=torch.nn.functional.relu(l(x))
            if self.use_graph: x=self.graph_operator@x
            return self.layers[-1](x)
    outs={}
    if which in ('gcn','both'):
        seed_everything(seed,torch)
        outs['GCN_graph_using']=Base(True).to(device)
    if which in ('mlp','both'):
        seed_everything(seed,torch)
        outs['MLP_graph_blind']=Base(False).to(device)
    return outs


def atomically_save(torch,path,data):
    temp=path.with_suffix('.tmp')
    torch.save(data,temp)
    os.replace(temp,path)


def save_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')


def save_rows_csv(path,rows,fields):
    tmp=path.with_suffix('.tmp')
    with tmp.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    os.replace(tmp,path)


def plot_curves(folder,curves):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(8.0,4.5))
        for name,values in curves.items():
            ax.plot(range(1,len(values)+1),values,label=name,lw=1.25)
        ax.set_yscale('log');ax.set_xlabel('Epoch');ax.set_ylabel('Training MSE')
        ax.legend(fontsize=8,ncol=2);ax.grid(alpha=.25);fig.tight_layout()
        fig.savefig(folder/'loss.png',dpi=170)
        fig.savefig(folder/'loss.eps')
        plt.close(fig)
    except ImportError:
        pass


def run_one(args, torch,nx,case,out_root,all_summary):
    fam,n,params,task,hidden,seed=case
    case_id=tag(fam,n,params,task,hidden,seed,args.layers)
    folder=out_root/case_id;folder.mkdir(parents=True,exist_ok=True)
    done_file=folder/'completed.json'
    completion_config=dict(epochs=args.epochs,lr=args.lr,weight_decay=args.weight_decay,
                           ranks=parse_ints(args.ranks),baselines=args.baselines,backend=args.backend,
                           isolate_policy=args.isolate_policy,baseline_hidden=args.baseline_hidden)
    if done_file.exists() and args.resume:
        old=json.loads(done_file.read_text(encoding='utf-8'))
        if old.get('configuration')!=completion_config:
            raise ValueError(f'Completed case has different run settings: {case_id}; use a different --output-dir')
        print('[SKIP completed]',case_id,flush=True)
        fam,n,params,task,hidden,seed=case
        all_summary.extend(dict(case=case_id,family=fam,N=n,task=task,layers=args.layers,seed=seed,**model_row)
                           for model_row in old['models'])
        return

    device = torch.device('cuda' if args.device=='auto' and torch.cuda.is_available() else args.device if args.device!='auto' else 'cpu')
    if device.type=='cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA unavailable; GPU setup is unchanged. Activate the existing CUDA-enabled Python environment. No CPU fallback.')
    seed_everything(seed,torch)
    g,edge_index,x,y,isolate_count,edges=generate_data(fam,n,params,seed,task,args.isolate_policy,torch,nx,device)
    torch.save({'x':x.detach().cpu(),'y':y.detach().cpu(),'edge_index':edge_index.detach().cpu()},folder/'graph_and_xy.pt')
    save_json(folder/'case.json',dict(family=fam,N=n,parameters=params,task=task,hidden_channels=hidden,
                      layers=args.layers,seed=seed,epochs=args.epochs,lr=args.lr,weight_decay=args.weight_decay,
                      backend=args.backend,device=str(device),num_edges=g.number_of_edges(),
                      isolates=isolate_count,graph_connected=nx.is_connected(g),
                      target_shape=list(y.shape),target_semantics=(
                      'Y_i = sum_(q=1..10) X_iq + 0.1 * N(0,1), independent of GRAPH but dependent on X' if task=='feature_sum_noise' else
                      'Y is sampled independent Uniform[0,1) per vertex (new ablation)' if task=='independent' else
                      'Y_i=sum_(j~i)sum_(q=1..10) X_jq / deg(i); isolates are zero by explicit policy'),
                      isolate_policy=args.isolate_policy))
    with (folder/'undirected_edges.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['u','v']);w.writerows(edges)

    from models.disc_models import DiscreteBundleSheafDiffusion
    specs=[(f'NSD_rank{d}', d) for d in parse_ints(args.ranks)]
    if any(d<=1 for _,d in specs):
        raise ValueError('d=1 original DiscreteDiagSheafDiffusion returns log_softmax and is invalid with one regression output; use d>=2')
    result_rows=[];curves={}
    for name,d in specs:
        # Fresh initialization per model; same data and graph across ranks.
        seed_everything(seed,torch)
        options=model_options(torch,n,d,args.layers,hidden,device)
        model=DiscreteBundleSheafDiffusion(edge_index,options).to(device)
        p1,p2=model.grouped_parameters()
        opt=torch.optim.Adam([{'params':p1,'weight_decay':args.weight_decay},
                               {'params':p2,'weight_decay':args.weight_decay}],lr=args.lr)
        row=train_model(args,torch,folder,name,model,opt,x,y,seed)
        result_rows.append(row);curves[name]=row.pop('__curve')

    if args.baselines!='none':
        seed_everything(seed,torch)
        baselines=create_baseline_models(torch,edge_index,n,10,args.baseline_hidden,args.layers,device,args.baselines,seed)
        for name,model in baselines.items():
            seed_everything(seed,torch)
            opt=torch.optim.Adam(model.parameters(),lr=args.lr,weight_decay=args.weight_decay)
            row=train_model(args,torch,folder,name,model,opt,x,y,seed)
            result_rows.append(row);curves[name]=row.pop('__curve')

    if not args.no_plots:plot_curves(folder,curves)
    save_rows_csv(folder/'summary.csv',result_rows,['name','parameters','training_mse_final','training_mse_best','best_epoch','epochs_completed','elapsed_seconds','checkpoint'])
    save_json(done_file,{'case':case_id,'models':result_rows,'configuration':completion_config})
    all_summary.extend(dict(case=case_id,family=fam,N=n,task=task,layers=args.layers,seed=seed,**r) for r in result_rows)
    print('[DONE CASE]',case_id,flush=True)


def train_model(args,torch,folder,name,model,opt,x,y,seed):
    checkpoint=folder/(name+'_checkpoint.pt')
    hist=[];start=0;best=float('inf');best_epoch=0;idle=0
    if args.resume and checkpoint.exists():
        # Only resume matching configuration (validated before loading); old checkpoints must be trusted locally.
        state=torch.load(checkpoint,map_location=x.device,weights_only=False)
        expected=dict(epochs=args.epochs,lr=args.lr,weight_decay=args.weight_decay,seed=seed,name=name)
        if state.get('configuration') != expected:
            raise ValueError(f'checkpoint config mismatch {checkpoint}: {state.get("configuration")} != {expected}')
        model.load_state_dict(state['model']);opt.load_state_dict(state['optimizer'])
        hist=list(state['history']);start=int(state['epoch']);best=float(state['best'])
        best_epoch=int(state['best_epoch']);idle=int(state['idle'])
        torch.set_rng_state(state['torch_rng_cpu'].cpu())
        if x.device.type=='cuda' and state.get('torch_rng_cuda') is not None:
            torch.cuda.set_rng_state(state['torch_rng_cuda'].cpu(),device=x.device)
        print('[RESUME]',name,start,flush=True)
    configuration=dict(epochs=args.epochs,lr=args.lr,weight_decay=args.weight_decay,seed=seed,name=name)
    nparams=sum(p.numel() for p in model.parameters() if p.requires_grad)
    begun=time.time()
    for ep in range(start,args.epochs):
        model.train();opt.zero_grad(set_to_none=True)
        pred=model(x)
        if tuple(pred.shape)!=tuple(y.shape):
            raise RuntimeError(f'MSE shape mismatch in {name}: output={tuple(pred.shape)} target={tuple(y.shape)}')
        loss=torch.nn.functional.mse_loss(pred,y)
        if not torch.isfinite(loss):
            raise FloatingPointError(f'Nonfinite train loss in {name} epoch {ep+1}: {loss.item()}')
        loss.backward()
        opt.step()
        val=float(loss.detach().item());hist.append(val)
        if val+args.min_improvement < best:
            best=val;best_epoch=ep+1;idle=0
        else:idle+=1
        if (ep+1)%args.print_every==0 or ep==start or ep+1==args.epochs:
            print(f'  {name} {ep+1}/{args.epochs}: train_MSE={val:.8g} best={best:.8g}',flush=True)
        if (ep+1)%args.checkpoint_every==0 or ep+1==args.epochs:
            atomically_save(torch,checkpoint,dict(
                configuration=configuration,epoch=ep+1,history=hist,best=best,best_epoch=best_epoch,idle=idle,
                model=model.state_dict(),optimizer=opt.state_dict(),torch_rng_cpu=torch.get_rng_state(),
                torch_rng_cuda=torch.cuda.get_rng_state(x.device) if x.device.type=='cuda' else None))
            save_rows_csv(folder/(name+'_loss.csv'),[dict(epoch=j+1,training_mse=v) for j,v in enumerate(hist)],['epoch','training_mse'])
        if args.patience>0 and idle>=args.patience:break
    if not checkpoint.exists() or args.patience>0:
        atomically_save(torch,checkpoint,dict(configuration=configuration,epoch=len(hist),history=hist,
            best=best,best_epoch=best_epoch,idle=idle,model=model.state_dict(),optimizer=opt.state_dict(),
            torch_rng_cpu=torch.get_rng_state(),
            torch_rng_cuda=torch.cuda.get_rng_state(x.device) if x.device.type=='cuda' else None))
    save_rows_csv(folder/(name+'_loss.csv'),[dict(epoch=j+1,training_mse=v) for j,v in enumerate(hist)],['epoch','training_mse'])
    return dict(name=name,parameters=nparams,training_mse_final=hist[-1],training_mse_best=best,
                best_epoch=best_epoch,epochs_completed=len(hist),elapsed_seconds=round(time.time()-begun,2),
                checkpoint=checkpoint.name,__curve=hist)


def main():
    args=cli()
    ranks=parse_ints(args.ranks);seeds=parse_ints(args.seeds)
    if args.layers<1 or not ranks or any(x<=1 for x in ranks):
        raise SystemExit('At least one stalk rank d>=2 and layers>=1 are required')
    if args.checkpoint_every<1 or args.print_every<1: raise SystemExit('checkpoint/print interval >= 1')
    plans=preset_specs(args)
    cases=[(*p,seed) for p in plans for seed in seeds]
    print(f'PLAN: {len(plans)} graph/task/hidden cases x {len(seeds)} seeds = {len(cases)} cases, {len(ranks)} NSD ranks per case',flush=True)
    for i,p in enumerate(cases):
        fam,n,cfg,task,h,seed=p
        print(f'  {i+1:3d}. {tag(fam,n,cfg,task,h,seed,args.layers)}',flush=True)
    if args.plan_only:return
    import torch
    import networkx as nx
    torch.set_num_threads(max(1,args.threads))
    if args.backend=='portable':
        from portable_backend import install
        install()
    sys.path.insert(0,str(SOURCE))
    from models.disc_models import DiscreteBundleSheafDiffusion
    out_root=Path(args.output_dir).resolve();out_root.mkdir(parents=True,exist_ok=True)
    original_file=SOURCE/'NSD_PhysicaD_code_20261121(1).zip'
    sha=hashlib.sha256(original_file.read_bytes()).hexdigest() if original_file.exists() else None
    save_json(out_root/'RUN_MANIFEST.json',dict(args=vars(args),python=sys.version,torch=torch.__version__,
              networkx=nx.__version__,source_zip_sha256=sha,cases=len(cases),
              note='New independent draws: historical Figure 5-11 reconstruction is not claimed'))
    all_summary=[];failures=[]
    for i,case in enumerate(cases):
        print(f'\n=== CASE {i+1}/{len(cases)} ===',flush=True)
        try:run_one(args,torch,nx,case,out_root,all_summary)
        except Exception as exc:
            failure=dict(case=case,exception=repr(exc),traceback=traceback.format_exc())
            failures.append(failure); print(failure['traceback'],file=sys.stderr,flush=True)
            if args.fail_fast:break
        if all_summary:
            fields=['case','family','N','task','layers','seed','name','parameters','training_mse_final','training_mse_best','best_epoch','epochs_completed','elapsed_seconds','checkpoint']
            save_rows_csv(out_root/'ALL_SUMMARY.csv',all_summary,fields)
        save_json(out_root/'FAILURES.json',failures)
    if failures:
        raise SystemExit(f'{len(failures)} cases failed; see FAILURES.json')
    print(f'\nSUCCESS: {len(cases)} cases. Results in {out_root}',flush=True)


if __name__=='__main__':main()
