@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Using Python: %NSD_PYTHON%
"%NSD_PYTHON%" check_gpu_environment.py
if errorlevel 1 goto :failed
echo Smoothed target N x 1 (no broadcast), d=2,4,6,8.
echo EXCLUDING 24 cases already computed by 02_RUN_BASE_GPU.bat.
echo New 04_RUN_SMOOTHED_GPU.bat executes ONLY the remaining 40 rank runs.
echo Make sure BASE_GPU is completed before drawing all Figures 5-11.
"%NSD_PYTHON%" -u run_nsd_corrected.py --preset smoothed --exclude-base-smoothed --ranks 2,4,6,8 --layers 2 --epochs 1000 --seeds 0 --baselines none --backend portable --device cuda --threads 4 --checkpoint-every 50 --output-dir results_SMOOTHED_GPU --resume
if errorlevel 1 goto :failed
echo.
echo SUCCESS. Output path shown above.
pause
exit /b 0
:failed
echo.
echo ERROR. GPU environment or experiment failed. No PyTorch packages were installed or altered.
pause
exit /b 1
