"""CPU sanity tests for the actual Karube NSD code with portable ops.
Run: python tests/test_corrected.py
"""
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(HERE))
from portable_backend import install
install()
sys.path.insert(0,str(HERE/'karube_original'))
import torch
import networkx as nx
from run_nsd_corrected import generate_data,model_options,create_baseline_models
from models.disc_models import DiscreteBundleSheafDiffusion


def check_target_exact():
    g,e,x,y,niso,_=generate_data('BA',4,dict(m=1),123,'smoothed','zero',torch,nx,torch.device('cpu'))
    expect=[]
    for i in range(4):
        neigh=list(g.neighbors(i))
        expect.append(x[neigh,:].sum().item()/len(neigh))
    assert y.shape==(4,1)
    torch.testing.assert_close(y.flatten(),torch.tensor(expect),rtol=1e-5,atol=2e-6)
    ga,e,xx,yy,_,_=generate_data('BA',4,dict(m=1),123,'feature_sum_noise','zero',torch,nx,torch.device('cpu'))
    assert yy.shape==(4,1)
    assert not torch.allclose(y,yy)
    assert torch.max(torch.abs(yy - xx.sum(dim=1,keepdim=True))) < 0.5, 'unexpected noise scale'
    gb,eb,xxx,yyy,_,_=generate_data('BA',4,dict(m=1),123,'independent','zero',torch,nx,torch.device('cpu'))
    assert yyy.shape==(4,1)
    assert not torch.allclose(yy,yyy)
    print('OK: correct N x 1 sum-over-all-channels neighbor target')


def check_source_forward_and_grad():
    n=8
    g,e,x,y,_,_=generate_data('BA',n,dict(m=2),4,'smoothed','zero',torch,nx,torch.device('cpu'))
    for d in (2,4,6,8):
        args=model_options(torch,n,d,2,8,torch.device('cpu'))
        m=DiscreteBundleSheafDiffusion(e,args)
        pred=m(x)
        assert pred.shape == (n,1)
        L=torch.nn.functional.mse_loss(pred,y)
        L.backward()
        assert m.lin1.weight.grad is not None and torch.isfinite(m.lin1.weight.grad).all()
        leaf_grads=[p.grad for p in m.sheaf_learners.parameters() if p.grad is not None]
        assert leaf_grads and all(torch.isfinite(g).all() for g in leaf_grads)
        print(f'OK: original NSD forward+backward d={d}, params={sum(p.numel() for p in m.parameters())}')


def check_mathematical_builder():
    from models.laplacian_builders import NormConnectionLaplacianBuilder
    n=4;d=3
    undir=torch.tensor([[0,1,2,0],[1,2,3,3]],dtype=torch.long)
    e=torch.cat([undir,undir.flip(0)],dim=1)
    builder=NormConnectionLaplacianBuilder(n,e,d=d,orth_map='householder')
    params=torch.randn(e.shape[1],d*(d-1)//2,requires_grad=True)
    idx,weights=builder(params)[0]
    M=torch.sparse_coo_tensor(idx,weights,(n*d,n*d)).coalesce().to_dense()
    assert torch.allclose(M,M.T,atol=1e-5)
    eig=torch.linalg.eigvalsh(M.detach())
    assert eig.min()>-1e-4, eig
    (M.square().sum()).backward()
    assert torch.isfinite(params.grad).all()
    print('OK: normalized sheaf Laplacian symmetric PSD, gradients finite')


def check_baselines():
    g,e,x,y,_,_=generate_data('BA',8,dict(m=2),4,'smoothed','zero',torch,nx,torch.device('cpu'))
    mods=create_baseline_models(torch,e,8,10,16,2,torch.device('cpu'),'both',seed=99)
    a,b=mods['GCN_graph_using'],mods['MLP_graph_blind']
    assert sum(p.numel() for p in a.parameters())==sum(p.numel() for p in b.parameters())
    assert all(torch.allclose(u,v) for u,v in zip(a.parameters(),b.parameters()))
    print('OK: optional true GCN and graph-blind MLP have same architecture and initialization')

if __name__=='__main__':
    torch.set_num_threads(2)
    check_target_exact();check_source_forward_and_grad();check_mathematical_builder();check_baselines()
    print('ALL SANITY TESTS PASSED')
