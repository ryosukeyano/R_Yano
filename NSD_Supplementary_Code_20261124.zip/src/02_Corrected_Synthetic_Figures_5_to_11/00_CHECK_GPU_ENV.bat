@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Using Python: %NSD_PYTHON%
"%NSD_PYTHON%" check_gpu_environment.py
if errorlevel 1 goto :failed
echo GPU check PASSED. No packages installed.
pause
exit /b 0
:failed
echo GPU check FAILED. No packages installed.
pause
exit /b 1
