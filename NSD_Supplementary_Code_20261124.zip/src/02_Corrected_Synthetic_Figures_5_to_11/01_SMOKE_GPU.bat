@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Using Python: %NSD_PYTHON%
"%NSD_PYTHON%" check_gpu_environment.py
if errorlevel 1 goto :failed
echo NSD original model: GPU smoke and corrected N x 1 smoothed target
"%NSD_PYTHON%" -u run_nsd_corrected.py --preset smoke --ranks 2,4 --layers 2 --epochs 3 --baselines both --backend portable --device cuda --threads 4 --print-every 1 --checkpoint-every 1 --output-dir smoke_GPU_NEW --resume
if errorlevel 1 goto :failed
echo.
echo SUCCESS. Output path shown above.
pause
exit /b 0
:failed
echo.
echo ERROR. GPU environment or experiment failed. No PyTorch packages were installed or altered.
pause
exit /b 1
