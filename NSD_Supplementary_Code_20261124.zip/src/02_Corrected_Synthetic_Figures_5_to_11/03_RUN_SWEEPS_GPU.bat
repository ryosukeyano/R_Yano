@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Using Python: %NSD_PYTHON%
"%NSD_PYTHON%" check_gpu_environment.py
if errorlevel 1 goto :failed
echo ER BA WS parameter sweeps with historical feature-sum-noise target
"%NSD_PYTHON%" -u run_nsd_corrected.py --preset sweeps --ranks 2,4,6,8 --layers 2 --epochs 1000 --seeds 0 --baselines none --backend portable --device cuda --threads 4 --checkpoint-every 50 --output-dir results_SWEEPS_GPU --resume
if errorlevel 1 goto :failed
echo.
echo SUCCESS. Output path shown above.
pause
exit /b 0
:failed
echo.
echo ERROR. GPU environment or experiment failed. No PyTorch packages were installed or altered.
pause
exit /b 1
