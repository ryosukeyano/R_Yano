#!/usr/bin/env python3
"""Train a genuine graph-using GCN on already-saved NSD graph_and_xy.pt cases.
Does NOT rerun NSD or regenerate graph, features, or targets; never edits NSD checkpoints.
Requires existing PyTorch CUDA environment by default, no package installations.
"""
from __future__ import annotations
import argparse, json, sys, csv, datetime
from pathlib import Path
from types import SimpleNamespace


def main():
    p=argparse.ArgumentParser(description='Train genuine GCN on the SAME saved graph/input/target as NSD')
    p.add_argument('--roots',nargs='+',default=['results_BASE_GPU','results_SWEEPS_GPU','results_SMOOTHED_GPU','results_ALL_GPU'])
    p.add_argument('--device',choices=['cuda','cpu'],default='cuda')
    p.add_argument('--baseline-hidden',type=int,default=16)
    p.add_argument('--epochs',type=int,default=1000)
    p.add_argument('--checkpoint-every',type=int,default=50)
    p.add_argument('--print-every',type=int,default=100)
    p.add_argument('--resume',action='store_true')
    p.add_argument('--all-cases',action='store_true',help='Include NSD cases that have not yet finished (default waits for completed.json)')
    p.add_argument('--threads',type=int,default=4)
    args=p.parse_args()
    import torch
    torch.set_num_threads(max(1,args.threads))
    if args.device=='cuda':
        if not torch.cuda.is_available():raise SystemExit('CUDA unavailable; no training started or environment changed.')
        # Executes an actual CUDA matmul/backward to reject non-working CUDA builds.
        a=torch.randn(16,16,device='cuda',requires_grad=True)
        ((a@a).square().sum()).backward();torch.cuda.synchronize()
        print('GPU:',torch.cuda.get_device_name(0),'PyTorch:',torch.__version__,flush=True)
    from run_nsd_corrected import create_baseline_models,seed_everything,train_model
    count=0;skipped=0
    for root in args.roots:
        rr=Path(root)
        if not rr.exists():continue
        for jp in sorted(rr.glob('*/case.json')):
            folder=jp.parent
            if not args.all_cases and not (folder/'completed.json').exists():
                print('[SKIP in-progress NSD]',folder)
                skipped+=1;continue
            loss_path=folder/'GCN_graph_using_loss.csv'
            if loss_path.exists() and not args.resume:
                print('[SKIP existing GCN]',folder)
                skipped+=1;continue
            case=json.loads(jp.read_text(encoding='utf-8'))
            case_file=folder/'graph_and_xy.pt'
            if not case_file.exists():
                print('[SKIP missing dataset]',folder)
                skipped+=1;continue
            ds=torch.load(case_file,map_location='cpu',weights_only=True)
            x,y,edge=ds['x'],ds['y'],ds['edge_index']
            n=int(case['N'])
            if tuple(x.shape)!=(n,10) or tuple(y.shape)!=(n,1) or edge.shape[0]!=2:
                raise RuntimeError(f'Corrupt/mismatched case at {folder}: x={x.shape}, y={y.shape}, edges={edge.shape}')
            seed=int(case['seed']);depth=int(case['layers'])
            seed_everything(seed,torch)
            x=x.to(args.device);y=y.to(args.device);edge=edge.to(args.device)
            baselines=create_baseline_models(torch,edge,n,10,args.baseline_hidden,depth,
                                              torch.device(args.device),'gcn',seed)
            model=baselines['GCN_graph_using']
            lr=float(case['lr']);wd=float(case['weight_decay'])
            opt=torch.optim.Adam(model.parameters(),lr=lr,weight_decay=wd)
            cfg=SimpleNamespace(epochs=args.epochs,lr=lr,weight_decay=wd,checkpoint_every=args.checkpoint_every,
                                print_every=args.print_every,min_improvement=1e-5,patience=0,resume=args.resume)
            print(f'\n[START GCN on same saved data] {folder} n={n} hidden={args.baseline_hidden} layers={depth}',flush=True)
            row=train_model(cfg,torch,folder,'GCN_graph_using',model,opt,x,y,seed)
            row.pop('__curve',None)
            (folder/'GCN_RECHECK_METADATA.json').write_text(json.dumps({
                'source':'GCN baseline trained later on the EXACT same saved x/y/edge_index as the corrected NSD case',
                'original_case':case,'training':{'baseline_hidden':args.baseline_hidden,'layers':depth,'epochs':args.epochs,
                                                'lr':lr,'weight_decay':wd},'output':row,
                'not_a_historical_result':True,'no_NSD_checkpoint_changed':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            count+=1
    print(f'Completed new GCN baselines: {count}. Skipped: {skipped}. NSD weights unchanged.')

if __name__=='__main__':main()
