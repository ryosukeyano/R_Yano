@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo PLAN ONLY: 24 duplicated NSD rank runs skipped, 40 remaining.
"%NSD_PYTHON%" run_nsd_corrected.py --preset smoothed --exclude-base-smoothed --plan-only --ranks 2,4,6,8 --seeds 0 --layers 2
if errorlevel 1 goto :failed
echo.
echo EXPECTED: 10 graph specifications x 4 NSD ranks = 40 runs.
pause
exit /b 0
:failed
echo ERROR. Please verify that BOTH 04_RUN_SMOOTHED_GPU.bat and run_nsd_corrected.py were updated.
pause
exit /b 1
