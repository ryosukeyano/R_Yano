# ER・BA・WS NSD GPU再計算版：既存PyTorchを一切変更しない（2026-11-21）

## 最重要：CPU版の上書きをしません

このZIPには **CPU版PyTorchをインストールするBATはありません。** `pip install` / `conda install` / `venv` 作成・変更を一切実行しません。全BATは既存PythonのCUDA環境を先に検査し、GPUが利用できなければ**停止**します。自動的なCPU代替実行は行いません。

前回配布の `01_SETUP_CPU.bat` は、前回フォルダ内の `.venv` が対象でした。他のPython環境を直接変更するものではありません。ただし同じ `.venv` にGPU版を入れていた場合はCPU版へ置き換わり得ます。`

## 実行前：GPU版Pythonを指定

すでにGPU版PyTorchの仮想環境がある場合、Anaconda PromptまたはCMDでその環境をactivateした後、展開したフォルダに移動して次を実行してください。

```
00_CHECK_GPU_ENV.bat
01_SMOKE_GPU.bat
```

利用するPythonをフルパスで指定する場合は、CMDで一度だけ（例示パスは各自の環境に合わせる）:

```
set "NSD_PYTHON=G:\your_gpu_venv\Scripts\python.exe"
00_CHECK_GPU_ENV.bat
01_SMOKE_GPU.bat
```

出力に `PyTorch ... +cuXXX`、`Compiled CUDA runtime: ...`、`CUDA available: True`、GPU名、`CUDA matrix operation + backward: PASS` が出ることを確認してください。GPUチェックに失敗した場合、実験は開始されず、既存環境に変更も加えません。

GTX 1070 (Pascal, compute capability 6.1) はPyTorchのビルドによってCUDA命令非対応の場合があります。`cuda.is_available()==True` だけでなくCUDA計算そのものを試験します。旧GPU用のPyTorchのバージョンを、ここでは決め打ちしません。

`torch_sparse`, `torch_scatter`, `torch_geometric`, `torch_householder` がGPU版環境に揃っている場合は手動コマンドの `--backend portable` を `--backend native` に変更できます。デフォルトは外部拡張に依存しないPyTorch演算のportableアダプタです。これは元のクラスを変えませんが、計算軌道のビット一致は保証されません。

## 軽部君の2026-11-21回答を受けた重大な訂正

**旧Figures 5–8のgraph-independent targetは、入力 X から独立な乱数ではありません。** 本人確認による実際の式:

`Y_i = sum_{q=1}^{10} X_{iq} + 0.1 * N(0,1)`

`--tasks feature_sum_noise` でこの式を使用します。グラフに依存しない一方で**入力には依存**するため、`independent` / random labels / heterophily と同一視してはいけません。前版の `independent` 目標は任意選択の追加アブレーションとして残していますが、既定の再計算対象にはしません。

Graph-smoothed targetは、論文の式に合わせ `Y_i=(sum_(j~i)sum_(q=1..10)X_jq)/deg(i)` という必ず **N×1** のベクトルです。predictionもN×1であることを毎epoch検証し、ブロードキャストを禁止しています。孤立点は `--isolate-policy zero` で明示的に0とし、論文への追記が必要です。

比較モデル `SimpleLinearGNN` はMLPだったことが本人確認により確定したため、旧GNN曲線はGCNの結果として使いません。新規のGCNは学習可能なGCN operatorを使う独立比較です。GCNとMLPは同じパラメータ数ですが、**NSDとの容量一致は保証されません**。

## GPU用実行BAT

- `00_CHECK_GPU_ENV.bat` : 既存CUDA環境の検査（インストール処理なし）
- `01_SMOKE_GPU.bat` : ランク2/4、3epoch、GPU基本動作の確認
- `02_RUN_BASE_GPU.bat` : ER/BA/WS、N=10/50/100/300、ランク2/4/6/8、feature_sum_noiseとsmoothed
- `03_RUN_SWEEPS_GPU.bat` : ER p、BA m、WS k/pの比較（feature_sum_noise）
- `04_RUN_SMOOTHED_GPU.bat` : smoothed targetの比較
- `05_GCN_MLP_NSD_CONTROL_GPU.bat` : NSDと正しいGCNとMLPの比較用
- `06_RUN_ALL_GPU.bat` : 全計算（計算量は大きい）
- `07_VIEW_PLAN.bat` : 計算計画のみ

全ての再計算は乱数seedを記録し、グラフ・入力・教師値を条件ごとに保存します。各モデルで学習損失CSV・チェックポイントを出力します。GPUによる演算は非決定的となる場合があり、元の結果と完全一致する保証はありません。実験ログでは `training MSE` を示し、テストRMSEと混同しません。

## これまでの論文図との関係

・軽部君がFig.5–11にMLPと誤記、予測教師の不整合、コードの条件相違を認めたため、旧図は修正後の新規学習結果を確認するまで比較結論に使用しません。  
・Fig.5–8の旧graph-independent taskを再現するには `feature_sum_noise` を使用します。  
・Graph-smoothed taskは必ず論文通りのN×1合計ターゲットへ変更するため、旧図は数値的に変わる可能性があります。  
・`--layers 2` は既存ログに合わせていますが、論文に `l=1` と書かれていた事実と不一致なので、論文へ反映する際は層数を明示して更新してください。  
・PeMSD7やSTGCN、GCNの30分/45分混同はこのパッケージの対象外で、本文の比較修正が別途必要です。

## 条件確認・記録・原本との違い

`run_nsd_corrected.py --help` で全オプション表示。指定パラメータは `RUN_MANIFEST.json`、`case.json`、`summary.csv` へ保存。`--resume` により同条件のcheckpoint再開ができます。条件変更時は別ディレクトリを使ってください。

`karube_original` には前に共有された元コードを保持しています。非公開GitHubリポジトリの現時点の内容と完全一致する保証はありません。本文のEq.(4)は、学習可能残差係数等を実装に合わせてなお調整する必要があります。

## 2026-11-21追記：論文と同じFigures 5–11のパネル図

再計算結果の個別 `loss.png` だけでなく、論文と同じ3×4、2×3、2×4、3×3、1×3、2×2のパネル図をまとめて作成できます。`README_FIGURES_5_TO_11_JA.md` を参照し、`09_ADD_REAL_GCN_FROM_SAVED_NSD.bat` で保存済みNSD条件のGCNを追加計算してから、`08_DRAW_FIG5_TO_11.bat` を実行してください。


## 2026-11-22 04_RUN_SMOOTHED_GPU.bat の重複除外修正

`02_RUN_BASE_GPU.bat` と重複する smoothed/h=20、ER(p=0.1)・BA(m=2)・WS(k=4,p=0.1)、N=50/100 の **6グラフ条件×4ランク=24回** を `04` では実行しません。残り **10グラフ条件×4ランク=40回** だけが実行対象です。

新しい `04_RUN_SMOOTHED_GPU.bat` は `--preset smoothed --exclude-base-smoothed` を指定します。旧フォルダに適用する場合は、`04_RUN_SMOOTHED_GPU.bat` と `run_nsd_corrected.py` の **2ファイルを同時に置換**してください。既存の `results_BASE_GPU` / `results_SWEEPS_GPU` やGPU版PyTorchには変更を加えません。

`--resume` はそのまま有効で、`results_SMOOTHED_GPU` 内の完了済みケースはスキップされます。新しい `04` で足りない24ケースは `results_BASE_GPU` から図作成時に読み込まれます。**02が未完了の場合は、後で完了させてください。**

プランだけ検査するには：

```bat
python run_nsd_corrected.py --preset smoothed --exclude-base-smoothed --plan-only --ranks 2,4,6,8 --seeds 0 --layers 2
```

一覧には **10 cases** と表示され、NSDのランクごとの計算回数は **40回** です。
