@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Training genuine graph-using GCN baselines on SAVED NSD x/y/edges.
echo NSD weights will not be retrained or modified; no pip/conda installs.
"%NSD_PYTHON%" check_gpu_environment.py
if errorlevel 1 goto :failed
"%NSD_PYTHON%" -u run_GCN_on_saved_NSD.py --roots results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU results_ALL_GPU --device cuda --baseline-hidden 16 --epochs 1000 --checkpoint-every 50 --print-every 100 --resume
if errorlevel 1 goto :failed
echo.
echo GCN baselines finished. Run 08_DRAW_FIG5_TO_11.bat to render paper-grid plots.
pause
exit /b 0
:failed
echo.
echo ERROR. Existing packages/PyTorch unchanged.
pause
exit /b 1
