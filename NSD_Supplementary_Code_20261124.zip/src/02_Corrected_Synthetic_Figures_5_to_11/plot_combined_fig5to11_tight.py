#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Complete standalone plotting program for corrected NSD Figures 5--11.

Inputs:  existing results_BASE_GPU, results_SWEEPS_GPU, results_SMOOTHED_GPU,
         (optionally) results_COMPARE_GPU directories.  Each case contains
         case.json, completed.json, and *_loss.csv.

Outputs: one true-vector EPS/PDF and one PNG for each combined figure 5--11.
         (a) 0--20 completed optimizer updates, *linear* MSE;
         (b) complete history, strictly positive *logarithmic* MSE;
             each subplot's y-limits fit its ACTUAL positive data.

The file never imports PyTorch, changes the environment, trains, interpolates,
shifts epochs in the CSV, or fabricates missing series.  Source CSV epoch=1
is drawn at x=0 because the logged MSE precedes that optimizer update.

Usage:
    python plot_combined_fig5to11_tight.py --strict
    python plot_combined_fig5to11_tight.py --figures 5,9 --strict
    python plot_combined_fig5to11_tight.py --ylim-mode figure --strict
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.ticker import LogFormatterMathtext, LogLocator, NullLocator

FIGURE_TITLES = {5: 'ER, BA and WS: node-count dependence of training MSE', 6: 'ER: edge-probability dependence of training MSE', 7: 'BA: attachment number and network size versus training MSE', 8: 'WS: node count, neighborhood size and rewiring versus training MSE', 9: 'ER, BA and WS: node-count effects on graph-smoothed target MSE', 10: 'ER: connection probability versus graph-smoothed target MSE', 11: 'BA and WS: parameter effects on graph-smoothed target MSE'}


@dataclass(frozen=True)
class Panel:
    family: str
    n: int
    parameters: tuple
    task: str
    hidden: int

    def title(self) -> str:
        pars = ", ".join(f"{k}={v:g}" if isinstance(v, float)
                          else f"{k}={v}" for k, v in self.parameters)
        return f"{self.family}  N={self.n}  {pars}"


def p(family: str, n: int, kwargs: dict, task: str, hidden: int) -> Panel:
    return Panel(family, n, tuple(sorted((k, round(v, 9) if isinstance(v, float)
                                          else v) for k, v in kwargs.items())), task, hidden)


def layouts() -> dict:
    ns = (10, 50, 100, 300)
    return {
        5: (3, 4, [p(f, n, pars, "feature_sum_noise", 20)
                    for f, pars in [("ER", {"p": .1}),
                                    ("BA", {"m": 2}),
                                    ("WS", {"k": 4, "p": .1})]
                    for n in ns],
            "Graph-independent local-feature-sum target; rows ER, BA, WS; columns N=10, 50, 100, 300."),
        6: (2, 3, [p("ER", 100, {"p": x}, "feature_sum_noise", 16)
                    for x in (.1, .3, .5, .7, .9)] + [None],
            "Graph-independent target; ER N=100; p=0.1, 0.3, 0.5 / 0.7, 0.9."),
        7: (2, 4, [p("BA", n, {"m": m}, "feature_sum_noise", 16)
                    for m in (2, 4) for n in ns],
            "Graph-independent target; BA m=2 (upper row), m=4 (lower row)."),
        8: (2, 4, [p("WS", n, {"k": k, "p": prob}, "feature_sum_noise", 16)
                    for k, prob in ((4, .1), (6, .2)) for n in ns],
            "Graph-independent target; WS (k,p)=(4,0.1) / (6,0.2)."),
        9: (3, 3, [p(f, n, pars, "smoothed", 20)
                    for f, pars in [("ER", {"p": .1}),
                                    ("BA", {"m": 2}),
                                    ("WS", {"k": 4, "p": .1})]
                    for n in (50, 100, 200)],
            "Graph-smoothed target; rows ER, BA, WS; columns N=50, 100, 200."),
        10: (1, 3, [p("ER", 50, {"p": x}, "smoothed", 16)
                     for x in (.1, .5, .9)],
             "Graph-smoothed target; ER N=50; p=0.1, 0.5, 0.9."),
        11: (2, 2, [p("BA", 50, {"m": 2}, "smoothed", 16),
                     p("BA", 50, {"m": 4}, "smoothed", 16),
                     p("WS", 50, {"k": 4, "p": .1}, "smoothed", 16),
                     p("WS", 50, {"k": 6, "p": .2}, "smoothed", 16)],
             "Graph-smoothed target; BA m=2,4 (upper), WS k=4,6 (lower)."),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--roots", nargs="+", default=[
        "results_BASE_GPU", "results_SWEEPS_GPU", "results_SMOOTHED_GPU", "results_COMPARE_GPU"],
        help="One or more run directories containing case folders")
    parser.add_argument("--output-dir", default="composite_figures_tight",
                        help="A NEW directory for regenerated plots")
    parser.add_argument("--figures", default="5,6,7,8,9,10,11")
    parser.add_argument("--ranks", default="2,4,6,8")
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--strict", action="store_true",
                        help="Abort without plotting if ANY required case or curve is absent")
    parser.add_argument("--ylim-mode", choices=("panel", "figure"), default="panel",
                        help="For full graphs: tight min/max per panel, or shared min/max for all panels in one figure")
    parser.add_argument("--lower-factor", type=float, default=.85,
                        help="Log y lower limit = minimum positive MSE x factor (0 < factor < 1)")
    parser.add_argument("--upper-factor", type=float, default=1.20,
                        help="Log y upper limit = maximum MSE x factor (>1)")
    parser.add_argument("--dpi", type=int, default=240)
    return parser.parse_args()


def get_sources(roots: list[str], seed: int, layers: int) -> dict:
    """Prefer completed cases with most loss files, preserving caller root priority."""
    options: dict[Panel, list] = defaultdict(list)
    for priority, root_s in enumerate(roots):
        root = Path(root_s)
        if not root.is_dir():
            print(f"NOTICE: output directory not present: {root}")
            continue
        for meta_path in sorted(root.glob("*/case.json")):
            try:
                info = json.loads(meta_path.read_text(encoding="utf-8"))
                if int(info["seed"]) != seed or int(info["layers"]) != layers:
                    continue
                key = p(str(info["family"]), int(info["N"]),
                        dict(info["parameters"]), str(info["task"]),
                        int(info["hidden_channels"]))
                folder = meta_path.parent
                complete = int((folder / "completed.json").is_file())
                nloss = len(list(folder.glob("*_loss.csv")))
                options[key].append(((complete, nloss, -priority), folder, info))
            except (OSError, ValueError, TypeError, KeyError) as exc:
                print(f"WARNING: ignored {meta_path}: {exc}", file=sys.stderr)
    return {key: max(candidates, key=lambda v: v[0])[1:]
            for key, candidates in options.items()}


def read_loss_csv(file: Path) -> tuple[np.ndarray, np.ndarray]:
    ep, mse = [], []
    with file.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            try:
                k = int(row["epoch"])
                v = float(row["training_mse"])
            except (ValueError, TypeError, KeyError) as exc:
                raise ValueError(f"Bad loss CSV entry: {file}: {row}") from exc
            if k < 1 or not math.isfinite(v) or v < 0:
                raise ValueError(f"Invalid MSE/epoch: {file}: epoch={k}, MSE={v}")
            ep.append(k - 1)  # CSV's 1 = PRE-UPDATE initial loss; plot it as 0 updates.
            mse.append(v)
    if not ep or any(b <= a for a, b in zip(ep, ep[1:])):
        raise ValueError(f"Missing or non-increasing epoch sequence: {file}")
    return np.asarray(ep, dtype=float), np.asarray(mse, dtype=float)


def load_panel(folder: Path, ranks: list[int]) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    models = [(f"NSD (d={d})", folder / f"NSD_rank{d}_loss.csv") for d in ranks]
    models.append(("GCN (graph convolution)", folder / "GCN_graph_using_loss.csv"))
    curves = {}
    for label, path in models:
        if path.is_file():
            curves[label] = read_loss_csv(path)
    return curves


def pos_limits(curves: dict, lower_factor: float, upper_factor: float) -> tuple[float, float]:
    """No clipping: use actual min and max among ALL finite positive recorded MSEs."""
    positive = [y[y > 0] for _, y in curves.values() if np.any(y > 0)]
    if not positive:
        raise ValueError("No strictly positive MSE: logarithmic view is undefined")
    lo = min(float(z.min()) for z in positive)
    hi = max(float(z.max()) for z in positive)
    bottom = lo * lower_factor
    top = hi * upper_factor
    if not (math.isfinite(bottom) and math.isfinite(top) and 0 < bottom < top):
        raise ValueError(f"Bad logarithmic limits from data min={lo}, max={hi}")
    return bottom, top


def draw_curve(ax, curves, ranks, colors, *, part, ylim=None, first20_upper=None):
    for label, (x, y) in curves.items():
        if label.startswith("GCN"):
            color, style = "#7659a6", "--"
        else:
            d = int(label.split("d=")[1].split(")")[0])
            color, style = colors[d], "-"
        keep = np.isfinite(x) & np.isfinite(y)
        if part == "first20":
            keep &= (x <= 20)
        else:
            keep &= (y > 0)  # log cannot show exact zero; never replace it with epsilon.
        ax.plot(x[keep], y[keep], color=color, lw=1.6, linestyle=style)
    if part == "first20":
        ax.set_xlim(0, 20)
        ax.set_xticks([0, 5, 10, 15, 20])
        ax.set_ylim(0, first20_upper)
    else:
        upper_x = max(float(np.max(x)) for x, y in curves.values())
        ax.set_xlim(0, max(20, upper_x))
        ax.set_yscale("log", nonpositive="mask")
        ax.set_ylim(*ylim)
        ax.yaxis.set_major_locator(LogLocator(base=10, numticks=6))
        ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10))
        ax.yaxis.set_minor_locator(NullLocator())
    ax.tick_params(axis="both", labelsize=8.8)
    ax.grid(True, which="major", color="#d6d6d6", alpha=1, linewidth=.5)
    ax.set_xlabel("Optimizer updates", fontsize=9.5)
    ax.set_ylabel("Training MSE", fontsize=9.5)


def make_figure(number, layout, by_panel, ranks, args):
    nrows, ncols, panels, caption = layout
    colors = {2: "#2b6bb2", 4: "#d97731", 6: "#378a62", 8: "#c74b51"}
    # Maintain a common first20 y-scale so those panels are comparable.
    early_values = [float(v) for cvs in by_panel if cvs for x, y in cvs.values()
                    for v in y[x <= 20] if math.isfinite(v)]
    first_upper = max(early_values) * 1.08 if early_values else 1.0
    first_upper = max(first_upper, 1e-8)
    shared_limits = None
    if args.ylim_mode == "figure":
        merged = {}
        for j, cvs in enumerate(by_panel):
            if cvs:
                for key, series in cvs.items():
                    merged[f"{j}:{key}"] = series
        shared_limits = pos_limits(merged, args.lower_factor, args.upper_factor)

    # Dedicated grid rows for the (a)/(b) headers and the caption/legend.
    # Unlike free-positioned fig.text(), these rows cannot overlap any axes.
    figure_width = 4.45 * ncols
    figure_height = 5.75 * nrows + 3.25
    fig = plt.figure(figsize=(figure_width, figure_height), facecolor="white")
    fig.suptitle(FIGURE_TITLES[number], y=.991,
                 fontsize=15, fontweight="bold")
    height_ratios = [.25] + [1.0] * nrows + [.25] + [1.0] * nrows + [.65]
    gs = fig.add_gridspec(2 * nrows + 3, ncols,
                          height_ratios=height_ratios,
                          left=.07, right=.985, top=.943, bottom=.042,
                          hspace=.52, wspace=.34)
    header_a = fig.add_subplot(gs[0, :]); header_a.axis("off")
    header_a.text(.5, .45, "(a) first 20 epochs — linear MSE",
                  ha="center", va="center", transform=header_a.transAxes,
                  fontsize=12.5, fontweight="bold")
    header_b = fig.add_subplot(gs[nrows + 1, :]); header_b.axis("off")
    header_b.text(.5, .45, "(b) full training history — positive log MSE",
                  ha="center", va="center", transform=header_b.transAxes,
                  fontsize=12.5, fontweight="bold")
    for idx, panel_ in enumerate(panels):
        row, col = divmod(idx, ncols)
        for section, part in ((0, "first20"), (1, "full")):
            grid_row = 1 + row if section == 0 else nrows + 2 + row
            ax = fig.add_subplot(gs[grid_row, col])
            if panel_ is None:
                ax.axis("off")
                continue
            cvs = by_panel[idx]
            if not cvs:
                ax.text(.5, .5, "MISSING", transform=ax.transAxes,
                        ha="center", va="center", color="crimson")
                continue
            ylim = shared_limits or pos_limits(cvs, args.lower_factor, args.upper_factor)
            draw_curve(ax, cvs, ranks, colors, part=part,
                       ylim=ylim, first20_upper=first_upper)
            ax.set_title(panel_.title(), fontsize=10.2, pad=8)

    keys = [f"NSD (d={d})" for d in ranks] + ["GCN (graph convolution)"]
    handles = [Line2D([0], [0],
                      color=(colors[int(k.split("d=")[1].split(")")[0])]
                             if k.startswith("NSD") else "#7659a6"),
                      lw=2.0, linestyle="-" if k.startswith("NSD") else "--",
                      label=k) for k in keys]
    foot = fig.add_subplot(gs[-1, :]); foot.axis("off")
    foot.text(.5, .81, caption, ha="center", va="center",
              transform=foot.transAxes, fontsize=9.5)
    foot.legend(handles=handles, loc="lower center",
                bbox_to_anchor=(.5, -.02), ncol=len(keys),
                frameon=False, fontsize=10.0)
    return fig


def run() -> int:
    a = parse_args()
    if not (0 < a.lower_factor < 1):
        raise SystemExit("--lower-factor must satisfy 0 < value < 1")
    if a.upper_factor <= 1:
        raise SystemExit("--upper-factor must be > 1")
    figs = [int(x) for x in a.figures.split(",") if x.strip()]
    ranks = [int(x) for x in a.ranks.split(",") if x.strip()]
    if not figs or any(f not in layouts() for f in figs):
        raise SystemExit("--figures must be a subset of 5,6,7,8,9,10,11")
    if not ranks or any(d not in (2,4,6,8) for d in ranks):
        raise SystemExit("Available ranks: 2,4,6,8")

    sources = get_sources(a.roots, a.seed, a.layers)
    all_plots = {}
    coverage = []
    problems = []
    for figure in figs:
        nrows, ncols, panels, caption = layouts()[figure]
        curves_list = []
        for idx, panel_ in enumerate(panels):
            if panel_ is None:
                curves_list.append(None)
                continue
            if panel_ not in sources:
                problems.append(f"Fig. {figure}: MISSING CASE {panel_.title()} task={panel_.task} hidden={panel_.hidden}")
                curves_list.append({})
                coverage.append((figure, idx+1, panel_.title(), "MISSING CASE", ""))
                continue
            folder, metadata = sources[panel_]
            try:
                curves = load_panel(folder, ranks)
            except (OSError, ValueError) as exc:
                problems.append(f"Fig. {figure} / {folder}: {exc}")
                curves = {}
            expected = [f"NSD (d={d})" for d in ranks] + ["GCN (graph convolution)"]
            missing = [m for m in expected if m not in curves]
            if not (folder / "completed.json").is_file():
                missing.append("completed.json")
            if missing:
                problems.append(f"Fig. {figure}: {panel_.title()}: missing {missing} in {folder}")
            elif not any(np.any(y > 0) for x, y in curves.values()):
                problems.append(f"Fig. {figure}: all losses zero: no log plot: {folder}")
            coverage.append((figure, idx+1, panel_.title(),
                             "OK" if not missing else "MISSING", str(folder)))
            curves_list.append(curves)
        all_plots[figure] = curves_list

    outdir = Path(a.output_dir)
    outdir.mkdir(exist_ok=True, parents=True)
    with (outdir / "FIGURE_COVERAGE.csv").open("w", newline="", encoding="utf-8-sig") as f:
        cw = csv.writer(f)
        cw.writerow(("figure", "panel", "name", "status", "source_directory"))
        cw.writerows(coverage)

    if problems:
        for problem in problems:
            print("ERROR:", problem, file=sys.stderr)
        if a.strict:
            print("STRICT MODE: no figures were drawn; the source files were NOT modified.", file=sys.stderr)
            return 2
        print("WARNING: proceeding with clearly marked missing panels", file=sys.stderr)

    # Auditable axis statistics: verify that full-panel lower bounds follow
    # exactly the smallest positive MSE, never a hard-coded 1e-10.
    axis_rows = []
    for figure in figs:
        shared = None
        if a.ylim_mode == "figure":
            all_curves = {}
            for j, curves in enumerate(all_plots[figure]):
                if curves:
                    for model_name, xy in curves.items():
                        all_curves[f"{j}/{model_name}"] = xy
            if all_curves:
                shared = pos_limits(all_curves, a.lower_factor, a.upper_factor)
        for j, cvs in enumerate(all_plots[figure]):
            if cvs is None or not cvs:
                continue
            positives = [y[y > 0] for x, y in cvs.values() if np.any(y > 0)]
            if not positives:
                continue
            raw_min = min(float(y.min()) for y in positives)
            raw_max = max(float(y.max()) for y in positives)
            used_min, used_max = shared or pos_limits(cvs, a.lower_factor, a.upper_factor)
            zeros = sum(int(np.count_nonzero(y == 0)) for x, y in cvs.values())
            axis_rows.append([figure, j+1, layouts()[figure][2][j].title(),
                              f"{raw_min:.16g}", f"{raw_max:.16g}",
                              f"{used_min:.16g}", f"{used_max:.16g}", zeros, a.ylim_mode])
    with (outdir / "AXIS_LIMITS.csv").open("w", newline="", encoding="utf-8-sig") as f:
        wr = csv.writer(f)
        wr.writerow(["figure", "panel", "condition", "actual_min_positive_mse",
                     "actual_max_mse", "full_y_lower", "full_y_upper", "zero_mse_points_omitted", "ylim_mode"])
        wr.writerows(axis_rows)

    outputs = []
    for figure in figs:
        f = make_figure(figure, layouts()[figure], all_plots[figure], ranks, a)
        stem = outdir / f"FIG_{figure:02d}_20_FULL_COMBINED"
        for ext in ("eps", "pdf", "png"):
            path = stem.with_suffix("." + ext)
            f.savefig(path, format=ext, dpi=a.dpi,
                      bbox_inches="tight", pad_inches=.14)
            outputs.append(str(path))
        plt.close(f)
        print(f"FIG {figure} DONE: {stem}.[eps|pdf|png]", flush=True)

    manifest = {
        "figure_numbers": figs,
        "figures": outputs,
        "input_roots": a.roots,
        "layers": a.layers,
        "seed": a.seed,
        "ranks": ranks,
        "x_axis": "optimizer updates from zero: plotted_epoch=CSV_epoch-1",
        "first20_y_axis": "linear, common range across panels of each figure",
        "full_y_axis": f"positive logarithmic; limits=min_positive*{a.lower_factor}, max*{a.upper_factor}; range={a.ylim_mode}",
        "original_loss_data_unchanged": True,
        "no_training_performed": True,
        "warnings": problems,
    }
    (outdir / "FIGURE_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print("AXIS AUDIT:", outdir / "AXIS_LIMITS.csv", flush=True)
    print("DONE: no training performed and no loss CSVs altered.", flush=True)
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(run())
