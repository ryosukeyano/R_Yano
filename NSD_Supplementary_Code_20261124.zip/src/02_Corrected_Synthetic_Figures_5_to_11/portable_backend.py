"""Pure-PyTorch adapters for Karube's original NSD model imports.

These replace unavailable compiled extension operations while leaving the
original model and sheaf-Laplacian builder code unmodified.  They use native
PyTorch sparse COO, index_add and Householder-product operations.  Numerical
training trajectories are NOT guaranteed identical to the original extension
implementations; use --backend native when exact historical dependency
behavior is important.
"""
import sys
import types
import torch


def install():
    if any(x in sys.modules for x in ('torch_sparse', 'torch_scatter', 'torch_householder')):
        raise RuntimeError('portable backend must be installed before importing original NSD modules')

    sp = types.ModuleType('torch_sparse')

    def to_sparse(index, value, rows, cols):
        return torch.sparse_coo_tensor(index.long(), value, (rows, cols), device=value.device).coalesce()

    def spmm(index, value, rows, cols, x):
        if x.size(0) != cols:
            raise ValueError(f'spmm input dimension mismatch: {x.shape}, expected [{cols},...]')
        return torch.sparse.mm(to_sparse(index, value, rows, cols), x)

    def coalesce(index, value, rows, cols, op='add'):
        if op != 'add':
            raise NotImplementedError(f'portable coalesce only supports add, got {op}')
        a = to_sparse(index, value, rows, cols)
        return a.indices(), a.values()

    def transpose(index, value, rows, cols):
        a = to_sparse(index, value, rows, cols).transpose(0,1).coalesce()
        return a.indices(),a.values()

    def spspmm(i1, v1, i2, v2, rows, mid, cols, coalesced=True):
        a = torch.sparse.mm(to_sparse(i1,v1,rows,mid), to_sparse(i2,v2,mid,cols)).coalesce()
        return a.indices(), a.values()

    sp.spmm=spmm; sp.coalesce=coalesce; sp.transpose=transpose; sp.spspmm=spspmm
    sys.modules['torch_sparse']=sp

    scatter = types.ModuleType('torch_scatter')
    def scatter_add(src, index, dim=0, out=None, dim_size=None):
        if index.ndim != 1:
            raise NotImplementedError('portable scatter_add supports 1D index only')
        if out is None:
            shape=list(src.shape)
            shape[dim]=int(dim_size if dim_size is not None else (index.max().item()+1 if index.numel() else 0))
            out=src.new_zeros(shape)
        return out.index_add(dim,index.long(),src)
    scatter.scatter_add=scatter_add
    sys.modules['torch_scatter']=scatter

    pyg=types.ModuleType('torch_geometric')
    utils=types.ModuleType('torch_geometric.utils')
    def degree(idx, num_nodes=None, dtype=None):
        n=int(num_nodes if num_nodes is not None else idx.max().item()+1)
        return torch.bincount(idx.long(),minlength=n).to(dtype=dtype or torch.float32)
    utils.degree=degree; pyg.utils=utils
    sys.modules['torch_geometric']=pyg
    sys.modules['torch_geometric.utils']=utils

    hh=types.ModuleType('torch_householder')
    def torch_householder_orgqr(mat):
        """Householder Q from compact lower-triangular reflector representation.

        The supplied original Orthogonal.forward constructs A = tril(-1)+I.
        For column j the associated reflector is (0,...,0,1,A[j+1:,j]).
        tau_j = 2/(1 + ||A[j+1:,j]||^2), which can be passed to the
        differentiable torch.linalg.householder_product.
        """
        lower=mat.tril(diagonal=-1)
        tau=2.0/(1.0+(lower*lower).sum(dim=-2))
        return torch.linalg.householder_product(mat,tau)
    hh.torch_householder_orgqr=torch_householder_orgqr
    sys.modules['torch_householder']=hh
