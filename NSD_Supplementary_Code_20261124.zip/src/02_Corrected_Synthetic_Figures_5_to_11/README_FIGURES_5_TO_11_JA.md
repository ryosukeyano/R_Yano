# 2026-11-21追加：Physica DのFigures 5–11と同じパネル配置で再プロット

**旧配布版では、各実験条件の `loss.png` は保存されても、論文と同じ複数パネル図の自動生成はありませんでした。今回追加しました。**

## 使い方（CPU版PyTorch上書きなし）

- `02_RUN_BASE_GPU.bat`、`03_RUN_SWEEPS_GPU.bat`、`04_RUN_SMOOTHED_GPU.bat` で訂正条件のNSDを計算（既に計算済みなら再実行は不要）。
- `09_ADD_REAL_GCN_FROM_SAVED_NSD.bat`：各ケースの既保存 `graph_and_xy.pt` に対し、真のグラフ畳み込みGCNだけを別途学習。同じグラフ・同じ入力・同じ教師値を使用し、NSD checkpointは変更しない。GPUを使用し、PyTorchをインストールしない。
- `08_DRAW_FIG5_TO_11.bat`：保存済み損失CSVを読み、論文のFig.5–11と同じ**パネル順序**でPNG/PDF/EPSを一括出力。PyTorch/GPUすら使わない。
- `10_STRICT_FIGURE_CHECK.bat`：全パネル・NSDランク・GCNデータが揃っているか検査。未計算ケースがあれば終了コード2。

**重要：** 以前の再計算パッケージの結果ディレクトリを使う場合は、新パッケージのフォルダ内に `results_BASE_GPU`、`results_SWEEPS_GPU`、`results_SMOOTHED_GPU` 等のディレクトリをコピーするか、手動コマンドの `--roots` でその場所を指定する。モデルの再計算は不要。**結果を移す際、checkpointを別のコードで上書きしないこと。**

## 図のパネル配置（論文元PDFに照合済み）

| Figure | パネル数 | 行・列の意味 | ターゲット |
|---|---|---|---|
| Fig. 5 | 3×4 | 行 ER/BA/WS、列 N=10/50/100/300 | `feature_sum_noise` |
| Fig. 6 | 2×3（5パネル） | ER、N=100、p=0.1/0.3/0.5/0.7/0.9 | `feature_sum_noise` |
| Fig. 7 | 2×4 | 行 BA m=2/4、列 N=10/50/100/300 | `feature_sum_noise` |
| Fig. 8 | 2×4 | 行 WS (k,p)=(4,0.1)/(6,0.2)、列 N=10/50/100/300 | `feature_sum_noise` |
| Fig. 9 | 3×3 | **実際の元図の行順 ER/BA/WS**、列 N=50/100/200 | `smoothed` |
| Fig. 10 | 1×3 | ER、N=50、p=0.1/0.5/0.9 | `smoothed` |
| Fig. 11 | 2×2 | 上段 BA m=2/4、下段 WS (4,0.1)/(6,0.2) | `smoothed` |

**元論文のFig.9キャプションには「上段BA／中段ER」とありますが、実際の元図のパネルは「上段ER／中段BA」です。図を差し替える際にキャプションも修正する。**

## 出力

`figures_5_to_11_corrected/` 内に各Fig. 5–11の以下2種類を保存します。

- `Fig05_first20_corrected_L2_seed0.{png,pdf,eps}`：元論文に合わせた最初の20エポック、線形縦軸
- `Fig05_full_corrected_L2_seed0.{png,pdf,eps}`：全エポック、対称対数縦軸（収束終盤の表示用）

Fig.5以外も同様です。線はCSVの実数値だけで描画し、平滑化や補間をしません。**欠けた条件がある図は `DRAFT_Fig...` という名前で保存し、欠測を図中に表示**します。DRAFTは投稿用に使わないこと。

`FIGURE_COVERAGE.csv` に各パネルの出典ケースフォルダ・足りないモデルを記録、`FIGURE_MANIFEST.json` に全体の状態を保存します。PNG・PDF・EPSはいずれも再プロットしたものです。

## 保存済みNSDだけでGCNを追加計算する理由

元のGPU版再計算BATは `--baselines none` で、GCNは計算していません。そのままでは元図に相当するGCN比較曲線が作れません。`09_ADD_REAL_GCN_FROM_SAVED_NSD.bat` を実行すると、**NSDを再計算することなく、同じ `graph_and_xy.pt` の入力で本来のGCNを計算**します。旧のグラフを使わないMLPをGCNと呼びません。GCNの隠れ幅16、NSDのランクとモデルパラメータ数は同一ではありません。厳密な容量一致比較が必要なら別途計画してください。

## CMDで個別実行

```
python plot_paper_figures_5_11.py --roots "G:\path\results_BASE_GPU" "G:\path\results_SWEEPS_GPU" "G:\path\results_SMOOTHED_GPU" --output-dir paper_plots --seed 0 --layers 2 --full-epochs
```

```
python run_GCN_on_saved_NSD.py --roots "G:\path\results_BASE_GPU" "G:\path\results_SWEEPS_GPU" "G:\path\results_SMOOTHED_GPU" --device cuda --epochs 1000 --resume
```

この2ファイルには `pip install`, `conda install`, `venv` の作成処理はありません。

**科学的注意**：訂正後の教師値と真のGCNで新しい結果を得るためのプログラムです。旧Figures 5–11の曲線を復元したと主張するものではなく、再計算後の論文差し替え用です。学習済みモデルの数値が揃うまでは元図を置き換えないこと。
