#!/usr/bin/env python3
"""Create corrected NSD ER/BA/WS Figures 5--11 in the manuscript's actual panel grids.

This plotting-only script reads *_loss.csv and case.json produced by run_nsd_corrected.py.
It never trains, generates, interpolates, or replaces unavailable experimental curves.
Missing cases / GCN baselines are visibly marked in DRAFT plots; --strict fails closed.
No CPU/GPU/PyTorch installation or import is performed.
"""
from __future__ import annotations
import argparse, csv, json, math, sys, re
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict

@dataclass(frozen=True)
class Panel:
    family: str
    n: int
    params: tuple
    task: str
    hidden: int
    def label(self):
        return f"{self.family}  N={self.n}  " + ', '.join(f'{k}={v}' for k,v in self.params)


def panel(fam,n,pars,task,hidden):
    return Panel(fam,n,tuple(sorted(pars.items())),task,hidden)


def figure_layouts():
    sizes=[10,50,100,300]
    return {
      5: (3,4,[panel(f,n,p,t,20) for f,p,t in [('ER',{'p':.1},'feature_sum_noise'),('BA',{'m':2},'feature_sum_noise'),('WS',{'k':4,'p':.1},'feature_sum_noise')] for n in sizes],
          'Graph-independent local-feature-sum target; rows ER, BA, WS; columns N=10,50,100,300.'),
      6: (2,3,[panel('ER',100,{'p':p},'feature_sum_noise',16) for p in [.1,.3,.5,.7,.9]] + [None],
          'Graph-independent local-feature-sum target; ER N=100; p=0.1,0.3,0.5 / 0.7,0.9.'),
      7: (2,4,[panel('BA',n,{'m':m},'feature_sum_noise',16) for m in [2,4] for n in sizes],
          'Graph-independent local-feature-sum target; BA m=2 (top), m=4 (bottom).'),
      8: (2,4,[panel('WS',n,{'k':k,'p':p},'feature_sum_noise',16) for k,p in [(4,.1),(6,.2)] for n in sizes],
          'Graph-independent local-feature-sum target; WS (k,p)=(4,0.1) (top), (6,0.2) (bottom).'),
      9: (3,3,[panel(f,n,pars,'smoothed',20) for f,pars in [('ER',{'p':.1}),('BA',{'m':2}),('WS',{'k':4,'p':.1})] for n in [50,100,200]],
          'Graph-smoothed target; visual row order ER, BA, WS; columns N=50,100,200. The old caption swaps ER and BA.'),
     10: (1,3,[panel('ER',50,{'p':p},'smoothed',16) for p in [.1,.5,.9]],
          'Graph-smoothed target; ER N=50; p=0.1,0.5,0.9.'),
     11: (2,2,[panel('BA',50,{'m':2},'smoothed',16),panel('BA',50,{'m':4},'smoothed',16),
                panel('WS',50,{'k':4,'p':.1},'smoothed',16),panel('WS',50,{'k':6,'p':.2},'smoothed',16)],
          'Graph-smoothed target; BA m=2,4 above; WS (k,p)=(4,0.1),(6,0.2) below.')
    }


def parse_args():
    p=argparse.ArgumentParser(description='Render Figures 5-11 in paper-matching layouts from corrected NSD/GNN loss CSVs')
    p.add_argument('--roots',nargs='+',default=['results_ALL_GPU','results_BASE_GPU','results_SWEEPS_GPU','results_SMOOTHED_GPU','results_COMPARE_GPU'],
                   help='One or more result directories; sources are NEVER combined within a panel')
    p.add_argument('--output-dir',default='figures_5_to_11_corrected')
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--layers',type=int,default=2)
    p.add_argument('--ranks',default='2,4,6,8',help='Comma-separated NSD ranks to include (default 2,4,6,8)')
    p.add_argument('--figures',default='5,6,7,8,9,10,11')
    p.add_argument('--full-epochs',action='store_true',help='In addition to first20, render all epochs in log y scale')
    p.add_argument('--include-mlp',action='store_true',help='Also display explicitly labeled graph-blind MLP if available')
    p.add_argument('--allow-no-gcn',action='store_true',help='Do not classify missing GCN baselines as incomplete')
    p.add_argument('--strict',action='store_true',help='Do not publish even draft figures if any required case/model incomplete')
    p.add_argument('--dpi',type=int,default=200)
    return p.parse_args()


def get_case_sources(roots,seed,layers):
    bykey=defaultdict(list)
    for priority,root in enumerate(roots):
        root=Path(root)
        if not root.is_dir():continue
        for p in sorted(root.glob('*/case.json')):
            try:
                d=json.loads(p.read_text(encoding='utf-8'))
                if int(d['seed'])!=seed or int(d['layers'])!=layers:continue
                key=panel(d['family'],int(d['N']),d['parameters'],d['task'],int(d['hidden_channels']))
                files=list(p.parent.glob('*_loss.csv'))
                count=len(files)
                finished=(p.parent/'completed.json').is_file()
                # Prefer a complete case with the most recorded model curves, then earlier listed roots.
                bykey[key].append((int(finished),count,-priority, p.parent,d))
            except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
                print(f'WARNING: cannot parse {p}: {e}',file=sys.stderr)
    return {key:sorted(choices,reverse=True,key=lambda x:x[:3])[0][3:] for key,choices in bykey.items()}


def load_curve(path):
    with path.open('r',encoding='utf-8-sig',newline='') as f:
        arr=list(csv.DictReader(f))
    epochs=[];values=[]
    for x in arr:
        try:
            ep=int(x['epoch']);val=float(x['training_mse'])
        except (KeyError,ValueError,TypeError):continue
        if ep>=1 and math.isfinite(val) and val>=0:
            epochs.append(ep);values.append(val)
    if not epochs or any(b<=a for a,b in zip(epochs,epochs[1:])):
        return None
    return epochs,values


def find_curves(folder,ranks,show_mlp):
    names=[(f'NSD_rank{d}',f'NSD (d={d})') for d in ranks]
    names += [('GCN_graph_using','GCN (graph convolution)')]
    if show_mlp:names += [('MLP_graph_blind','MLP (graph-blind)')]
    ans={}
    for fname,label in names:
        path=folder/(fname+'_loss.csv')
        if path.exists():
            curve=load_curve(path)
            if curve:ans[label]=curve
    return ans


def run():
    args=parse_args()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    figs=[int(x) for x in args.figures.split(',') if x.strip()]
    ranks=[int(x) for x in args.ranks.split(',') if x.strip()]
    if any(x not in range(5,12) for x in figs):raise SystemExit('--figures accepts numbers 5..11')
    roots=[str(Path(x).resolve()) for x in args.roots]
    sources=get_case_sources(roots,args.seed,args.layers)
    layouts=figure_layouts()
    outdir=Path(args.output_dir).resolve();outdir.mkdir(parents=True,exist_ok=True)
    reports=[];renders=[];all_complete=True
    palette={2:'#2b6bb2',4:'#d97731',6:'#378a62',8:'#c74b51'}
    model_style={f'NSD (d={d})': (palette.get(d,'#777777'),'-') for d in ranks}
    model_style.update({'GCN (graph convolution)':('#7659a6','--'), 'MLP (graph-blind)':('#6b7280',':')})
    for fig in figs:
        nrows,ncols,panels,caption=layouts[fig]
        panel_data=[];fail=[]
        for i,p in enumerate(panels):
            if p is None:
                panel_data.append((p,{},None,[]));continue
            if p not in sources:
                panel_data.append((p,{},None,['no completed case']));fail.append(i);continue
            folder,meta=sources[p]
            cur=find_curves(folder,ranks,args.include_mlp)
            missing=[f'NSD d={d}' for d in ranks if f'NSD (d={d})' not in cur]
            if not args.allow_no_gcn and 'GCN (graph convolution)' not in cur:missing.append('GCN')
            if not (folder/'completed.json').exists():missing.append('run incomplete')
            if missing:fail.append(i)
            panel_data.append((p,cur,folder,missing))
        incomplete=bool(fail)
        all_complete=all_complete and not incomplete
        for i,(p,cur,folder,missing) in enumerate(panel_data):
            if p is None:continue
            reports.append(dict(figure=fig,panel_index=i+1,row=i//ncols+1,column=i%ncols+1,
                               family=p.family,N=p.n,parameters=json.dumps(dict(p.params),sort_keys=True),
                               task=p.task,hidden_channels=p.hidden,layers=args.layers,seed=args.seed,
                               input_folder=str(folder) if folder else '',models='; '.join(cur.keys()),
                               status='OK' if not missing else 'MISSING / INCOMPLETE',issues='; '.join(missing)))
        if incomplete and args.strict:
            print(f'Fig.{fig}: not rendered in --strict mode: {len(fail)} incomplete/missing panel(s)',flush=True)
            continue
        variants=['first20']+(['full'] if args.full_epochs else [])
        for variant in variants:
            plot_name=f"{'DRAFT_' if incomplete else ''}Fig{fig:02d}_{variant}_corrected_L{args.layers}_seed{args.seed}"
            figobj,axes=plt.subplots(nrows,ncols,figsize=(4.25*ncols,3.15*nrows),squeeze=False)
            allvals=[]
            for p,cur,_,_ in panel_data:
                for xx,yy in cur.values():
                    allvals.extend(v for e,v in zip(xx,yy) if variant!='first20' or e<=20)
            upper=max(allvals)*1.08 if allvals else 1
            for i,(p,cur,folder,missing) in enumerate(panel_data):
                ax=axes.flat[i]
                if p is None:ax.axis('off');continue
                for model,xy in cur.items():
                    epochs,vals=xy
                    color,style=model_style.get(model,('#111111','-'))
                    ax.plot(epochs,vals,lw=1.5,color=color,ls=style,label=model)
                if variant=='first20':
                    ax.set_xlim(0,20)
                    ax.set_ylim(0,upper)
                    ax.set_xticks([0,5,10,15,20])
                else:
                    maxepoch=max((max(xy[0]) for xy in cur.values()),default=20)
                    ax.set_xlim(0,max(20,maxepoch))
                    ax.set_yscale('symlog',linthresh=1e-5) if allvals else None
                ax.set_title(p.label(),fontsize=10,pad=7)
                ax.set_xlabel('Epoch',fontsize=10)
                ax.set_ylabel('Training MSE',fontsize=10)
                ax.tick_params(labelsize=9)
                ax.grid(alpha=.19)
                if missing:
                    status='; '.join(missing)
                    ax.text(.5,.52,'NOT COMPLETE\n'+status,ha='center',va='center',transform=ax.transAxes,
                            color='#a61e2b',fontsize=9,fontweight='bold',wrap=True,
                            bbox={'facecolor':'white','alpha':.86,'edgecolor':'#dfb2b8','pad':4})
            handles=[Line2D([0],[0],color=model_style[m][0],linestyle=model_style[m][1],lw=1.8,label=m)
                     for m in [f'NSD (d={d})' for d in ranks]+['GCN (graph convolution)']+(['MLP (graph-blind)'] if args.include_mlp else [])]
            figobj.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,-.015),ncol=min(len(handles),6),fontsize=10,frameon=False)
            figobj.suptitle(f'Fig. {fig}: corrected NSD / GCN comparison — {variant} epochs',fontsize=13,fontweight='bold',y=.995)
            if incomplete:figobj.text(.5,.963,'INCOMPLETE: missing models/panels are not reconstructed',color='#aa1111',ha='center',fontsize=10,fontweight='bold')
            figobj.text(.5,.018,caption,ha='center',va='bottom',fontsize=9,wrap=True)
            figobj.tight_layout(rect=[.02,.075,.98,.945],h_pad=1.1,w_pad=.8)
            for ext in ['png','pdf','eps']:
                dest=outdir/(plot_name+'.'+ext)
                figobj.savefig(dest,dpi=args.dpi,bbox_inches='tight')
            plt.close(figobj)
            renders.append(plot_name)
            print(f"Fig.{fig} {variant}: {'DRAFT (missing data)' if incomplete else 'COMPLETE'} -> {plot_name}",flush=True)
    with (outdir/'FIGURE_COVERAGE.csv').open('w',newline='',encoding='utf-8-sig') as f:
        keys=['figure','panel_index','row','column','family','N','parameters','task','hidden_channels','layers','seed','input_folder','models','status','issues']
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(reports)
    info=dict(roots=roots,seed=args.seed,layers=args.layers,ranks=ranks,figure_ids=figs,full_epochs=args.full_epochs,
              figure_description='Layouts match the ORIGINAL manuscript Figs 5-11. Corrections use new training data, not historic curves.',
              incomplete_panels=sum(r['status']!='OK' for r in reports),
              eligible_for_paper=all_complete,output_images=renders,
              warning='DO NOT submit DRAFT figures. Missing curves never interpolated. Do not call MLP a GCN; GCN must be generated using graph edges.')
    (outdir/'FIGURE_MANIFEST.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('\nCOVERAGE:',outdir/'FIGURE_COVERAGE.csv',flush=True)
    if not all_complete:
        print('WARNING: at least one panel incomplete. This output is not a full paper replacement.',flush=True)
        if args.strict:raise SystemExit(2)
    else:print('All required conditions present. Review the numerical results before using in paper.',flush=True)

if __name__=='__main__':run()
