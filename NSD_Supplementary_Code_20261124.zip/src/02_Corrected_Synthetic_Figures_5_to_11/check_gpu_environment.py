"""Read-only inspection of the ACTIVE Python environment, never runs pip."""
import sys
print('Python executable:',sys.executable,flush=True)
try:
    import torch
except Exception as e:
    raise SystemExit('FAIL: torch import failed: '+repr(e))
print('PyTorch:',torch.__version__,'path:',torch.__file__,flush=True)
print('Compiled CUDA runtime:',torch.version.cuda,flush=True)
print('CUDA available:',torch.cuda.is_available(),flush=True)
if not torch.cuda.is_available():
    raise SystemExit('FAIL: The selected Python interpreter has NO usable CUDA. Existing environment was NOT changed. Set NSD_PYTHON to GPU Python.exe or activate GPU env and retry.')
print('GPU device count:',torch.cuda.device_count(),flush=True)
for idx in range(torch.cuda.device_count()):
    print('GPU',idx,':',torch.cuda.get_device_name(idx),'SM:',torch.cuda.get_device_capability(idx),flush=True)
try:
    arch=torch.cuda.get_arch_list()
    print('Architectures compiled into PyTorch:',arch,flush=True)
except Exception as e:
    print('Compiled architecture listing unavailable:',repr(e),flush=True)
# Exercise real CUDA ops. Incompatible legacy GPU builds may report cuda available but still fail.
try:
    a=torch.randn(4,4,device='cuda',requires_grad=True)
    b=(a@a.T).sum(); b.backward()
    if a.grad is None or not torch.isfinite(a.grad).all():
        raise RuntimeError('CUDA backward failed to create finite gradients')
    torch.cuda.synchronize()
    print('CUDA matrix operation + backward: PASS',flush=True)
    import networkx
    print('networkx:',networkx.__version__,flush=True)
    import matplotlib
    print('matplotlib:',matplotlib.__version__,flush=True)
except Exception as e:
    raise SystemExit('FAIL: CUDA or dependency smoke test: '+repr(e))
print('PASS: GPU environment is usable without installing anything.',flush=True)
