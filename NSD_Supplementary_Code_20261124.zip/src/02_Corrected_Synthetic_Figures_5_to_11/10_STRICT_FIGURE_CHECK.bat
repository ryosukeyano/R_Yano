@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
echo Strict check: all panels, NSD ranks and genuine GCN must be present.
"%NSD_PYTHON%" plot_paper_figures_5_11.py --roots results_ALL_GPU results_BASE_GPU results_SWEEPS_GPU results_SMOOTHED_GPU results_COMPARE_GPU --output-dir figures_5_to_11_strict --layers 2 --seed 0 --ranks 2,4,6,8 --full-epochs --strict
if errorlevel 1 goto :failed
echo.
echo PASS: all figure panels have the required models and completed cases.
pause
exit /b 0
:failed
echo.
echo NOT READY: check figures_5_to_11_strict\FIGURE_COVERAGE.csv for missing cases/models.
pause
exit /b 2
