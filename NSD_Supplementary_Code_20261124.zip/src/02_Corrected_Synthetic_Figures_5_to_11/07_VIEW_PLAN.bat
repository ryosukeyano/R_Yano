@echo off
setlocal
cd /d "%~dp0"
if not defined NSD_PYTHON set "NSD_PYTHON=python"
"%NSD_PYTHON%" run_nsd_corrected.py --preset paper_all --tasks feature_sum_noise,smoothed --plan-only --ranks 2,4,6,8 --seeds 0 --layers 2
pause
