# verify_rank1_sheaf_d1.py
# Python 3.9+
#
# Purpose:
#   Numerical verification of the d=1 rank-one sheaf theory:
#   Lemma 29, Theorem 31, and Proposition 32.
#
# Dependencies:
#   numpy
#   matplotlib is optional, only used for plots.
#
# Run:
#   python verify_rank1_sheaf_d1.py
#
# Output:
#   d1_sheaf_verification_summary.csv
#   d1_sheaf_verification_details.csv

import argparse
import csv
import os
from collections import deque

import numpy as np


# -----------------------------
# Basic graph utilities
# -----------------------------
def unsigned_incidence_matrix(n, edges):
    """
    A[v,e] = 1 if vertex v is incident to edge e, otherwise 0.
    Shape: n x m.
    """
    A = np.zeros((n, len(edges)), dtype=float)
    for k, (u, v) in enumerate(edges):
        A[u, k] = 1.0
        A[v, k] = 1.0
    return A


def bipartition(n, edges):
    """
    Return (is_bipartite, part), where part[v] is 0 or 1.
    If not bipartite, part is None.
    """
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)

    part = [-1] * n
    for s in range(n):
        if part[s] != -1:
            continue
        part[s] = 0
        q = deque([s])
        while q:
            u = q.popleft()
            for v in adj[u]:
                if part[v] == -1:
                    part[v] = 1 - part[u]
                    q.append(v)
                elif part[v] == part[u]:
                    return False, None
    return True, np.array(part, dtype=int)


def matrix_rank(A, tol=1e-11):
    return np.linalg.matrix_rank(A, tol=tol)


# -----------------------------
# Rank-one sheaf construction
# -----------------------------
def construct_rank1_sheaf_from_edge_weights(n, edges, g, signs=None):
    """
    Construct a rank-one sheaf F in Bun_1^x(G) from positive edge weights g.

    Given positive g_e, set
        s = A g,
        zeta_v = sign_v * sqrt(s_v),
        F_{v<-e} = sqrt(g_e) / zeta_v.

    Then
        F_{u<-e} zeta_u = F_{v<-e} zeta_v = sqrt(g_e),
    so zeta is in ker L_F.

    Moreover,
        D_F = I
    because
        sum_{e incident to v} F_{v<-e}^2
        = sum_e g_e / zeta_v^2
        = 1.
    Therefore zeta also spans ker Delta_F when the kernel is one-dimensional.
    """
    A = unsigned_incidence_matrix(n, edges)
    s = A @ g

    if np.any(s <= 0):
        raise ValueError("A g must be strictly positive at every vertex.")

    if signs is None:
        signs = np.ones(n)

    zeta = signs * np.sqrt(s)

    # R[e,0] is F_{u<-e}, R[e,1] is F_{v<-e} for edge e=(u,v)
    R = np.zeros((len(edges), 2), dtype=float)
    for k, (u, v) in enumerate(edges):
        root_g = np.sqrt(g[k])
        R[k, 0] = root_g / zeta[u]
        R[k, 1] = root_g / zeta[v]

    return R, zeta


def sheaf_laplacian_and_degree(n, edges, R):
    """
    Rank-one sheaf Laplacian.

    For edge e=(u,v):
        delta_e(x) = r_u x_u - r_v x_v.

    Contribution to L_F:
        L_uu += r_u^2
        L_vv += r_v^2
        L_uv -= r_u r_v
        L_vu -= r_u r_v

    Degree:
        D_vv = sum_{e incident to v} r_{v<-e}^2.
    """
    L = np.zeros((n, n), dtype=float)
    D = np.zeros(n, dtype=float)

    for k, (u, v) in enumerate(edges):
        ru = R[k, 0]
        rv = R[k, 1]

        L[u, u] += ru * ru
        L[v, v] += rv * rv
        L[u, v] -= ru * rv
        L[v, u] -= ru * rv

        D[u] += ru * ru
        D[v] += rv * rv

    return L, D


def normalized_sheaf_laplacian(L, D):
    if np.any(D <= 0):
        raise ValueError("D must be strictly positive for normalized sheaf Laplacian.")

    D_inv_sqrt = np.diag(1.0 / np.sqrt(D))
    Delta = D_inv_sqrt @ L @ D_inv_sqrt
    return Delta


def kernel_info(Delta, tol=1e-10):
    """
    Return eigenvalues, numerical kernel dimension, and smallest eigenvector.
    """
    eigvals, eigvecs = np.linalg.eigh(Delta)
    idx = np.argsort(eigvals)
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]
    kdim = int(np.sum(eigvals < tol))
    return eigvals, kdim, eigvecs[:, 0]


def angle_error(u, v):
    """
    Sign-invariant distance between normalized vectors.
    """
    u = u / np.linalg.norm(u)
    v = v / np.linalg.norm(v)
    return min(np.linalg.norm(u - v), np.linalg.norm(u + v))


# -----------------------------
# Theoretical checks
# -----------------------------
def check_single_trial(n, edges, rng, force_positive_zeta=True):
    """
    One trial:
      - sample positive edge weights g
      - construct rank-one sheaf
      - check Delta_F zeta = 0
      - check zeta^2 = A g
      - check bipartite quadratic obstruction when relevant
    """
    m = len(edges)
    A = unsigned_incidence_matrix(n, edges)

    # lognormal gives positive edge weights over several scales
    g = rng.lognormal(mean=0.0, sigma=0.8, size=m)

    if force_positive_zeta:
        signs = np.ones(n)
    else:
        signs = rng.choice([-1.0, 1.0], size=n)

    R, zeta = construct_rank1_sheaf_from_edge_weights(n, edges, g, signs=signs)
    L, D = sheaf_laplacian_and_degree(n, edges, R)
    Delta = normalized_sheaf_laplacian(L, D)

    eigvals, kdim, eigvec = kernel_info(Delta)

    # Lemma 29 residuals
    kernel_residual = np.linalg.norm(Delta @ zeta) / max(np.linalg.norm(zeta), 1e-15)
    cone_residual = np.linalg.norm(zeta**2 - A @ g) / max(np.linalg.norm(zeta**2), 1e-15)
    degree_residual = np.linalg.norm(D - np.ones(n)) / np.sqrt(n)

    evector_error = angle_error(eigvec, zeta)

    is_bip, part = bipartition(n, edges)
    bip_quad_residual = None
    if is_bip:
        lhs = np.sum(zeta[part == 0] ** 2)
        rhs = np.sum(zeta[part == 1] ** 2)
        bip_quad_residual = abs(lhs - rhs) / max(abs(lhs) + abs(rhs), 1e-15)

    return {
        "min_eig": float(eigvals[0]),
        "second_eig": float(eigvals[1]) if len(eigvals) > 1 else np.nan,
        "kernel_dim": kdim,
        "kernel_residual": float(kernel_residual),
        "cone_residual": float(cone_residual),
        "degree_residual": float(degree_residual),
        "eigvec_angle_error": float(evector_error),
        "bip_quad_residual": float(bip_quad_residual) if bip_quad_residual is not None else np.nan,
    }


def check_ridge_realization(n, edges, rng, n_points=200):
    """
    Verify the exact ReLU ridge realization used in Theorem 31.

    This check is meaningful for a positive zeta.
    We construct F so that ker Delta_F = span(zeta), then test:

        h_{F,b,c}(X) = ReLU(<X,zeta> + beta)

    using the scalarized NSD-b unit.

    Because D_F = I in our construction,
        pi_F X = <X, zhat> zhat.
    """
    A = unsigned_incidence_matrix(n, edges)
    g = rng.lognormal(mean=0.0, sigma=0.8, size=len(edges))
    R, zeta = construct_rank1_sheaf_from_edge_weights(
        n, edges, g, signs=np.ones(n)
    )

    L, D = sheaf_laplacian_and_degree(n, edges, R)
    Delta = normalized_sheaf_laplacian(L, D)

    eigvals, kdim, eigvec = kernel_info(Delta)

    zhat = zeta / np.linalg.norm(zeta)
    v0 = int(np.argmax(np.abs(zhat)))

    # Since zeta is positive, t > 0.
    t = zeta[v0] / (np.linalg.norm(zeta) ** 2)

    beta = rng.normal()
    b = np.zeros(n)
    c = np.zeros(n)

    b[v0] = t * beta
    c[v0] = 1.0 / t

    X = rng.normal(size=(n_points, n))

    # Projection pi_F X = <X, zhat> zhat
    proj = (X @ zhat)[:, None] * zhat[None, :]

    relu = lambda y: np.maximum(y, 0.0)

    h = relu(proj + b[None, :]) @ c
    target = relu(X @ zeta + beta)

    max_err = np.max(np.abs(h - target))
    rms_err = np.sqrt(np.mean((h - target) ** 2))

    return {
        "ridge_max_error": float(max_err),
        "ridge_rms_error": float(rms_err),
        "ridge_kernel_dim": int(kdim),
        "ridge_min_eig": float(eigvals[0]),
    }


def sample_cone_dimension(n, edges, rng, samples=500):
    """
    Sample s = A g, g > 0, and estimate the dimension of the sampled cloud.
    For connected graphs:
      - non-bipartite: rank(A) = n
      - bipartite: rank(A) = n-1
    """
    A = unsigned_incidence_matrix(n, edges)
    G = rng.lognormal(mean=0.0, sigma=1.0, size=(len(edges), samples))
    S = A @ G

    # Centering estimates affine dimension of the cone sample.
    Sc = S - S.mean(axis=1, keepdims=True)
    sample_rank = matrix_rank(Sc, tol=1e-9)
    A_rank = matrix_rank(A)

    return A_rank, sample_rank


# -----------------------------
# Graph collection
# -----------------------------
def get_graphs():
    """
    Small graphs used for d=1 verification.

    triangle: non-bipartite
    K4: non-bipartite
    house: non-bipartite, triangle-free? The usual house has one square plus roof triangle.
    C4: bipartite
    path5: bipartite
    """
    graphs = {}

    graphs["triangle_nonbip"] = (
        3,
        [(0, 1), (1, 2), (2, 0)],
    )

    graphs["K4_nonbip"] = (
        4,
        [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)],
    )

    # House graph: square 0-1-2-3-0 plus roof vertex 4 connected to 1 and 2.
    # Contains triangle 1-2-4.
    graphs["house_nonbip"] = (
        5,
        [(0, 1), (1, 2), (2, 3), (3, 0), (1, 4), (2, 4)],
    )

    graphs["C4_bip"] = (
        4,
        [(0, 1), (1, 2), (2, 3), (3, 0)],
    )

    graphs["path5_bip"] = (
        5,
        [(0, 1), (1, 2), (2, 3), (3, 4)],
    )

    return graphs


# -----------------------------
# Main
# -----------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=int, default=600)
    parser.add_argument("--seed", type=int, default=12345)
    parser.add_argument("--outdir", type=str, default=".")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    rng = np.random.default_rng(args.seed)
    graphs = get_graphs()

    details_path = os.path.join(args.outdir, "d1_sheaf_verification_details.csv")
    summary_path = os.path.join(args.outdir, "d1_sheaf_verification_summary.csv")

    detail_rows = []
    summary_rows = []

    for name, (n, edges) in graphs.items():
        A = unsigned_incidence_matrix(n, edges)
        is_bip, part = bipartition(n, edges)

        A_rank, sample_rank = sample_cone_dimension(n, edges, rng, samples=args.samples)

        trial_rows = []
        for trial in range(args.samples):
            row = check_single_trial(
                n=n,
                edges=edges,
                rng=rng,
                force_positive_zeta=False,
            )
            row.update({
                "graph": name,
                "trial": trial,
                "n": n,
                "m": len(edges),
                "is_bipartite": is_bip,
                "rank_A": A_rank,
                "sample_cone_rank": sample_rank,
            })
            detail_rows.append(row)
            trial_rows.append(row)

        # Ridge realization test is most relevant for non-bipartite graphs.
        ridge_row = check_ridge_realization(n, edges, rng, n_points=300)

        def max_of(key):
            return float(np.nanmax([r[key] for r in trial_rows]))

        def mean_of(key):
            return float(np.nanmean([r[key] for r in trial_rows]))

        summary = {
            "graph": name,
            "n": n,
            "m": len(edges),
            "is_bipartite": is_bip,
            "rank_A": A_rank,
            "sample_cone_rank": sample_rank,
            "max_min_eig": max_of("min_eig"),
            "mean_min_eig": mean_of("min_eig"),
            "max_kernel_residual": max_of("kernel_residual"),
            "max_cone_residual": max_of("cone_residual"),
            "max_degree_residual": max_of("degree_residual"),
            "max_eigvec_angle_error": max_of("eigvec_angle_error"),
            "max_bip_quad_residual": max_of("bip_quad_residual"),
        }
        summary.update(ridge_row)
        summary_rows.append(summary)

    # Write details CSV
    detail_fields = [
        "graph", "trial", "n", "m", "is_bipartite",
        "rank_A", "sample_cone_rank",
        "min_eig", "second_eig", "kernel_dim",
        "kernel_residual", "cone_residual", "degree_residual",
        "eigvec_angle_error", "bip_quad_residual",
    ]

    with open(details_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=detail_fields)
        writer.writeheader()
        for r in detail_rows:
            writer.writerow({k: r.get(k, "") for k in detail_fields})

    # Write summary CSV
    summary_fields = [
        "graph", "n", "m", "is_bipartite",
        "rank_A", "sample_cone_rank",
        "max_min_eig", "mean_min_eig",
        "max_kernel_residual", "max_cone_residual",
        "max_degree_residual", "max_eigvec_angle_error",
        "max_bip_quad_residual",
        "ridge_max_error", "ridge_rms_error",
        "ridge_kernel_dim", "ridge_min_eig",
    ]

    with open(summary_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=summary_fields)
        writer.writeheader()
        for r in summary_rows:
            writer.writerow({k: r.get(k, "") for k in summary_fields})

    # Print summary
    print("\n=== d=1 rank-one sheaf verification summary ===")
    print(f"samples per graph = {args.samples}")
    print(f"details: {details_path}")
    print(f"summary: {summary_path}\n")

    for r in summary_rows:
        print(f"[{r['graph']}]")
        print(f"  bipartite              : {r['is_bipartite']}")
        print(f"  rank(A)                : {r['rank_A']} / n={r['n']}")
        print(f"  sampled cone rank       : {r['sample_cone_rank']}")
        print(f"  max min eigenvalue      : {r['max_min_eig']:.3e}")
        print(f"  max ||Delta zeta||      : {r['max_kernel_residual']:.3e}")
        print(f"  max ||zeta^2 - A g||    : {r['max_cone_residual']:.3e}")
        print(f"  max eigvec angle error  : {r['max_eigvec_angle_error']:.3e}")
        if r["is_bipartite"]:
            print(f"  max bipartite residual  : {r['max_bip_quad_residual']:.3e}")
        print(f"  ridge max error         : {r['ridge_max_error']:.3e}")
        print(f"  ridge rms error         : {r['ridge_rms_error']:.3e}")
        print("")

    print("Interpretation:")
    print("  1. max ||Delta zeta|| close to 0 verifies that constructed zeta is a kernel direction.")
    print("  2. max ||zeta^2 - A g|| close to 0 verifies the incidence-cone characterization.")
    print("  3. For non-bipartite connected graphs, rank(A)=n indicates full-dimensional attainable squared directions.")
    print("  4. For bipartite graphs, rank(A)=n-1 and the bipartite quadratic residual should be close to 0.")
    print("  5. ridge errors close to 0 verify the exact ReLU ridge-unit realization used in Theorem 31.")


if __name__ == "__main__":
    main()