"""
Numerical test of the bipartite obstruction (Proposition 32) at the level of
APPROXIMATION, not at the level of the algebraic identity.

For each graph G we
  (a) sample attainable rank-one limit directions  zeta = eps .* sqrt(A g),  g > 0,
  (b) fit  f(X) = sum_{v in V1} X_v^2  by finite sums of ReLU ridge units
      with those directions, letting the number of units n grow,
  (c) independently report a uniform-norm analytic lower bound on
      bipartite graphs (Lemma A). The analytic bound is NOT a lower
      bound on the finite-sample relative test RMSE reported in the plot.

The sampled fitting errors decrease on non-bipartite graphs but remain
high at the tested widths on the bipartite graphs. No asymptotic rate
is inferred from this finite-sample experiment.
"""

import numpy as np
from itertools import combinations
from collections import deque

rng_global = np.random.default_rng(20260907)

# ----------------------------------------------------------------------
# graphs
# ----------------------------------------------------------------------
GRAPHS = {
    "triangle":  (3, [(0, 1), (1, 2), (2, 0)]),
    "K4":        (4, list(combinations(range(4), 2))),
    "house":     (5, [(0, 1), (1, 2), (2, 3), (3, 0), (1, 4), (2, 4)]),
    "C4":        (4, [(0, 1), (1, 2), (2, 3), (3, 0)]),
    "P5":        (5, [(0, 1), (1, 2), (2, 3), (3, 4)]),
    "C6":        (6, [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0)]),
    "C6+chord":  (6, [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0), (0, 2)]),
}


def incidence(n, edges):
    A = np.zeros((n, len(edges)))
    for k, (u, v) in enumerate(edges):
        A[u, k] = 1.0
        A[v, k] = 1.0
    return A


def two_colour(n, edges):
    """Return +-1 colouring if bipartite, else None."""
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    col = np.zeros(n, dtype=int)
    for s in range(n):
        if col[s] != 0:
            continue
        col[s] = 1
        q = deque([s])
        while q:
            x = q.popleft()
            for y in adj[x]:
                if col[y] == 0:
                    col[y] = -col[x]
                    q.append(y)
                elif col[y] == col[x]:
                    return None
    return col


# ----------------------------------------------------------------------
# attainable rank-one limit directions  (Lemma 29, constructive direction)
# ----------------------------------------------------------------------
def sample_directions(A, n_dir, rng):
    E = A.shape[1]
    g = rng.random((n_dir, E)) + 1e-2          # strictly positive edge weights
    s = g @ A.T                                # zeta^{o2} = A g
    signs = rng.choice([-1.0, 1.0], size=s.shape)
    zeta = signs * np.sqrt(s)
    zeta /= np.linalg.norm(zeta, axis=1, keepdims=True)
    return zeta


def relu_features(X, zeta, beta):
    return np.maximum(X @ zeta.T + beta, 0.0)


# ----------------------------------------------------------------------
# certified lower bound from the annihilating functional
# ----------------------------------------------------------------------
def bump_norms(m=200001):
    """1-D bump phi(t) = exp(-1/(1-t^2)) on (-1,1): returns ||phi||_1, ||phi''||_1."""
    t = np.linspace(-1.0, 1.0, m)
    t = t[1:-1]
    u = 1.0 - t**2
    phi = np.exp(-1.0 / u)
    # phi'  = -2t/u^2 * phi
    # phi'' = phi * ( (-2/u^2 - 8t^2/u^3) + (2t/u^2)^2 )
    d2 = phi * ((-2.0 / u**2 - 8.0 * t**2 / u**3) + (2.0 * t / u**2) ** 2)
    dt = t[1] - t[0]
    return np.trapezoid(phi, dx=dt), np.trapezoid(np.abs(d2), dx=dt)


def certified_bound(N, n_V1):
    """Bipartite only: uniform-norm bound for f=sum_{v in V1} X_v**2 on [-1,1]^N."""
    p1, p2 = bump_norms()
    return 2.0 * n_V1 * p1 / (N * p2)


# ----------------------------------------------------------------------
# experiment
# ----------------------------------------------------------------------
def run_graph(name, n_nodes, edges, n_list, M=4000, rng=None, ridge=1e-8):
    rng = rng or np.random.default_rng(0)
    A = incidence(n_nodes, edges)
    col = two_colour(n_nodes, edges)
    bipartite = col is not None

    # target: sum over one side (for non-bipartite graphs use an arbitrary
    # subset of the same size, so that the target has the same scale)
    if bipartite:
        V1 = np.where(col > 0)[0]
    else:
        V1 = np.arange((n_nodes + 1) // 2)
    y_fun = lambda X: (X[:, V1] ** 2).sum(axis=1)

    Xtr = rng.uniform(-1.0, 1.0, size=(M, n_nodes))
    Xva = rng.uniform(-1.0, 1.0, size=(M, n_nodes))
    Xte = rng.uniform(-1.0, 1.0, size=(M, n_nodes))
    ytr, yva, yte = y_fun(Xtr), y_fun(Xva), y_fun(Xte)

    n_max = max(n_list)
    zeta = sample_directions(A, n_max, rng)
    beta = rng.uniform(-np.sqrt(n_nodes), np.sqrt(n_nodes), size=n_max)

    Ptr_all = relu_features(Xtr, zeta, beta)
    Pva_all = relu_features(Xva, zeta, beta)
    Pte_all = relu_features(Xte, zeta, beta)

    lams = 10.0 ** np.arange(-12, 2, 1.0)
    out = []
    for n in n_list:
        Ptr = np.hstack([Ptr_all[:, :n], np.ones((M, 1))])
        Pva = np.hstack([Pva_all[:, :n], np.ones((M, 1))])
        Pte = np.hstack([Pte_all[:, :n], np.ones((M, 1))])
        sc = np.linalg.norm(Ptr, axis=0) / np.sqrt(M)
        sc[sc == 0] = 1.0
        Ptr, Pva, Pte = Ptr / sc, Pva / sc, Pte / sc
        # single SVD, then ridge for every lambda at no extra cost
        U, s, Vt = np.linalg.svd(Ptr, full_matrices=False)
        Uy = U.T @ ytr
        best = (np.inf, None)
        for lam in lams:
            a = Vt.T @ (s * Uy / (s ** 2 + lam * M))
            e = np.sqrt(((yva - Pva @ a) ** 2).mean())
            if e < best[0]:
                best = (e, a)
        a = best[1]
        r = yte - Pte @ a
        out.append((n,
                    np.sqrt((r ** 2).mean()),          # test RMSE
                    np.abs(r).max()))                  # test sup-norm error
    return dict(name=name, bipartite=bipartite, N=n_nodes, E=len(edges),
                rankA=np.linalg.matrix_rank(A), nV1=len(V1),
                bound=(certified_bound(n_nodes, len(V1)) if bipartite else np.nan),
                true_f_sup=float(len(V1)),
                fnorm=float(np.abs(yte).max()), curve=out)


def main(n_seeds=4, n_list=(8, 16, 32, 64, 128, 256, 512, 1024)):
    n_list = list(n_list)
    summary = {}
    for name, (n_nodes, edges) in GRAPHS.items():
        curves = []
        for k in range(n_seeds):
            res = run_graph(name, n_nodes, edges, n_list,
                            rng=np.random.default_rng(1000 * k + len(name)))
            curves.append([rmse / res["fnorm"] for (_, rmse, _) in res["curve"]])
        C = np.array(curves)
        summary[name] = dict(mean=C.mean(0), std=C.std(0), meta=res)

    hdr = (f"{'graph':10s} {'type':9s} {'N':>2s} {'|E|':>3s} {'rkA':>3s} "
           + " ".join(f"n={n:<6d}" for n in n_list) + "  L_inf bound / true ||f||_inf (bip. only)")
    print(hdr)
    print("-" * len(hdr))
    for name, S in summary.items():
        m, sd, meta = S["mean"], S["std"], S["meta"]
        print(f"{name:10s} {'bip.' if meta['bipartite'] else 'non-bip.':9s} "
              f"{meta['N']:2d} {meta['E']:3d} {meta['rankA']:3d} "
              + " ".join(f"{a:.3f}({b:.3f})" for a, b in zip(m, sd))
              + (f"  {meta['bound']/meta['true_f_sup']:.2e}" if meta['bipartite'] else "  --"))

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6.4, 4.2))
        for name, S in summary.items():
            meta = S["meta"]
            ax.errorbar(n_list, S["mean"], yerr=S["std"],
                        marker="o" if meta["bipartite"] else "s",
                        ms=3.5, lw=1.2, capsize=2,
                        ls="-" if meta["bipartite"] else "--",
                        label=f"{name} ({'bip.' if meta['bipartite'] else 'non-bip.'})")
        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_xlabel("number of sampled ReLU ridge features $n$")
        ax.set_ylabel(r"relative test RMSE")
        ax.grid(alpha=0.3, which="both")
        ax.legend(fontsize=7.5, ncol=2)
        fig.tight_layout()
        fig.savefig("bipartite_density.pdf")
        fig.savefig("bipartite_density.png", dpi=180)
        print("\nwrote bipartite_density.{pdf,png}")
    except ImportError:
        print("\nmatplotlib unavailable; figure skipped")
    return summary


if __name__ == "__main__":
    main()
