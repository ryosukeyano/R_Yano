#!/usr/bin/env python3
"""Parameter-matched ER/BA/WS normalized Laplacian spectral ensembles.

The pseudorandom graphs are REGENERATED using exactly the deterministic seeds
of signless_ER_BA_WS_reproduce.py, never asserted to be the original NSD
training realizations. This diagnostic is NOT an analysis of learned sheaf
spectra, learning rate, or regression accuracy.

Usage:
    OPENBLAS_NUM_THREADS=1 python spectral_distribution_ER_BA_WS.py \
        --reps 128 --outdir .
"""
import argparse, csv, sys
from pathlib import Path
import numpy as np
import networkx as nx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Keep sampling exactly matched to the independently generated signless-ensemble run.
try:
    from signless_ER_BA_WS_reproduce import configurations, sample_seed, draw
except ImportError as e:
    raise ImportError('Place signless_ER_BA_WS_reproduce.py in the same folder') from e

BINS = np.linspace(0, 2, 41)
TAU = 0.5
DEPTH = 4
STYLES = [('ER','p=0.1','ER  p=0.1'), ('BA','m=2','BA  m=2'),
          ('BA','m=4','BA  m=4'), ('WS','k=4,p=0.1','WS  k=4, p=0.1'),
          ('WS','k=6,p=0.2','WS  k=6, p=0.2')]


def spectrum_lcc(G):
    comp=max(nx.connected_components(G),key=len)
    L=G.subgraph(comp)
    adj=nx.to_numpy_array(L, nodelist=sorted(comp), dtype=float)
    deg=adj.sum(axis=1)
    n=len(deg)
    if n==1:
        return np.array([0.0])
    s=1/np.sqrt(deg)
    normlap=np.eye(n)-(s[:,None]*adj*s[None,:])
    eig=np.linalg.eigvalsh(normlap)
    return np.clip(eig,0,2)


def sample_metrics(eig):
    n=len(eig)
    modes=eig[1:] if n>1 else np.array([],dtype=float)
    # The nonconstant modes of the illustrative linear Euler filter.
    return {'lcc_n':n,
      'frac_low_lam_le_0p5':float(np.mean(eig<=0.5)),
      'frac_high_lam_ge_1p5':float(np.mean(eig>=1.5)),
      'neighbor_filter_energy':float(np.mean((1-eig)**2)),
      'linear_retention_L4_tau0p5':float(np.mean((1-TAU*modes)**(2*DEPTH))) if len(modes)>0 else float('nan'),
      'lambda_2':float(eig[1]) if n>1 else float('nan'),
      'lambda_max':float(eig[-1])}


def run(reps,outdir):
    configs=configurations()
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    rows=[]; dists={}; retains={}
    for idx,((family,n,param),groups) in enumerate(configs.items(),start=1):
        h=[]; curve=[]
        for rep in range(reps):
            seed=sample_seed(family,n,param,rep)
            G=draw(family,n,param,seed)
            eig=spectrum_lcc(G)
            y=sample_metrics(eig)
            rows.append({'family':family,'n':n,'parameters':param,'replicate':rep,'seed':seed,**y})
            h.append(np.histogram(eig,bins=BINS)[0] / (len(eig)*(BINS[1]-BINS[0])))
            modes=eig[1:]
            curve.append([float(np.mean((1-TAU*modes)**(2*L))) if len(modes) else np.nan for L in range(0,9)])
        dists[(family,n,param)]=np.mean(h,axis=0)
        retains[(family,n,param)]=np.nanmedian(np.array(curve),axis=0)
        print(f'[{idx:2d}/{len(configs)}] {family:2s}, N={n:3d}, {param:12s}: {reps} graphs',flush=True)
    summary=[]
    for key,groups in configs.items():
        family,n,param=key
        s=[row for row in rows if (row['family'],row['n'],row['parameters'])==key]
        line={'family':family,'n':n,'parameters':param,'repeats':reps,'groups':';'.join(sorted(groups))}
        for metric in ['frac_low_lam_le_0p5','frac_high_lam_ge_1p5','neighbor_filter_energy',
                       'linear_retention_L4_tau0p5','lambda_2','lambda_max']:
            a=np.asarray([row[metric] for row in s]);a=a[np.isfinite(a)]
            for k,value in {'mean':np.mean(a),'median':np.median(a),'q10':np.quantile(a,.1),'q90':np.quantile(a,.9)}.items():
                line[f'{metric}_{k}']=float(value)
        summary.append(line)
    for filename,records in [('normalized_spectrum_draw_metrics.csv',rows),
                              ('normalized_spectrum_summary.csv',summary)]:
        with open(outdir/filename,'w',newline='',encoding='utf8') as fh:
            w=csv.DictWriter(fh,fieldnames=list(records[0].keys()));w.writeheader();w.writerows(records)

    density_rows=[]
    for (fam,n,param),density in dists.items():
        for i,val in enumerate(density):
            density_rows.append(dict(family=fam,n=n,parameters=param,bin_left=BINS[i],bin_right=BINS[i+1],
                                      bin_center=(BINS[i]+BINS[i+1])/2,density=float(val)))
    with open(outdir/'normalized_spectrum_histograms.csv','w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(density_rows[0].keys()));w.writeheader();w.writerows(density_rows)

    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(2,2,figsize=(9.3,6.5))
    center=(BINS[:-1]+BINS[1:])/2
    for j,N in enumerate([50,300]):
        ax1=axes[0,j];ax2=axes[1,j]
        for fam,param,label in STYLES:
            k=(fam,N,param)
            ax1.plot(center,dists[k],lw=1.5,label=label)
            ax2.plot(range(9),retains[k],lw=1.5,marker='o',ms=2.6,label=label)
        ax1.set_xlim(0,2);ax1.set_xlabel(r'Normalized graph Laplacian eigenvalue, $\lambda$')
        ax1.set_ylabel('Mean spectral density' if j==0 else '')
        ax1.set_title(f'(a)' if j==0 else '(b)', loc='left',fontweight='bold')
        ax1.set_title(f'N={N} (largest connected component)')
        ax1.grid(alpha=.15)
        ax2.set_ylim(bottom=0);ax2.set_xlim(0,8);ax2.set_xticks(range(0,9,2))
        ax2.set_xlabel(r'Illustrative linear propagation steps, $L$')
        ax2.set_ylabel(r'$N_{\perp}^{-1}\sum_{\lambda>0}(1-\lambda/2)^{2L}$' if j==0 else '')
        ax2.set_title('(c)' if j==0 else '(d)', loc='left',fontweight='bold')
        ax2.grid(alpha=.18)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=3,bbox_to_anchor=(0.5,0.0),frameon=False,fontsize=10)
    fig.tight_layout(rect=[0,0.10,1,1],h_pad=1.35,w_pad=1.2)
    for ext in ['eps','pdf','png']:
        fig.savefig(outdir/f'normalized_spectrum_ER_BA_WS.{ext}',dpi=190)
    plt.close(fig)
    print('Summary N=50,300:',flush=True)
    for s in summary:
        if s['n'] in [50,300] and s['parameters'] in [x[1] for x in STYLES]:
            print(f"{s['family']:2s} N={s['n']:3d} {s['parameters']:12s} "
                  f"low={s['frac_low_lam_le_0p5_median']:.3f} "
                  f"high={s['frac_high_lam_ge_1p5_median']:.3f} "
                  f"R4={s['linear_retention_L4_tau0p5_median']:.4f} "
                  f"f_neigh={s['neighbor_filter_energy_median']:.3f}")
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--reps',type=int,default=128);ap.add_argument('--outdir',default='.')
    a=ap.parse_args();run(a.reps,a.outdir)
