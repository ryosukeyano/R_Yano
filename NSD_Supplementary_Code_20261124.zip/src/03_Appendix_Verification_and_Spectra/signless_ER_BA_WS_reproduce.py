#!/usr/bin/env python3
"""Independent graph-family replication of signless-Laplacian statistics.

No original graph seeds, original trained network, or originally sampled
adjacency matrices are used or claimed to be recovered.

Usage:
    python signless_ER_BA_WS_reproduce.py --reps 128 --outdir .

Requires networkx, numpy, scipy, matplotlib (plotting only).
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import math
from collections import OrderedDict
from pathlib import Path
import numpy as np
import networkx as nx
from scipy import sparse
from scipy.sparse.linalg import eigsh, ArpackNoConvergence
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MASTER_SEED = 'NSD-SIGNLESS-20261120-parameter-matched-v1'


def configurations():
    configs = OrderedDict()
    ns = [10, 50, 100, 300]
    for n in ns:
        for model, param in [('ER', 'p=0.1'), ('BA', 'm=2'), ('BA', 'm=4'),
                             ('WS', 'k=4,p=0.1'), ('WS', 'k=6,p=0.2')]:
            configs[(model, n, param)] = {'baseline'}
    for p in [0.1, 0.3, 0.5, 0.7, 0.9]:
        configs.setdefault(('ER', 50, f'p={p:g}'), set()).add('ER_p_sweep')
    for n in [50,100,200]:
        for model, param in [('ER', 'p=0.1'),('BA', 'm=2'),('WS', 'k=4,p=0.1')]:
            configs.setdefault((model,n,param),set()).add('smoothed_target_sizes')
    return configs


def sample_seed(model, n, param, rep):
    identifier = f'{MASTER_SEED}|{model}|{n}|{param}|{rep}'
    return int.from_bytes(hashlib.sha256(identifier.encode()).digest()[:8], 'big') % (2**32-1)


def draw(model, n, param, seed):
    options=dict(item.split('=') for item in param.split(','))
    if model=='ER': return nx.erdos_renyi_graph(n, float(options['p']), seed=seed)
    if model=='BA': return nx.barabasi_albert_graph(n, int(options['m']), seed=seed)
    if model=='WS': return nx.watts_strogatz_graph(n, int(options['k']), float(options['p']), seed=seed)
    raise ValueError(model)


def smallest_psd_eigenvalue(M):
    n=M.shape[0]
    if n==0: return np.nan
    if n<=35:
        value = float(np.linalg.eigvalsh(M.toarray())[0])
    else:
        try: value = float(eigsh(M, k=1, which='SA', tol=1e-9, maxiter=max(3500, 30*n), return_eigenvectors=False)[0])
        except ArpackNoConvergence:
            value = float(np.linalg.eigvalsh(M.toarray())[0])
    return max(value,0.0)


def signless(G):
    n=G.number_of_nodes()
    if n<=1 or G.number_of_edges()==0: return 0.,float('nan')
    # A symmetric sparse adjacency and integer degrees; loops excluded.
    A=nx.to_scipy_sparse_array(G, nodelist=sorted(G.nodes), format='csr', dtype=float)
    deg=np.asarray(A.sum(axis=1), dtype=float).reshape(-1)
    Q=sparse.csr_matrix(A)+sparse.diags(deg,format='csr')
    qmin=smallest_psd_eigenvalue(Q)
    if min(deg)<=0: return qmin,float('nan')
    r=1.0/np.sqrt(deg)
    Qnorm=sparse.diags(r)@Q@sparse.diags(r)
    nmin=smallest_psd_eigenvalue(Qnorm.tocsr())
    return qmin,nmin


def per_draw(model, n, param, rep):
    seed=sample_seed(model,n,param,rep)
    G=draw(model,n,param,seed)
    parts=sorted(nx.connected_components(G), key=len, reverse=True)
    L=G.subgraph(parts[0]).copy()
    connected=(len(parts)==1)
    lcc_nonbip=not nx.is_bipartite(L)
    # Full-graph bipartite flag does not imply connectedness.
    full_bip=nx.is_bipartite(G)
    lcc_mu,lcc_nu=signless(L) if lcc_nonbip else (0.0,0.0 if L.number_of_edges()>0 else float('nan'))
    # If ANY component is bipartite, the full signless Laplacian is singular.
    if any(nx.is_bipartite(G.subgraph(component)) for component in parts):
        full_mu=0.0
    else:
        full_mu=smallest_psd_eigenvalue(sparse.csr_matrix(nx.to_scipy_sparse_array(G, format='csr',dtype=float))+
          sparse.diags(np.array([d for _,d in sorted(G.degree())],dtype=float),format='csr'))
    return dict(family=model, n=n, parameters=param, rep=rep, seed=seed,
                num_edges=G.number_of_edges(), average_degree=2*G.number_of_edges()/n,
                num_components=len(parts), isolated=sum(d==0 for _,d in G.degree()),
                connected=int(connected), bipartite=int(full_bip),
                eligible=int(connected and not full_bip),
                lcc_n=L.number_of_nodes(), lcc_fraction=L.number_of_nodes()/n,
                lcc_nonbip=int(lcc_nonbip), full_mu=full_mu,
                lcc_mu=lcc_mu, lcc_nu=lcc_nu)


def summarize(all_rows, configurations):
    out=[]
    for (family,n,param),groups in configurations.items():
        rows=[r for r in all_rows if r['family']==family and r['n']==n and r['parameters']==param]
        def avg(key): return float(np.mean([r[key] for r in rows]))
        def descr(key):
            data=np.array([r[key] for r in rows],dtype=float)
            data=data[np.isfinite(data)]
            return (float(np.mean(data)),float(np.std(data,ddof=1)),
                    float(np.median(data)),float(np.quantile(data,0.1)),float(np.quantile(data,0.9))) if len(data) else (float('nan'),)*5
        d=dict(family=family,n=n,parameters=param, groups=';'.join(sorted(groups)),
               repeats=len(rows),mean_degree=avg('average_degree'),
               frac_connected=avg('connected'),frac_bipartite=avg('bipartite'),
               frac_eligible=avg('eligible'),frac_lcc_nonbip=avg('lcc_nonbip'),
               mean_lcc_fraction=avg('lcc_fraction'),frac_isolated=avg('isolated')/n)
        for key in ['full_mu','lcc_mu','lcc_nu']:
            m,s,median,q10,q90=descr(key)
            d.update({f'{key}_{suffix}':val for suffix,val in zip(['mean','std','median','q10','q90'],[m,s,median,q10,q90])})
        out.append(d)
    return out


def plot_summary(rows,outdir):
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
    styles=[('ER','p=0.1','ER, p=0.1'),('BA','m=2','BA, m=2'),('BA','m=4','BA, m=4'),
            ('WS','k=4,p=0.1','WS, k=4, p=0.1'),('WS','k=6,p=0.2','WS, k=6, p=0.2')]
    fig,axes=plt.subplots(1,2,figsize=(10.1,4.1))
    for family,param,label in styles:
        subset=sorted((r for r in rows if r['family']==family and r['parameters']==param and r['n'] in [10,50,100,300]),key=lambda r:r['n'])
        xx=[r['n'] for r in subset]
        for ax,metric in [(axes[0],'lcc_mu'),(axes[1],'lcc_nu')]:
            yy=[r[f'{metric}_median'] for r in subset]
            low=[r[f'{metric}_q10'] for r in subset]
            hi=[r[f'{metric}_q90'] for r in subset]
            ax.plot(xx,yy,marker='o',lw=1.6,ms=4,label=label)
            ax.fill_between(xx,low,hi,alpha=.13)
    axes[0].set_ylabel(r'$\mu_{\rm LCC}=\lambda_{\min}(Q_{\rm LCC})$')
    axes[1].set_ylabel(r'$\nu_{\rm LCC}=\lambda_{\min}(D^{-1/2}QD^{-1/2})$')
    for ax in axes:
        ax.set_xlabel('Number of vertices, N')
        ax.set_xticks([10,50,100,300]);ax.grid(alpha=.2)
        ax.set_ylim(bottom=0)
    # Fig. A.18 ONLY: 25% larger axis titles and tick labels (9 pt -> 11.25 pt).
    for axis in axes:
        axis.xaxis.label.set_fontsize(11.25)
        axis.yaxis.label.set_fontsize(11.25)
        axis.tick_params(axis='both', which='both', labelsize=11.25)
    handles,labels=axes[1].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(0.5,0.025),ncol=3,fontsize=8,frameon=False)
    fig.tight_layout(rect=(0,0.16,1,1),pad=1.2)
    for ext in ['pdf','eps','png']:
        fig.savefig(outdir/f'signless_mu_by_N.{ext}',dpi=190)
    plt.close(fig)

    er=sorted((r for r in rows if r['family']=='ER' and r['n']==50),key=lambda r:float(r['parameters'].split('=')[1]))
    fig,axes=plt.subplots(1,2,figsize=(9.2,3.25))
    pp=[float(r['parameters'].split('=')[1]) for r in er]
    nu=[r['lcc_nu_median'] for r in er]
    lq=[r['lcc_nu_q10'] for r in er]
    uq=[r['lcc_nu_q90'] for r in er]
    axes[0].plot(pp,nu,'o-',lw=1.5); axes[0].fill_between(pp,lq,uq,alpha=.18)
    axes[0].set_xlabel('ER edge probability p (N=50)');axes[0].set_ylabel(r'$\nu_{\rm LCC}$')
    ec=[r['frac_eligible'] for r in er]
    axes[1].plot(pp,ec,'o-',lw=1.5)
    axes[1].set_xlabel('ER edge probability p (N=50)');axes[1].set_ylabel('Connected, non-bipartite fraction')
    for ax in axes: ax.grid(alpha=.2);ax.set_xlim(0.075,.925);ax.set_ylim(bottom=0)
    axes[1].set_ylim(0,1.03)
    fig.tight_layout(pad=1.2)
    for ext in ['pdf','eps','png']:
        fig.savefig(outdir/f'signless_ER_p_sweep.{ext}',dpi=190)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reps',type=int,default=128)
    parser.add_argument('--outdir',default='.')
    args=parser.parse_args()
    outdir=Path(args.outdir);outdir.mkdir(parents=True,exist_ok=True)
    cfgs=configurations()
    results=[]
    for i,((family,n,param),groups) in enumerate(cfgs.items(),start=1):
        for rep in range(args.reps):results.append(per_draw(family,n,param,rep))
        print(f'[{i}/{len(cfgs)}] {family} n={n} {param}: {args.reps} independent draws',flush=True)
    summary=summarize(results,cfgs)
    for name,records in [('signless_mu_individual_draws.csv',results),('signless_mu_summary.csv',summary)]:
        with (outdir/name).open('w',newline='',encoding='utf8') as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0].keys()))
            writer.writeheader();writer.writerows(records)
    plot_summary(summary,outdir)
    print('Summary:')
    for row in summary:
        if 'baseline' in row['groups']:
            print(f"{row['family']:2s} N={row['n']:3d} {row['parameters']:12s} eligible={row['frac_eligible']:.2f} LCC={row['mean_lcc_fraction']:.2f} mu={row['lcc_mu_median']:.4f} nu={row['lcc_nu_median']:.4f}")
    print('Completed',len(results),'draws',flush=True)
if __name__=='__main__':main()
