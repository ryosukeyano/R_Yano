NSD PHYSD-D-26-01887: Supplementary Code Archive (2026-11-24).
Please read README_CODE_TO_FIGURES_EN.md and CODE_TO_FIGURE_MAP.csv first.
The original 2026-11-21 source ZIP is preserved unchanged.
Historical PeMSD7 and corrected NSD/GCN experiments are clearly separated.
Results/data needed for full independent figure or traffic reruns are NOT all included.
The source manifest includes SHA-256 digests.
