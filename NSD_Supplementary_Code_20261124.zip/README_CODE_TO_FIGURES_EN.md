# PHYSD-D-26-01887 — Supplementary Code Archive / source-to-figure guide

**Purpose:** accompany the major revision of *Sheaf-Valued Diffusion Limits on Complex Networks*.
The source files are grouped by scientific role, not chronology. No computational experiment has
been rerun as part of packaging. The included scripts are not a guarantee that every figure or
table can be independently regenerated from the ZIP alone. See `CODE_TO_FIGURE_MAP.csv`
for the *per-figure and per-table* crosswalk.

## Folder organization

- `00_Original_20261121_Archive/`: the original ZIP supplied by coauthor Karube, preserved **byte-for-byte**. SHA-256 below. It contains historical traffic scripts, source library, historical outputs/figures, and legacy synthetic runners. It is evidence of provenance, not the source of the corrected Figures 5–11.
- `01_PeMSD7_Historical_Source/`: an accessible extracted selection of that unchanged original (model, data loader, dated experiment scripts, source/metric CSVs). See Table 2 and Fig. 12 entries in the mapping CSV.
- `01b_Historical_Synthetic_Provenance_Not_Used_For_Revised_Figures/`: historical experiment and plot scripts, **not** the corrected NSD/GCN baseline. The old comparator was graph-blind MLP; the old target had a broadcast issue. Do not regenerate the current figures from these.
- `02_Corrected_Synthetic_Figures_5_to_11/`: corrected NSD runner, genuine GCN on the same saved graph/targets, GPU BAT launchers, combined plotting, and tests; Fig. 5–11.
- `03_Appendix_Verification_and_Spectra/`: rank-one algebraic verification, restricted-ridge stress test, and independent graph-ensemble spectral calculations for Appendix A.
- `04_RankD_Kernel_Construction_Spotcheck/`: optional finite rank-d linear-algebra spot check of Lemma B, not a proof.
- `05_Final_Times_New_Roman_Replot_Figures_5_to_11/`: compact, large-font EPS/PDF/PNG plotters for Figures 5–11, which read saved NSD/GCN loss CSVs, do not retrain the models, and expect Windows results directories.

## Important limits (do not suppress in any manuscript or referee reply)

* Historic PeMSD7 NSD: 15-min=3 steps, hidden width h=20 and up to 1500 epochs with early stopping; 45-min=9 steps, h=10, no more than 5 epochs. These are **not matched training budgets**. The historical evaluation averages scores over prediction windows, not only one horizon point.
* The historic `runpemsdGCN.py` six-step run is **30 minutes**, not 45 minutes. The Table 2 STGCN(Cheb) row is published **external literature data** obtained with a different evaluation protocol; it must not be ranked as a controlled head-to-head experiment against historical NSD.
* The original archive does not include PeMSD7 raw/preprocessed input arrays, model weights/checkpoints, all optimizer histories, the exact Table 1 graph-feature generator, or a verified Figure 12 trace-generation script.
* The corrected synthetic calculations use rank d=2/4/6/8, two learned NSD residual blocks and a true graph-convolution comparator; outputs have scalar N×1 shape. The different model parameter counts and graph propagation depths are **not capacity matched**; training plots are single-seed training MSE, not held-out test scores.
* `results_BASE_GPU`, `results_SWEEPS_GPU`, `results_SMOOTHED_GPU` are **not included**. Replotters stop when source loss CSVs are absent. To reproduce the plots on another machine, first rerun or supply the original saved calculation directories. **The attached EPS are the accepted paper figures, not new calculations made during packaging.**
* The spectral ER/BA/WS diagnostics in Appendix A.4 are run on **independently regenerated graphs**, not on the exact historical training instances. They cannot establish a causal learning-rate relationship.

## Reproduction entry points (Windows, after installing declared scientific Python dependencies)

Open `02_Corrected_Synthetic_Figures_5_to_11/README_FIRST_JA.md`, and use the existing `.bat` scripts, with appropriate GPU setup. For replotting saved loss histories (not training): `05_Final_Times_New_Roman_Replot_Figures_5_to_11/01_REPLOT_ALL_5_TO_11_TIMES.bat`. For Appendix rank-one checks:

```
python 03_Appendix_Verification_and_Spectra/verify_rank1_sheaf_d1.py --samples 600 --outdir results_rank_one
python 03_Appendix_Verification_and_Spectra/bipartite_density_appendix_a3_repro.py
python 03_Appendix_Verification_and_Spectra/signless_ER_BA_WS_reproduce.py --help
python 03_Appendix_Verification_and_Spectra/spectral_distribution_ER_BA_WS.py --help
```

These commands are execution pointers, not claims that unavailable datasets/models were reconstructed.

## Source identity and permissions

SHA-256 (unmodified coauthor source ZIP): `feb56bcbf775f77ad39f6593273b0c2dcd44e07be7c24804d2906e86d34619fd`

`01_PeMSD7_Historical_Source` is an extracted selection, not a modified reimplementation.
The original archive carries an Apache-2.0 LICENSE and includes third-party-derived code;
authors should confirm coauthor approval and third-party notices before **public** distribution.
In the present editorial package the code is supplied for reviewer inspection only; a public
repository release has not been claimed.
